# فارسی اُردو بول چال — اینڈرائیڈ ایپ (Flutter)

## 1) ایک بار کی تیاری (کمپیوٹر پر)
1. Flutter انسٹال کریں: https://docs.flutter.dev/get-started/install
2. Android Studio انسٹال کریں (Android SDK کے لیے) اور `flutter doctor` چلا کر دیکھیں کہ سب ٹھیک ہے۔

## 2) پروجیکٹ چلانا
اس فولڈر میں ٹرمینل کھولیں اور یہ حکم ایک ایک کر کے چلائیں:

```
flutter create --project-name farsi_urdu --platforms=android .
flutter pub get
```

پھر فائل `android/app/src/main/AndroidManifest.xml` کھولیں:
- `<application` سے **پہلے** یہ سطر ڈالیں (آن لائن اپڈیٹ کے لیے ضروری ہے):
  `<uses-permission android:name="android.permission.INTERNET"/>`
- `<application` کے اندر `android:label="..."` کی جگہ ایپ کا نام لکھیں: `فارسی اُردو بول چال`

موبائل جوڑ کر چلانے کے لیے: `flutter run`

APK بنانے کے لیے: `flutter build apk --release`
فائل یہاں ملے گی: `build/app/outputs/flutter-apk/app-release.apk`

(اگر `flutter create` کے بعد `test` فولڈر بن جائے تو اسے حذف کر دیں۔)

## 3) اپنے لنک لکھنا — `lib/config.dart`
- `appLink` — ایپ کا لنک (پلے اسٹور یا ویب سائٹ)۔ **ہر شیئر کے ساتھ یہی لنک جاتا ہے۔**
- `contentUrl` — آن لائن اپڈیٹ کی فائل کا لنک
- `feedbackEmail` — تصحیح و اضافہ کی ای میل

## 4) اپنے اسباق ڈالنا — `assets/data/content.json`
سب مواد اسی ایک فائل میں ہے: lessons، grammar، conversation، articles، stories، poems، dictionary، dialects۔
نمونے دیکھ کر اسی شکل میں نیا مواد ڈال دیں۔ کوڈ کو چھیڑنے کی ضرورت نہیں۔

## 5) آن لائن اپڈیٹ کیسے چلتی ہے
1. `content.json` میں مواد بدلیں اور **`version` کا نمبر بڑھا دیں** (مثلاً 1 سے 2)۔
2. وہی فائل اپنی ویب سائٹ / GitHub Pages پر `contentUrl` والے پتے پر رکھ دیں۔
3. ایپ میں «آن لائن اپڈیٹ» دبانے سے نیا مواد فون میں محفوظ ہو جاتا ہے۔

## 6) فونٹ
ایپ Google Fonts (Vazirmatn، Noto Naskh، Noto Nastaliq Urdu) استعمال کرتی ہے۔ پہلی بار انٹرنیٹ سے آتے ہیں اور پھر فون میں محفوظ رہتے ہیں۔

## 7) کیلنڈر
ایرانی کیلنڈر الگورتھم سے نکلتا ہے۔ اسلامی تاریخ حسابی ہے، چاند دیکھنے کی وجہ سے ایک دن کا فرق ہو سکتا ہے؛ کیلنڈر اسکرین میں ایڈجسٹمنٹ کا بٹن ہے۔
