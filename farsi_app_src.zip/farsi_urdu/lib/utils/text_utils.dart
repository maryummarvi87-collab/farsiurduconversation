import '../state.dart';

const String _faDigits = '۰۱۲۳۴۵۶۷۸۹';
const String _arDigits = '٠١٢٣٤٥٦٧٨٩';

/// فارسی/عربی ہندسوں کو انگریزی ہندسوں میں بدلتا ہے۔
String toLatinDigits(String s) {
  final b = StringBuffer();
  for (final r in s.runes) {
    final c = String.fromCharCode(r);
    var i = _faDigits.indexOf(c);
    if (i < 0) i = _arDigits.indexOf(c);
    b.write(i >= 0 ? '$i' : c);
  }
  return b.toString();
}

/// ترتیبات کے مطابق ہندسے دکھاتا ہے (۱۲۳ یا 123)۔
String localDigits(Object n) {
  final s = '$n';
  if (!settings.persianDigits) return s;
  final b = StringBuffer();
  for (final ch in s.split('')) {
    final i = int.tryParse(ch);
    b.write(i == null ? ch : _faDigits[i]);
  }
  return b.toString();
}

String two(int n) => n < 10 ? '0$n' : '$n';

const Map<String, String> _letterMap = {
  'ي': 'ی', 'ى': 'ی', 'ې': 'ی', 'ے': 'ی', 'ۓ': 'ی', 'ئ': 'ی',
  'ك': 'ک', 'ڪ': 'ک',
  'ہ': 'ه', 'ھ': 'ه', 'ة': 'ه', 'ۀ': 'ه', 'ۂ': 'ه', 'ۃ': 'ه',
  'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا',
  'ؤ': 'و',
  'ٹ': 'ت', 'ڈ': 'د', 'ڑ': 'ر', 'ں': 'ن',
};

final RegExp _strip = RegExp('[ً-ٰٟـ‌‍‎‏]');

/// تلاش کے لیے متن کو یکساں بناتا ہے: اردو اور فارسی کے ملتے جلتے حروف
/// (ی/ي/ے، ک/ك، ه/ہ/ھ)، اعراب، ZWNJ اور ہندسے ایک ہی شکل میں آ جاتے ہیں۔
String normalize(String input) {
  var s = toLatinDigits(input.toLowerCase()).replaceAll(_strip, '');
  final b = StringBuffer();
  for (final ch in s.split('')) {
    b.write(_letterMap[ch] ?? ch);
  }
  return b.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
}

/// قرآن سیکشن میں اردو آواز کے لیے بولا جانے والا متن: اردو شرح/ترجمے کے
/// اندر آئے مکمل اعراب والے قرآنی عربی الفاظ بولنے سے ہٹا دیے جاتے ہیں
/// (اردو آواز انہیں غلط تلفظ سے پڑھتی ہے؛ قرآنی عربی کی اصل آواز تلاوت ہے)۔
/// واحد اعراب والے اصل اردو نمونے محفوظ رہتے ہیں: اُن/اُس/اِس (ابتدائی ا پر
/// ایک اعراب)، اضافت کا زیر (حرفِ، آلِ)، تنوین والے اردو مظروف (یقیناً،
/// مثلاً)، دُعا/بُرے جیسے الفاظ، اور صرف ٰ (U+0670) والے اردو الفاظ
/// (تعالیٰ، الٰہی، لہٰذا) — ان میں بنیادی اعراب ہوتا ہی نہیں۔
/// ڈسپلے متن نہیں بدلتا؛ یہ صرف اسپیکر کو بھیجا جانے والا متن ہے۔
String urduSpeechText(String text) {
  var s = text.replaceAll(RegExp(r'﴿[^﴾]*﴾'), ' ');
  final kept = <String>[];
  for (final tok in s.split(RegExp(r'\s+'))) {
    if (tok.isNotEmpty && !_isQuranicArabicToken(tok)) kept.add(tok);
  }
  s = kept.join(' ');
  // تنہا رموز/نشانات (—، ۞، [= وغیرہ) جن میں کوئی حرف/ہندسہ نہیں — بولنے
  // میں ان کی کوئی آواز نہیں، ہٹا دو
  s = s
      .split(RegExp(r'\s+'))
      .where((t) => t.runes.any(_isSpeechLetterOrDigit))
      .join(' ');
  s = s.replaceAll(RegExp(r'\s+([،۔؛:؟!»)])'), r'$1');
  s = s.replaceAll(RegExp(r'([،؛])(\s*[،؛])+'), r'$1');
  s = s.replaceAll('()', ' ').replaceAll('( )', ' ');
  s = s.replaceAll(RegExp(r'\s+'), ' ').trim();
  s = s.replaceAll(RegExp(r'^[ ،؛]+|[ ،؛]+$'), '');
  return s.trim();
}

bool _isSpeechLetter(int r) =>
    (r >= 0x0621 && r <= 0x064A) ||
    (r >= 0x066E && r <= 0x06D3) ||
    (r >= 0x41 && r <= 0x5A) ||
    (r >= 0x61 && r <= 0x7A);

bool _isSpeechLetterOrDigit(int r) =>
    _isSpeechLetter(r) ||
    (r >= 0x30 && r <= 0x39) ||
    (r >= 0x660 && r <= 0x669) ||
    (r >= 0x6F0 && r <= 0x6F9);

const Set<int> _speechPunct = {
  0x060C, 0x06D4, 0x061B, 0x003A, 0x061F, 0x0021, 0x00AB, 0x00BB,
  0x0028, 0x0029, 0x005B, 0x005D, 0x0022, 0x0027, 0x2026,
};

const Set<int> _urduSpecificRunes = {
  0x0679, 0x0688, 0x0691, 0x06BE, 0x06D2, 0x06AF, 0x0686, 0x067E,
};

/// ایک ٹوکن قرآنی عربی ہے؟ مکمل اعراب (بنیادی اعراب U+064B–U+065F) نشانی
/// ہے؛ مگر واحد اعراب والے اردو نمونے (اُن، حرفِ، یقیناً، دُعا) مستثنیٰ ہیں۔
bool _isQuranicArabicToken(String tok) {
  final runes = tok.runes.toList();
  var a = 0, b = runes.length;
  while (a < b && _speechPunct.contains(runes[a])) a++;
  while (b > a && _speechPunct.contains(runes[b - 1])) b--;
  if (a >= b) return false;
  final core = runes.sublist(a, b);
  final letters = core.where(_isSpeechLetter).length;
  final markIdx = <int>[];
  for (var i = 0; i < core.length; i++) {
    if (core[i] >= 0x064B && core[i] <= 0x065F) markIdx.add(i);
  }
  if (markIdx.isEmpty) return false;
  // قرآنی رسم کی نشانی (ٰ یا وقف علامات) بنیادی اعراب کے ساتھ ہو تو عربی
  if (core.any((r) => r == 0x0670 || (r >= 0x06D6 && r <= 0x06ED))) {
    return true;
  }
  if (markIdx.length >= 2) return true;
  final m = core[markIdx.first];
  final mi = markIdx.first;
  // اُن/اُس/اِن/اُٹھانا — ابتدائی ا پر واحد اعراب
  if (core.first == 0x0627 && mi == 1) return false;
  // یقیناً/مثلاً — آخر میں واحد تنوین، لمبا لفظ
  if ((m == 0x064B || m == 0x064C || m == 0x064D) &&
      mi == core.length - 1 &&
      letters >= 3) {
    return false;
  }
  // حرفِ/آلِ — آخر میں اضافت کا واحد زیر
  if (m == 0x0650 && mi == core.length - 1 && letters >= 2) return false;
  // بُرے/دُھوپ — اردو مخصوص حروف والا لفظ
  if (core.any(_urduSpecificRunes.contains)) return false;
  // دُعا — پہلے حرف پر واحد اعراب، لمبا لفظ
  if (mi == 1 && letters >= 3) return false;
  return true;
}
