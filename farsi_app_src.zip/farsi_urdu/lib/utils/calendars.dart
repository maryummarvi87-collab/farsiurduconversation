import 'dart:math' as math;

import '../state.dart';
import 'text_utils.dart';

// ---------------------------------------------------------------------------
// جولین ڈے نمبر (JDN) کی بنیاد پر تینوں کیلنڈروں کی تبدیلی۔
// ---------------------------------------------------------------------------

const int _unixEpochJdn = 2440588;

int gregorianToJdn(int y, int m, int d) =>
    DateTime.utc(y, m, d).difference(DateTime.utc(1970, 1, 1)).inDays +
    _unixEpochJdn;

DateTime jdnToDate(int jdn) =>
    DateTime.utc(1970, 1, 1).add(Duration(days: jdn - _unixEpochJdn));

int todayJdn() {
  final n = DateTime.now();
  return gregorianToJdn(n.year, n.month, n.day);
}

/// ہفتے کا دن: 0 = پیر ... 6 = اتوار
int weekdayIndex(int jdn) => jdn % 7;

/// ہفتہ (شنبہ) سے شروع ہونے والے گرڈ میں کالم: 0 = ہفتہ ... 6 = جمعہ
int saturdayColumn(int jdn) => (jdn % 7 + 2) % 7;

const List<String> weekdayFa = [
  'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه', 'یکشنبه'
];
const List<String> weekdayUr = [
  'پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ', 'اتوار'
];

int _div(int a, int b) => a ~/ b;
int _mod(int a, int b) => a - (a ~/ b) * b; // C/JS کی طرح (منفی کے لیے بھی)

// ----------------------------- ایرانی (شمسی ہجری) --------------------------

const List<int> _breaks = [
  -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097,
  2192, 2262, 2324, 2394, 2456, 3178
];

class _JalCal {
  final int leap;
  final int gy;
  final int march;
  const _JalCal(this.leap, this.gy, this.march);
}

_JalCal _jalCal(int jy) {
  final gy = jy + 621;
  var leapJ = -14;
  var jp = _breaks[0];
  var jump = 0;
  for (var i = 1; i < _breaks.length; i++) {
    final jm = _breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ += _div(jump, 33) * 8 + _div(_mod(jump, 33), 4);
    jp = jm;
  }
  var n = jy - jp;
  leapJ += _div(n, 33) * 8 + _div(_mod(n, 33) + 3, 4);
  if (_mod(jump, 33) == 4 && jump - n == 4) leapJ += 1;
  final leapG = _div(gy, 4) - _div((_div(gy, 100) + 1) * 3, 4) - 150;
  final march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + _div(jump + 4, 33) * 33;
  var leap = _mod(_mod(n + 1, 33) - 1, 4);
  if (leap == -1) leap = 4;
  return _JalCal(leap, gy, march);
}

int jalaliToJdn(int jy, int jm, int jd) {
  final r = _jalCal(jy);
  return gregorianToJdn(r.gy, 3, r.march) +
      (jm - 1) * 31 -
      _div(jm, 7) * (jm - 7) +
      jd -
      1;
}

List<int> jdnToJalali(int jdn) {
  final gy = jdnToDate(jdn).year;
  var jy = gy - 621;
  final r = _jalCal(jy);
  final jdn1f = gregorianToJdn(gy, 3, r.march);
  var k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) {
      return [jy, 1 + _div(k, 31), _mod(k, 31) + 1];
    }
    k -= 186;
  } else {
    jy -= 1;
    k += 179;
    if (r.leap == 1) k += 1;
  }
  return [jy, 7 + _div(k, 30), _mod(k, 30) + 1];
}

bool isJalaliLeap(int jy) => _jalCal(jy).leap == 0;

// ----------------------------- اسلامی (حسابی/عمومی) -------------------------

const int _hijriEpochJdn = 1948440;

int hijriToJdn(int y, int m, int d) =>
    d + (29.5 * (m - 1)).ceil() + (y - 1) * 354 + ((3 + 11 * y) ~/ 30) +
    _hijriEpochJdn - 1;

List<int> jdnToHijri(int jdn) {
  final y = (30 * (jdn - _hijriEpochJdn) + 10646) ~/ 10631;
  final m = math.min(12, ((jdn - (29 + hijriToJdn(y, 1, 1))) / 29.5).ceil() + 1);
  final d = jdn - hijriToJdn(y, m, 1) + 1;
  return [y, m, d];
}

// ---------------------------------------------------------------------------
// کیلنڈر سسٹمز کا مشترکہ انٹرفیس
// ---------------------------------------------------------------------------

abstract class CalSystem {
  const CalSystem();
  String get label;
  List<String> get monthNames;
  List<int> fromJdn(int jdn); // [سال، مہینہ، دن]
  int toJdn(int y, int m, int d);
  int monthLength(int y, int m);

  String monthName(int m) => monthNames[m - 1];

  String format(int jdn) {
    final d = fromJdn(jdn);
    return '${localDigits(d[2])} ${monthName(d[1])} ${localDigits(d[0])}';
  }
}

class JalaliCal extends CalSystem {
  const JalaliCal();
  @override
  String get label => 'ایرانی';
  @override
  List<String> get monthNames => const [
        'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
      ];
  @override
  List<int> fromJdn(int jdn) => jdnToJalali(jdn);
  @override
  int toJdn(int y, int m, int d) => jalaliToJdn(y, m, d);
  @override
  int monthLength(int y, int m) {
    if (m <= 6) return 31;
    if (m <= 11) return 30;
    return isJalaliLeap(y) ? 30 : 29;
  }
}

class GregorianCal extends CalSystem {
  const GregorianCal();
  @override
  String get label => 'عیسوی';
  @override
  List<String> get monthNames => const [
        'جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون',
        'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر'
      ];
  @override
  List<int> fromJdn(int jdn) {
    final d = jdnToDate(jdn);
    return [d.year, d.month, d.day];
  }

  @override
  int toJdn(int y, int m, int d) => gregorianToJdn(y, m, d);
  @override
  int monthLength(int y, int m) => DateTime.utc(y, m + 1, 0).day;
}

class HijriCal extends CalSystem {
  const HijriCal();
  @override
  String get label => 'اسلامی';
  @override
  List<String> get monthNames => const [
        'محرم', 'صفر', 'ربیع الاول', 'ربیع الثانی', 'جمادی الاول',
        'جمادی الثانی', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذیقعدہ', 'ذوالحجہ'
      ];

  /// چاند دیکھنے کی وجہ سے ±1 دن کا فرق ہو سکتا ہے؛ صارف ترتیب سے ایڈجسٹ کر سکتا ہے۔
  @override
  List<int> fromJdn(int jdn) => jdnToHijri(jdn + settings.hijriAdjust);
  @override
  int toJdn(int y, int m, int d) => hijriToJdn(y, m, d) - settings.hijriAdjust;
  @override
  int monthLength(int y, int m) {
    final ny = m == 12 ? y + 1 : y;
    final nm = m == 12 ? 1 : m + 1;
    return hijriToJdn(ny, nm, 1) - hijriToJdn(y, m, 1);
  }
}

const List<CalSystem> calendarSystems = [
  JalaliCal(),
  GregorianCal(),
  HijriCal(),
];
