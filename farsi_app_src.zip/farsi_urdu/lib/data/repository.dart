import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import '../config.dart';
import '../utils/text_utils.dart';

String str(dynamic v) => v == null ? '' : '$v';

List<Map<String, dynamic>> asMaps(dynamic v) {
  if (v is! List) return [];
  return v.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
}

/// تلاش کا ایک نتیجہ
class Hit {
  final String kind; // مثلاً: «سبق · سلام اور تعارف»
  final String section; // lessons, dictionary, ...
  final int index;
  final String fa;
  final String ur;
  final String hay;
  final String hayNoSpace;

  Hit(this.kind, this.section, this.index, this.fa, this.ur, this.hay)
      : hayNoSpace = hay.replaceAll(' ', '');
}

class UpdateResult {
  final bool ok;
  final String message;
  const UpdateResult(this.ok, this.message);
}

class Repository {
  Map<String, dynamic> data = {};
  List<Hit> _index = [];

  int get version => (data['version'] as num?)?.toInt() ?? 0;
  String get updated => str(data['updated']);

  List<Map<String, dynamic>> list(String key) => asMaps(data[key]);

  Future<File> _cacheFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/content_cache.json');
  }

  /// پہلے ایپ کے ساتھ آیا ہوا مواد، پھر اگر آن لائن اپڈیٹ کا نیا ورژن محفوظ ہو تو وہ۔
  Future<void> load() async {
    final raw = await rootBundle.loadString('assets/data/content.json');
    final bundled = json.decode(raw) as Map<String, dynamic>;
    data = bundled;
    try {
      final f = await _cacheFile();
      if (await f.exists()) {
        final cached = json.decode(await f.readAsString()) as Map<String, dynamic>;
        final cv = (cached['version'] as num?)?.toInt() ?? 0;
        final bv = (bundled['version'] as num?)?.toInt() ?? 0;
        if (cv > bv) data = cached;
      }
    } catch (_) {}
    _buildIndex();
  }

  Future<UpdateResult> checkForUpdate() async {
    if (AppConfig.contentUrl.contains('example.com')) {
      return const UpdateResult(
          false, 'ابھی اپڈیٹ کا لنک سیٹ نہیں ہوا۔ lib/config.dart میں contentUrl لکھیں۔');
    }
    try {
      final res = await http
          .get(Uri.parse(AppConfig.contentUrl))
          .timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) {
        return UpdateResult(false, 'سرور سے جواب نہیں ملا (کوڈ ${res.statusCode})۔');
      }
      final remote = json.decode(utf8.decode(res.bodyBytes));
      if (remote is! Map<String, dynamic>) {
        return const UpdateResult(false, 'اپڈیٹ فائل کی شکل درست نہیں ہے۔');
      }
      final rv = (remote['version'] as num?)?.toInt() ?? 0;
      if (rv <= version) {
        return const UpdateResult(true, 'آپ کے پاس تازہ ترین مواد موجود ہے۔');
      }
      final f = await _cacheFile();
      await f.writeAsString(json.encode(remote));
      data = remote;
      _buildIndex();
      return UpdateResult(true, 'نیا مواد (ورژن $rv) شامل ہو گیا۔');
    } catch (_) {
      return const UpdateResult(false, 'انٹرنیٹ سے رابطہ نہیں ہو سکا۔ دوبارہ کوشش کریں۔');
    }
  }

  // ------------------------------- تلاش -----------------------------------

  void _add(String kind, String section, int idx, String fa, String ur,
      [String extra = '']) {
    _index.add(Hit(kind, section, idx, fa, ur, normalize('$fa $ur $extra')));
  }

  void _buildIndex() {
    _index = [];
    const setLabels = {
      'lessons': 'سبق',
      'conversation': 'بول چال',
      'stories': 'کہانی',
      'poems': 'شاعری',
    };
    for (final e in setLabels.entries) {
      final sets = list(e.key);
      for (var i = 0; i < sets.length; i++) {
        final title = str(sets[i]['title']);
        for (final it in asMaps(sets[i]['items'])) {
          _add('${e.value} · $title', e.key, i, str(it['fa']), str(it['ur']));
        }
      }
    }
    final words = list('dictionary');
    for (var i = 0; i < words.length; i++) {
      _add('لغت', 'dictionary', i, str(words[i]['fa']), str(words[i]['ur']),
          str(words[i]['pos']));
    }
    final verbs = list('verbs');
    for (var i = 0; i < verbs.length; i++) {
      _add('مصدر', 'verbs', i, str(verbs[i]['fa']), str(verbs[i]['ur']),
          '${str(verbs[i]['past'])} ${str(verbs[i]['pres'])}');
    }
    final sentences = list('sentences');
    for (var i = 0; i < sentences.length; i++) {
      _add('جملہ', 'sentences', i, str(sentences[i]['fa']),
          str(sentences[i]['ur']));
    }
    const textLabels = {'grammar': 'گرامر', 'articles': 'مضمون'};
    for (final e in textLabels.entries) {
      final items = list(e.key);
      for (var i = 0; i < items.length; i++) {
        final body = str(items[i]['body']);
        final snippet = body.length > 120 ? '${body.substring(0, 120)}…' : body;
        _add(e.value, e.key, i, str(items[i]['title']), snippet, body);
      }
    }
    final dialects = list('dialects');
    for (var i = 0; i < dialects.length; i++) {
      for (final p in asMaps(dialects[i]['phrases'])) {
        _add('لہجہ · ${str(dialects[i]['name'])}', 'dialects', i, str(p['fa']),
            str(p['ur']));
      }
    }
    // کتابیں: ہر سبق کی سطریں (index = سارے اسباق کی چپٹی فہرست میں نمبر)
    var bookLessonIdx = 0;
    for (final b in list('books')) {
      for (final l in asMaps(b['lessons'])) {
        final body = str(l['body']);
        final snippet = body.length > 120 ? '${body.substring(0, 120)}…' : body;
        _add('کتاب · ${str(l['title'])}', 'books', bookLessonIdx,
            str(l['title']), snippet, body);
        bookLessonIdx++;
      }
    }
  }

  /// اردو اور فارسی دونوں میں تلاش
  List<Hit> search(String query, {int limit = 120}) {
    final q = normalize(query);
    if (q.isEmpty) return [];
    final qs = q.replaceAll(' ', '');
    final out = <Hit>[];
    for (final h in _index) {
      if (h.hay.contains(q) || h.hayNoSpace.contains(qs)) {
        out.add(h);
        if (out.length >= limit) break;
      }
    }
    return out;
  }
}

final Repository repo = Repository();
