import '../data/mushaf_data.dart';

/// ﴿ ﴾ آیت بلاک کا مصحف سے یقینی میچ — اصل تلاوت اور لفظی تفصیل کے لیے۔
/// اندازہ کبھی نہیں: بلاک یا تو کسی ایک آیت کے بالکل برابر ہو، یا کسی ایک
/// آیت کا منفرد درمیانی حصہ (تعلیم القرآن میں لمبی آیات ٹکڑوں میں آتی ہیں)۔
/// مبہم یا بے میچ بلاک → null (سادہ کارڈ، نہ تلاوت، نہ ٹچ — غلط ڈیٹا نہیں)۔
class AyahMatch {
  final int surah;
  final int ayah;
  final int global;
  final Map<String, dynamic>? wordRec;

  /// ڈسپلے ٹوکن (جن کی معمولی صورت خالی نہ ہو) کے شمار → لفظی اندراجات
  final Map<int, List<int>> tokenWords;
  const AyahMatch({
    required this.surah,
    required this.ayah,
    required this.global,
    required this.wordRec,
    required this.tokenWords,
  });
}

class _AyahNorm {
  final int global, surah, ayah;
  final String sp;
  final List<int> cmap;
  final int rawTokens;
  const _AyahNorm(
      this.global, this.surah, this.ayah, this.sp, this.cmap, this.rawTokens);
}

/// ایک حرف کی تطہیر: اعراب/علامات حذف، ہم شکل حروف کی یکسانیت
/// (مصحف کے ٮ U+066E جیسے رسمِ عثمانی حروف بھی عام صورت میں آ جاتے ہیں)۔
/// حذف ہو تو null۔
int? _normCp(int cp) {
  if (cp == 0x0640 ||
      cp == 0x0674 ||
      (cp >= 0x064B && cp <= 0x065F) ||
      cp == 0x0670 ||
      (cp >= 0x06D6 && cp <= 0x06ED)) {
    return null;
  }
  if (cp == 0x0622 ||
      cp == 0x0623 ||
      cp == 0x0625 ||
      cp == 0x0671 ||
      cp == 0x0672 ||
      cp == 0x0673 ||
      cp == 0x0675 ||
      cp == 0xFE8E) {
    return 0x0627; // ا
  }
  if (cp == 0x0624 || cp == 0x0676 || cp == 0x0677) return 0x0648; // و
  if (cp == 0x0626 ||
      cp == 0x06CC ||
      cp == 0x06D2 ||
      cp == 0x0649 ||
      cp == 0x066E) {
    return 0x064A; // ي
  }
  if (cp == 0x06A9) return 0x0643; // ك
  if (cp == 0x06C1 ||
      cp == 0x06BE ||
      cp == 0x06C2 ||
      cp == 0x0629 ||
      cp == 0x06C3) {
    return 0x0647; // ه
  }
  if (cp == 0x066F) return 0x0642; // ق
  return cp;
}

bool _keepCp(int cp) =>
    (cp >= 0x0621 && cp <= 0x06D3) ||
    (cp >= 0x0660 && cp <= 0x0669) ||
    (cp >= 0x06F0 && cp <= 0x06F9) ||
    (cp >= 0x30 && cp <= 0x39) ||
    (cp >= 0x41 && cp <= 0x5A) ||
    (cp >= 0x61 && cp <= 0x7A);

/// ایک ٹوکن کی معمولی صورت (صرف حروف/اعداد) — خالی ہو تو ٹوکن قابلِ ٹیپ نہیں
String normTokenForm(String token) {
  final b = StringBuffer();
  for (final cp in token.runes) {
    final m = _normCp(cp);
    if (m != null && _keepCp(m)) b.writeCharCode(m);
  }
  return b.toString();
}

class _Spaceless {
  final String sp;
  final List<int> cmap;
  final List<String> forms;
  const _Spaceless(this.sp, this.cmap, this.forms);
}

_Spaceless _spaceless(String text) {
  final toks = text.split(' ');
  final b = StringBuffer();
  final cmap = <int>[];
  final forms = <String>[];
  for (var t = 0; t < toks.length; t++) {
    final f = normTokenForm(toks[t]);
    forms.add(f);
    if (f.isEmpty) continue;
    b.write(f);
    for (var i = 0; i < f.runes.length; i++) {
      cmap.add(t);
    }
  }
  return _Spaceless(b.toString(), cmap, forms);
}

/// مصحف ڈیٹا سے ﴿ ﴾ بلاکس کا میچر — انڈیکس ایک بار بنتا ہے، نتائج کیش ہوتے ہیں
class AyahMatcher {
  AyahMatcher._();
  static final AyahMatcher instance = AyahMatcher._();

  Future<void>? _loading;
  final List<_AyahNorm> _ayahs = [];
  final Map<int, _AyahNorm> _byGlobal = {};
  final Map<String, List<int>> _exact = {};
  Map<String, dynamic> _words = {};
  final Map<String, AyahMatch?> _cache = {};

  Future<void> _ensure() => _loading ??= _build();

  Future<void> _build() async {
    final q = await MushafData.loadQuran();
    final w = await MushafData.loadWords();
    _words = ((w['words'] as Map?) ?? const {}).cast<String, dynamic>();
    var g = 0;
    for (final s in (q['surahs'] as List)) {
      final sm = s as Map<String, dynamic>;
      final sn = (sm['n'] as num).toInt();
      final ayahs = (sm['ayahs'] as List).cast<String>();
      for (var i = 0; i < ayahs.length; i++) {
        g++;
        final sl = _spaceless(ayahs[i]);
        final an = _AyahNorm(
            g, sn, i + 1, sl.sp, sl.cmap, ayahs[i].split(' ').length);
        _ayahs.add(an);
        _byGlobal[g] = an;
        (_exact[sl.sp] ??= []).add(g);
      }
    }
  }

  /// بلاک کا یقینی میچ — نہ ملے یا مبہم ہو تو null
  Future<AyahMatch?> match(String blockText) async {
    if (_cache.containsKey(blockText)) return _cache[blockText];
    await _ensure();
    final r = _matchNow(blockText);
    _cache[blockText] = r;
    return r;
  }

  AyahMatch? _matchNow(String blockText) {
    final bs = _spaceless(blockText);
    if (bs.sp.isEmpty) return null;
    int? g;
    var start = 0;
    final ex = _exact[bs.sp];
    if (ex != null && ex.length == 1) {
      g = ex.first;
    } else if (ex == null && bs.sp.runes.length >= 5) {
      // کسی ایک آیت کا منفرد درمیانی حصہ؟ (حصہ اس آیت میں ایک ہی بار آئے)
      int? foundG;
      var foundStart = 0;
      var count = 0;
      for (final a in _ayahs) {
        final idx = a.sp.indexOf(bs.sp);
        if (idx < 0) continue;
        if (a.sp.indexOf(bs.sp, idx + 1) >= 0) {
          count += 2; // ایک ہی آیت میں دو بار — مبہم
          foundG = a.global;
          continue;
        }
        count++;
        foundG = a.global;
        foundStart = idx;
        if (count > 1) break;
      }
      if (count == 1) {
        g = foundG;
        start = foundStart;
      }
    }
    if (g == null) return null;
    final a = _byGlobal[g]!;
    final rec = _words['${a.surah}:${a.ayah}'];
    final tokenWords = <int, List<int>>{};
    if (rec != null) {
      final mmapRaw = rec['m'];
      final List<List<int>> mmap = mmapRaw != null
          ? (mmapRaw as List)
              .map((e) =>
                  (e as List).map((x) => (x as num).toInt()).toList())
              .toList()
          : List.generate(a.rawTokens, (i) => [i]);
      var pos = start;
      var disp = -1;
      for (var t = 0; t < bs.forms.length; t++) {
        final f = bs.forms[t];
        if (f.isEmpty) continue;
        disp++;
        final end = pos + f.runes.length;
        final tids = <int>{};
        for (var c = pos; c < end && c < a.cmap.length; c++) {
          tids.add(a.cmap[c]);
        }
        final wset = <int>{};
        for (final tid in tids) {
          if (tid < mmap.length) wset.addAll(mmap[tid]);
        }
        if (wset.isNotEmpty) tokenWords[disp] = wset.toList()..sort();
        pos = end;
      }
    }
    return AyahMatch(
      surah: a.surah,
      ayah: a.ayah,
      global: a.global,
      wordRec: rec,
      tokenWords: tokenWords,
    );
  }
}
