import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';
import '../widgets/detail_sheet.dart';
import '../widgets/word_tap_text.dart';

/// لغت: فارسی ↔ اردو، تلاش کے خانے کے ساتھ
/// [dataKey] سے عام لغت یا آکسفورڈ لغت — دونوں ایک ہی انداز میں
class DictionaryScreen extends StatefulWidget {
  final String dataKey;
  final String title;
  const DictionaryScreen(
      {super.key, this.dataKey = 'dictionary', this.title = 'لغت'});

  @override
  State<DictionaryScreen> createState() => _DictionaryScreenState();
}

class _DictionaryScreenState extends State<DictionaryScreen> {
  late final List<Map<String, dynamic>> _all;
  String _q = '';

  bool get _isOxford => widget.dataKey == 'oxford';

  @override
  void initState() {
    super.initState();
    _all = repo.list(widget.dataKey);
    if (!_isOxford) {
      _all.sort((a, b) =>
          normalize(str(a['fa'])).compareTo(normalize(str(b['fa']))));
    }
  }

  @override
  Widget build(BuildContext context) {
    final nq = normalize(_q);
    final shown = nq.isEmpty
        ? _all
        : _all
            .where((w) => _isOxford
                ? normalize(
                        '${str(w['en'])} ${str(w['ex'])} ${str(w['fa'])} ${str(w['ur'])} ${str(w['ro'])}')
                    .contains(nq)
                : normalize(
                        '${str(w['fa'])} ${str(w['ur'])} ${str(w['ro'])} ${str(w['en'])} ${str(w['urRo'])}')
                    .contains(nq))
            .toList();
    final cs = Theme.of(context).colorScheme;
    final intro = _isOxford ? str(repo.data['oxfordIntro']) : '';
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _q = v),
              decoration: InputDecoration(
                hintText: _isOxford
                    ? 'لفظ تلاش کریں (انگریزی، فارسی یا اردو)'
                    : 'لفظ تلاش کریں (فارسی، اردو، انگریزی یا رومن)',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: cardFill(context),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          if (_isOxford && _q.isEmpty && intro.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 2, 16, 8),
              child: Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: AppColors.gold.withAlpha(38),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.gold.withAlpha(120)),
                ),
                child: Text(
                  intro,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: cs.onSurface),
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                '${localDigits(shown.length)} الفاظ',
                style: TextStyle(color: cs.outline, fontSize: 13),
              ),
            ),
          ),
          Expanded(
            child: shown.isEmpty
                ? const EmptyState(message: 'کوئی لفظ نہیں ملا۔')
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 24),
                    itemCount: shown.length,
                    itemBuilder: (context, i) {
                      final w = shown[i];
                      if (_isOxford) {
                        // حروفِ تہجی کی سرخیاں ہٹا دی گئیں (Ayesh کی ہدایت، 1 نومبر 2026)
                        return _OxfordCard(w: w);
                      }
                      final pos = str(w['pos']);
                      return PhraseCard(
                        fa: str(w['fa']),
                        ur: str(w['ur']),
                        tag: pos.isEmpty ? null : pos,
                        roman: str(w['ro']),
                        vocalized: str(w['v']),
                        en: str(w['en']),
                        urRo: str(w['urRo']),
                        aiWord: str(w['fa']),
                        words: w['w'] as List<dynamic>?,
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

/// آکسفورڈ لغت کا کارڈ: مخفف (انگریزی) + مکمل صورت + فارسی + اردو
class _OxfordCard extends StatelessWidget {
  final Map<String, dynamic> w;
  const _OxfordCard({required this.w});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final en = str(w['en']);
    final ex = str(w['ex']);
    final fa = str(w['fa']);
    final ur = str(w['ur']);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(16),
            blurRadius: 14,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => openOxfordDetail(context, w),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  textDirection: TextDirection.ltr,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  en,
                  style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                      color: enBodyColor(context)),
                ),
                if (ex.isNotEmpty) ...[
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      ex,
                      style: TextStyle(
                          fontSize: 16,
                          fontStyle: FontStyle.italic,
                          color: enBodyColor(context)),
                    ),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 8),
            Text(
              fa,
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.right,
              style: faStyle(size: 19, color: faBodyColor(context)),
            ),
            if (str(w['ro']).isNotEmpty) ...[
              const SizedBox(height: 2),
              Text(
                str(w['ro']),
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: 14,
                  fontStyle: FontStyle.italic,
                  fontWeight: FontWeight.w600,
                  color: romanBodyColor(context),
                ),
                textDirection: TextDirection.ltr,
              ),
            ],
            const SizedBox(height: 4),
                Text(
                  ur,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: urStyle(size: 17, color: urBodyColor(context)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// آکسفورڈ اندراج کی مکمل تفصیل: انگریزی لفظ، تلفظ و قسمِ کلام، فارسی معنی
/// (ہر فارسی لفظ ٹچ ایبل — اس کی اپنی گرامر تفصیل کھلتی ہے)، اردو معنی
/// (ہر اردو لفظ ٹچ ایبل) اور «مزید جانیں» — Ayesh کی ہدایت، 1 نومبر 2026۔
void openOxfordDetail(BuildContext context, Map<String, dynamic> w) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) => _OxfordDetailSheet(w: w),
  );
}

class _OxfordDetailSheet extends StatelessWidget {
  final Map<String, dynamic> w;
  const _OxfordDetailSheet({required this.w});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final en = str(w['en']);
    final ex = str(w['ex']);
    final fa = str(w['fa']);
    final ur = str(w['ur']);
    final text = [en, ex, fa, ur].where((s) => s.isNotEmpty).join('\n');
    return SafeArea(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 5,
                  margin: const EdgeInsets.only(bottom: 14),
                  decoration: BoxDecoration(
                    color: cs.outlineVariant,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
              Text(
                en,
                textDirection: TextDirection.ltr,
                textAlign: TextAlign.left,
                style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: enBodyColor(context)),
              ),
              if (ex.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    ex,
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                        fontSize: 16.5,
                        fontStyle: FontStyle.italic,
                        color: enBodyColor(context)),
                  ),
                ),
              if (fa.isNotEmpty) ...[
                const SizedBox(height: 16),
                Text('فارسی معنی',
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: cs.primary)),
                const SizedBox(height: 6),
                WordTapText(fa: fa, style: faStyle(size: 20)),
              ],
              const SizedBox(height: 14),
              Text('اردو معنی',
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: cs.primary)),
              const SizedBox(height: 6),
              if (ur.isNotEmpty)
                UrduTapText(ur: ur, style: urStyle(size: 18))
              else
                Text('ابھی شامل نہیں',
                    style: urStyle(size: 16, color: cs.outline)),
              if (en.isNotEmpty) ...[
                const SizedBox(height: 16),
                LearnMoreChips(word: en),
              ],
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  IconButton(
                    tooltip: 'کاپی',
                    icon: const Icon(Icons.copy_rounded),
                    onPressed: () => copyText(context, text),
                  ),
                  IconButton(
                    tooltip: 'شیئر',
                    icon: const Icon(Icons.ios_share_rounded),
                    onPressed: () => shareText(text),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
