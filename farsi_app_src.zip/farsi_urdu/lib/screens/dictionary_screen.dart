import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';

/// لغت: فارسی ↔ اردو، تلاش کے خانے کے ساتھ
class DictionaryScreen extends StatefulWidget {
  const DictionaryScreen({super.key});

  @override
  State<DictionaryScreen> createState() => _DictionaryScreenState();
}

class _DictionaryScreenState extends State<DictionaryScreen> {
  late final List<Map<String, dynamic>> _all;
  String _q = '';

  @override
  void initState() {
    super.initState();
    _all = repo.list('dictionary')
      ..sort((a, b) =>
          normalize(str(a['fa'])).compareTo(normalize(str(b['fa']))));
  }

  @override
  Widget build(BuildContext context) {
    final nq = normalize(_q);
    final shown = nq.isEmpty
        ? _all
        : _all
            .where((w) =>
                normalize('${str(w['fa'])} ${str(w['ur'])}').contains(nq))
            .toList();
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('لغت')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _q = v),
              decoration: InputDecoration(
                hintText: 'لفظ تلاش کریں (فارسی یا اردو)',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: cardFill(context),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                '${localDigits(shown.length)} الفاظ',
                style: TextStyle(color: cs.outline, fontSize: 13),
              ),
            ),
          ),
          Expanded(
            child: shown.isEmpty
                ? const EmptyState(message: 'کوئی لفظ نہیں ملا۔')
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 24),
                    itemCount: shown.length,
                    itemBuilder: (context, i) {
                      final w = shown[i];
                      final pos = str(w['pos']);
                      return PhraseCard(
                        fa: str(w['fa']),
                        ur: str(w['ur']),
                        tag: pos.isEmpty ? null : pos,
                        roman: str(w['ro']),
                        vocalized: str(w['v']),
                        words: w['w'] as List<dynamic>?,
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
