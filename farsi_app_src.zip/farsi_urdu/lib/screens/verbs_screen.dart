import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';
import '../widgets/detail_sheet.dart';
import 'collection_screen.dart';

const _pronUr = {
  'من': 'میں',
  'تو': 'تو / تم',
  'او': 'وہ',
  'ما': 'ہم',
  'شما': 'آپ / تم',
  'آن\u200Cها': 'وہ سب',
};

/// گردان کے زمانوں کے انگریزی نام (Ayesh کی ہدایت — مصادر کے شروع میں زمانوں کی فہرست)
const _tenseEn = {
  'ماضی مطلق': 'Simple Past',
  'ماضی استمراری': 'Past Continuous',
  'ماضی نقلی استمراری': 'Present Perfect Continuous',
  'ماضی قریب': 'Present Perfect',
  'ماضی بعید': 'Past Perfect',
  'ماضی احتمالی': 'Probable Past',
  'مضارع التزامی': 'Present Subjunctive',
  'حال اخباری': 'Simple Present',
  'حال جاری': 'Present Continuous',
  'مستقبل': 'Simple Future',
  'امر': 'Imperative',
  'نہی': 'Prohibitive (Negative Imperative)',
  'ماضی سادہ': 'Simple Past',
  'مضارع سادہ': 'Present Subjunctive',
};

String tenseEn(String name) => _tenseEn[name] ?? '';

/// گرامر کے موضوعات میں کسی نام سے ملتا موضوع تلاش کرو (نہ ملے تو null)۔
/// پہلے بعینہٖ عنوان، پھر «—» سے پہلا حصہ، پھر جانے پہچانے متبادل ربط آزمائے جاتے ہیں۔
Map<String, dynamic>? grammarTopicFor(String name) {
  final topics = repo.list('grammar');
  if (topics.isEmpty || name.trim().isEmpty) return null;
  final byTitle = <String, Map<String, dynamic>>{};
  for (final t in topics) {
    final title = str(t['title']);
    if (title.isNotEmpty) byTitle[normalize(title)] = t;
  }
  Map<String, dynamic>? exact(String s) => byTitle[normalize(s)];

  final base = name.split('—').first.trim();
  for (final cand in {name, base}) {
    final hit = exact(cand);
    if (hit != null) return hit;
  }
  const aliasRaw = <String, List<String>>{
    'ماضی مطلق': ['ماضی سادہ'],
    'ماضی قریب': ['ماضی نقلی'],
    'ماضی نقلی استمراری': ['ماضی نقلی'],
    'ماضی': ['ماضی مطلق', 'ماضی سادہ'],
    'مضارع سادہ': ['مضارع التزامی'],
    'حال اخباری': ['مضارع اخباری'],
    'حال': ['مضارع اخباری'],
    'حال جاری': ['حال استمراری'],
  };
  final alias = <String, List<String>>{
    for (final e in aliasRaw.entries) normalize(e.key): e.value,
  };
  for (final target in alias[normalize(base)] ?? const <String>[]) {
    final hit = exact(target);
    if (hit != null) return hit;
  }
  // پرانا عنوان «فعل حال: می‌ + مادہ + شناسہ» — مضارع/حال کے گروہوں کے لیے
  final n = normalize(base);
  if (n == normalize('مضارع اخباری') ||
      n == normalize('حال اخباری') ||
      n == normalize('حال')) {
    final needle = normalize('فعل حال');
    for (final t in topics) {
      if (normalize(str(t['title'])).contains(needle)) return t;
    }
  }
  return null;
}

/// متعلقہ گرامر موضوع کھولو (نہ ملے تو خاموشی — کوئی crash نہیں)
void openGrammarTopic(BuildContext context, String name) {
  final topic = grammarTopicFor(name);
  if (topic == null) return;
  Navigator.of(context).push(
    MaterialPageRoute(builder: (_) => TextDetailScreen(item: topic)),
  );
}

Map<String, Map<String, dynamic>>? _dictByFa;

/// لغت (dictionary) میں لفظ تلاش کرو — اعراب اور حروف کی یکسانیت کے ساتھ
Map<String, dynamic>? dictEntryFor(String fa) {
  final word = fa.trim();
  if (word.isEmpty) return null;
  final cache = _dictByFa ??= <String, Map<String, dynamic>>{
    for (final w in repo.list('dictionary'))
      if (str(w['fa']).isNotEmpty) normalize(str(w['fa'])): w,
  };
  return cache[normalize(word)];
}

/// مشتق / مترادف / متضاد لفظ کی معیاری تفصیل شیٹ کھولو:
/// لفظ لغت میں موجود ہو تو اس کے مکمل اندراج (اعراب، رومن، لفظی تجزیہ) سے،
/// ورنہ لفظ کے اپنے ڈیٹا سے۔
void openWordDetail(
  BuildContext context,
  Map<String, dynamic> word, {
  String? tag,
}) {
  final entry = dictEntryFor(str(word['fa']));
  if (entry != null) {
    final pos = str(entry['pos']);
    openDetail(
      context,
      fa: str(entry['fa']),
      ur: str(entry['ur']),
      vocalized: str(entry['v']),
      roman: str(entry['ro']),
      en: str(entry['en']),
      urRoman: str(entry['urRo']),
      aiWord: str(entry['fa']),
      words: entry['w'] as List<dynamic>?,
      tag: tag ?? (pos.isEmpty ? null : pos),
    );
    return;
  }
  openDetail(
    context,
    fa: str(word['fa']),
    ur: str(word['ur']),
    vocalized: str(word['v']),
    roman: str(word['ro']),
    urRoman: str(word['urRo']),
    aiWord: str(word['fa']),
    tag: tag,
  );
}

/// گردان کی ایک صورت کی تفصیل شیٹ — نیچے اس گروہ کے گرامر موضوع کا لنک
void openFormDetail(
  BuildContext context,
  Map<String, dynamic> form0,
  String groupName,
) {
  final topic = grammarTopicFor(groupName);
  var form = form0;
  final segs0 = asMaps(form['segs']);
  if (segs0.isNotEmpty) {
    final sg = segs0.first;
    form = {
      ...form,
      'p': str(form['fa']),
      'fa': str(sg['fa']),
      'ro': str(sg['ro']),
      'u': str(sg['u']),
      'uRo': str(sg['uRo']),
    };
  }
  final pron = str(form['p']);
  final pronUr = _pronUr[pron] ?? '';
  final tag = pron.isEmpty
      ? groupName
      : '$groupName · $pron${pronUr.isEmpty ? '' : ' · $pronUr'}';
  openDetail(
    context,
    fa: str(form['fa']),
    ur: str(form['u']),
    roman: str(form['ro']),
    urRoman: str(form['uRo']),
    tag: tag,
    footer: topic == null
        ? null
        : OutlinedButton.icon(
            onPressed: () => openGrammarTopic(context, groupName),
            icon: const Icon(Icons.menu_book_rounded, size: 19),
            label: Text('گرامر: ${str(topic['title'])}'),
          ),
  );
}

class _TensesCard extends StatelessWidget {
  const _TensesCard();

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    const order = [
      'ماضی مطلق', 'ماضی استمراری', 'ماضی ملموس', 'ماضی قریب',
      'ماضی بعید', 'ماضی بعید نقلی', 'ماضی نقلی استمراری',
      'ماضی بعید استمراری', 'ماضی احتمالی', 'ماضی التزامی',
      'حال اخباری', 'حال جاری', 'مضارع التزامی', 'مستقبل',
      'مستقبل قریب', 'امر', 'نہی',
    ];
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
      ),
      child: ExpansionTile(
        title: Text(
          'گردان کے زمانے',
          style: TextStyle(
            fontSize: 16.5,
            fontWeight: FontWeight.w800,
            color: cs.primary,
          ),
        ),
        subtitle: const Text(
          'Tenses used in these conjugations',
          textDirection: TextDirection.ltr,
          textAlign: TextAlign.left,
          style: TextStyle(fontSize: 12.5),
        ),
        children: [
          for (final t in order)
            InkWell(
              onTap: grammarTopicFor(t) == null
                  ? null
                  : () => openGrammarTopic(context, t),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 3, 18, 3),
                child: Row(
                  children: [
                    Expanded(child: Text(t, style: urStyle(size: 15.5))),
                    if (grammarTopicFor(t) != null)
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Icon(
                          Icons.menu_book_rounded,
                          size: 16,
                          color: goldAccentColor(context),
                        ),
                      ),
                    Text(
                      _tenseEn[t] ?? '',
                      textDirection: TextDirection.ltr,
                      style: TextStyle(
                        fontSize: 13.5,
                        color: romanBodyColor(context),
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}


/// مصادر و گردان: فارسی افعال، ان کے بن اور مکمل گردان — تلاش کے ساتھ
/// ڈیٹا کی شکل: [{fa, v, ro, ur, past, pres, groups: [{name, forms: [{p, fa, ro}]}]}]
class VerbsScreen extends StatefulWidget {
  const VerbsScreen({super.key});

  @override
  State<VerbsScreen> createState() => _VerbsScreenState();
}

class _VerbsScreenState extends State<VerbsScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final verbs = repo.list('verbs');
    final cs = Theme.of(context).colorScheme;
    final nq = normalize(_q);
    final shown = nq.isEmpty
        ? verbs
        : verbs
            .where((v) => normalize(
                    '${str(v['fa'])} ${str(v['ur'])} ${str(v['past'])} ${str(v['pres'])} ${str(v['ro'])}')
                .contains(nq))
            .toList();
    return Scaffold(
      appBar: AppBar(title: const Text('مصادر و گردان')),
      body: verbs.isEmpty
          ? const EmptyState(
              message: 'ابھی مصادر شامل نہیں۔\nآن لائن اپڈیٹ سے نیا مواد حاصل کریں۔')
          : Column(
              children: [
                SearchBox(
                  hint: 'مصدر تلاش کریں (فارسی یا اردو)…',
                  onChanged: (v) => setState(() => _q = v),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 4),
                  child: Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Text(
                      '${localDigits(shown.length)} مصادر — کسی مصدر پر ٹیپ کریں، اس کی پوری گردان کھل جائے گی',
                      style: TextStyle(color: cs.outline, fontSize: 13),
                    ),
                  ),
                ),
                Expanded(
                  child: shown.isEmpty
                      ? const EmptyState(message: 'کوئی مصدر نہیں ملا۔')
                      : ListView.builder(
                          padding: const EdgeInsets.only(bottom: 24),
                          itemCount: shown.length + 1,
                          itemBuilder: (context, i) {
                            if (i == 0) return const _TensesCard();
                            final v = shown[i - 1];
                            return _VerbCard(verb: v);
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

class _VerbCard extends StatelessWidget {
  final Map<String, dynamic> verb;
  const _VerbCard({required this.verb});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final vocal = str(verb['v']);
    final faShown = vocal.isNotEmpty ? vocal : str(verb['fa']);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(16),
            blurRadius: 14,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => VerbDetailScreen(verb: verb)),
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(faShown, style: faStyle(size: 22)),
                    ),
                    Expanded(
                      child: Text(
                        str(verb['ur']),
                        style: urStyle(color: urBodyColor(context)),
                      ),
                    ),
                  ],
                ),
                if (str(verb['ro']).isNotEmpty)
                  Text(
                    str(verb['ro']),
                    style: TextStyle(
                      fontSize: 13.5,
                      color: romanBodyColor(context),
                      fontStyle: FontStyle.italic,
                    ),
                    textDirection: TextDirection.ltr,
                  ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  children: [
                    _stemChip(context, 'بنِ ماضی: ${str(verb['past'])}'),
                    _stemChip(context, 'بنِ مضارع: ${str(verb['pres'])}'),
                    if (str(verb['tr']).isNotEmpty)
                      _trChip(context, str(verb['tr'])),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _stemChip(BuildContext context, String label) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        color: cs.primary.withAlpha(26),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label,
          style: TextStyle(
              fontSize: 13, color: cs.primary, fontWeight: FontWeight.w700)),
    );
  }

  Widget _trChip(BuildContext context, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        color: goldAccentColor(context).withAlpha(40),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label,
          style: TextStyle(
              fontSize: 13,
              color: goldAccentColor(context),
              fontWeight: FontWeight.w700)),
    );
  }
}

/// گردان کے گروہ کی سرخی — متعلقہ گرامر موضوع موجود ہو تو ٹیپ پر وہ کھلتا ہے
class _GroupHeader extends StatelessWidget {
  final String name;
  const _GroupHeader({required this.name});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final topic = grammarTopicFor(name);
    final en = tenseEn(name);
    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Text(
                name,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: cs.primary,
                ),
              ),
            ),
            if (topic != null)
              Icon(
                Icons.menu_book_rounded,
                size: 19,
                color: goldAccentColor(context),
              ),
          ],
        ),
        if (en.isNotEmpty)
          Text(
            en,
            textDirection: TextDirection.ltr,
            textAlign: TextAlign.left,
            style: TextStyle(
              fontSize: 13,
              color: romanBodyColor(context),
              fontStyle: FontStyle.italic,
            ),
          ),
      ],
    );
    if (topic == null) return content;
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () => openGrammarTopic(context, name),
      child: content,
    );
  }
}

/// مشتقات / مترادفات / متضاد کی ایک سطر — ٹیپ پر معیاری تفصیل شیٹ کھلتی ہے
class _WordRow extends StatelessWidget {
  final Map<String, dynamic> word;
  final String? fixedTag;
  final bool showType;
  const _WordRow({required this.word, this.fixedTag, this.showType = true});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final type = str(word['t']);
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => openWordDetail(
            context,
            word,
            tag: fixedTag ?? (type.isEmpty ? null : type),
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (showType && type.isNotEmpty)
                  Text(
                    type,
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700,
                      color: cs.primary,
                    ),
                  ),
                Text(
                  str(word['v']).isNotEmpty ? str(word['v']) : str(word['fa']),
                  style: faStyle(size: 20),
                ),
                if (str(word['ro']).isNotEmpty)
                  Text(
                    str(word['ro']),
                    style: TextStyle(
                      fontSize: 13,
                      color: romanBodyColor(context),
                      fontStyle: FontStyle.italic,
                    ),
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.left,
                  ),
                if (str(word['ur']).isNotEmpty)
                  Text(
                    str(word['ur']),
                    style: urStyle(size: 15.5, color: urBodyColor(context)),
                  ),
                if (str(word['urRo']).isNotEmpty)
                  Text(
                    str(word['urRo']),
                    style: TextStyle(
                      fontSize: 12.5,
                      color: romanBodyColor(context),
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.w600,
                    ),
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.left,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// متعدی/لازم بیج (تفصیل کے سرنامے میں) — ٹیپ پر «متعدی و لازم افعال» کا
/// گرامر موضوع کھلتا ہے؛ موضوع نہ ملے تو کچھ نہیں ہوتا
class _TrBadge extends StatelessWidget {
  final String value;
  const _TrBadge({required this.value});

  @override
  Widget build(BuildContext context) {
    final gold = goldAccentColor(context);
    return Material(
      color: gold.withAlpha(36),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => openGrammarTopic(context, 'متعدی و لازم افعال'),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.menu_book_rounded, size: 15, color: gold),
              const SizedBox(width: 6),
              Text(
                value,
                style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// گردان کی ایک صورت کا کشادہ کارڈ: ضمیر، فارسی صورت، رومن اور اردو ترجمہ
/// ٹیپ کرنے پر صورت کی تفصیل شیٹ کھلتی ہے (نیچے گرامر موضوع کا لنک بھی)
class _FormCard extends StatelessWidget {
  final Map<String, dynamic> form;
  final String groupName;
  const _FormCard({required this.form, required this.groupName});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    // نئی ساخت (segs) ہو تو اصل صورت و ترجمہ seg سے لو؛ ضمیر فارم کے fa میں ہے
    final segs = asMaps(form['segs']);
    final Map<String, dynamic> eff = segs.isEmpty
        ? form
        : {
            ...form,
            'p': str(form['fa']),
            'fa': str(segs.first['fa']),
            'ro': str(segs.first['ro']),
            'u': str(segs.first['u']),
            'uRo': str(segs.first['uRo']),
          };
    final pron = str(eff['p']);
    final pronLabel = '$pron · ${_pronUr[pron] ?? ''}';
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(12),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => openFormDetail(context, eff, groupName),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(
                        color: AppColors.gold.withAlpha(45),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        pronLabel,
                        style: const TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w700),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(str(eff['fa']), style: faStyle(size: 22)),
                    ),
                  ],
                ),
                if (str(eff['ro']).isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      str(eff['ro']),
                      style: TextStyle(
                        fontSize: 13.5,
                        color: romanBodyColor(context),
                        fontStyle: FontStyle.italic,
                      ),
                      textDirection: TextDirection.ltr,
                    ),
                  ),
                if (str(eff['u']).isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      str(eff['u']),
                      style: urStyle(size: 17, color: urBodyColor(context)),
                    ),
                  ),
                if (str(eff['uRo']).isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 1),
                    child: Text(
                      str(eff['uRo']),
                      style: TextStyle(
                        fontSize: 12.5,
                        color: romanBodyColor(context),
                        fontStyle: FontStyle.italic,
                        fontWeight: FontWeight.w600,
                      ),
                      textDirection: TextDirection.ltr,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// ایک مصدر کی مکمل گردان: ماضی، حال، مستقبل، امر
class VerbDetailScreen extends StatelessWidget {
  final Map<String, dynamic> verb;
  const VerbDetailScreen({super.key, required this.verb});

  String _fullText() {
    final b = StringBuffer()
      ..writeln('${str(verb['fa'])} — ${str(verb['ur'])}');
    if (str(verb['tr']).isNotEmpty) {
      b.writeln('قسم: ${str(verb['tr'])}');
    }
    b.writeln(
        'بنِ ماضی: ${str(verb['past'])} · بنِ مضارع: ${str(verb['pres'])}');
    if (asMaps(verb['derivs']).isNotEmpty) {
      b.writeln('مشتقات:');
      for (final dv in asMaps(verb['derivs'])) {
        b.writeln(
            '${str(dv['t'])}: ${str(dv['fa'])} (${str(dv['ro'])}) — ${str(dv['ur'])}');
      }
    }
    if (str(verb['deriv']).isNotEmpty) {
      b.writeln('اضافی تفصیل: ${str(verb['deriv'])}');
    }
    if (str(verb['note']).isNotEmpty) {
      b.writeln('نوٹ: ${str(verb['note'])}');
    }
    if (asMaps(verb['syn']).isNotEmpty) {
      b.writeln('مترادفات:');
      for (final w in asMaps(verb['syn'])) {
        b.writeln('${str(w['fa'])} (${str(w['ro'])}) — ${str(w['ur'])}');
      }
    }
    if (asMaps(verb['ant']).isNotEmpty) {
      b.writeln('متضاد الفاظ:');
      for (final w in asMaps(verb['ant'])) {
        b.writeln('${str(w['fa'])} (${str(w['ro'])}) — ${str(w['ur'])}');
      }
    }
    for (final g in asMaps(verb['groups'])) {
      b.writeln('\n${str(g['name'])}');
      for (final f in asMaps(g['forms'])) {
        final sg = asMaps(f['segs']);
        if (sg.isNotEmpty) {
          b.writeln(
              '${str(f['fa'])}: ${str(sg.first['fa'])} — ${str(sg.first['u'])}');
        } else {
          b.writeln('${str(f['p'])}: ${str(f['fa'])} — ${str(f['u'])}');
        }
      }
    }
    return b.toString();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final vocal = str(verb['v']);
    final faShown = vocal.isNotEmpty ? vocal : str(verb['fa']);
    final groups = asMaps(verb['groups']);
    return Scaffold(
      appBar: AppBar(
        title: Text(str(verb['fa'])),
        actions: [
          IconButton(
            tooltip: 'کاپی',
            icon: const Icon(Icons.copy_rounded),
            onPressed: () => copyText(context, _fullText()),
          ),
          IconButton(
            tooltip: 'شیئر',
            icon: const Icon(Icons.ios_share_rounded),
            onPressed: () => shareText(_fullText()),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: cardFill(context),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: cs.outlineVariant.withAlpha(110)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(faShown, style: faStyle(size: 30)),
                if (str(verb['ro']).isNotEmpty)
                  Text(
                    str(verb['ro']),
                    style: TextStyle(
                      fontSize: 15,
                      color: romanBodyColor(context),
                      fontStyle: FontStyle.italic,
                    ),
                    textDirection: TextDirection.ltr,
                  ),
                const SizedBox(height: 6),
                Text(str(verb['ur']),
                    style: urStyle(
                        size: 18, color: urBodyColor(context))),
                if (str(verb['urRo']).isNotEmpty) ...[
                  const SizedBox(height: 1),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      str(verb['urRo']),
                      style: TextStyle(
                          fontSize: 13.5,
                          fontStyle: FontStyle.italic,
                          fontWeight: FontWeight.w600,
                          color: romanBodyColor(context)),
                      textDirection: TextDirection.ltr,
                      textAlign: TextAlign.left,
                    ),
                  ),
                ],
                if (str(verb['en']).isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      str(verb['en']),
                      style: TextStyle(
                          fontSize: 14.5,
                          fontStyle: FontStyle.italic,
                          color: enBodyColor(context)),
                      textDirection: TextDirection.ltr,
                      textAlign: TextAlign.left,
                    ),
                  ),
                ],
                if (str(verb['tr']).isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: _TrBadge(value: str(verb['tr'])),
                  ),
                ],
                const Divider(height: 26),
                _stemRow(context, 'بنِ ماضی', str(verb['past']),
                    str(verb['pastRo'])),
                const SizedBox(height: 6),
                _stemRow(context, 'بنِ مضارع', str(verb['pres']),
                    str(verb['presRo'])),
                const SizedBox(height: 8),
                Text(
                  'ماضی بنِ ماضی سے اور حال بنِ مضارع سے بنتا ہے۔ نیچے اسی مصدر کی مکمل گردان دی گئی ہے۔',
                  style: TextStyle(color: cs.outline, fontSize: 13.5),
                ),
              ],
            ),
          ),
          if (asMaps(verb['derivs']).isNotEmpty) ...[
            _sectionTitle(context, 'مشتقات'),
            ..._derivGroups(context, asMaps(verb['derivs'])),
          ],
          if (str(verb['deriv']).isNotEmpty) ...[
            _sectionTitle(context, 'اضافی تفصیل'),
            _textCard(context, str(verb['deriv'])),
          ],
          if (str(verb['note']).isNotEmpty) ...[
            _sectionTitle(context, 'نوٹ'),
            _textCard(context, str(verb['note'])),
          ],
          if (asMaps(verb['syn']).isNotEmpty) ...[
            _sectionTitle(context, 'مترادفات'),
            for (final w in asMaps(verb['syn']))
              _WordRow(word: w, fixedTag: 'مترادف'),
          ],
          if (asMaps(verb['ant']).isNotEmpty) ...[
            _sectionTitle(context, 'متضاد الفاظ'),
            for (final w in asMaps(verb['ant']))
              _WordRow(word: w, fixedTag: 'متضاد'),
          ],
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: LearnMoreChips(word: str(verb['fa'])),
          ),
          for (final g in groups) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 22, 6, 10),
              child: _GroupHeader(name: str(g['name'])),
            ),
            for (final f in asMaps(g['forms']))
              _FormCard(form: f, groupName: str(g['name'])),
          ],
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: () => openFeedback(context, _fullText()),
            icon: const Icon(Icons.edit_note_rounded),
            label: const Text('تصحیح / اضافے کی تجویز'),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(BuildContext context, String title) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(6, 22, 6, 10),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: cs.primary,
        ),
      ),
    );
  }

  /// مشتقات کی قسم (اسم فاعل، اسم مفعول، اسم مرکب…) کی ذیلی سرخی
  Widget _subTitle(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(6, 12, 6, 6),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 15.5,
          fontWeight: FontWeight.w700,
          color: goldAccentColor(context),
        ),
      ),
    );
  }

  /// مشتقات کو ان کی قسم کے مطابق الگ الگ حصوں میں ترتیب دو —
  /// قسمیں جس ترتیب سے ڈیٹا میں پہلے آئیں اسی ترتیب سے دکھتی ہیں؛
  /// بغیر قسم والے «دیگر» میں جاتے ہیں۔ ہر لفظ بدستور ٹیپ ایبل رہتا ہے۔
  List<Widget> _derivGroups(
      BuildContext context, List<Map<String, dynamic>> derivs) {
    final order = <String>[];
    final byType = <String, List<Map<String, dynamic>>>{};
    for (final dv in derivs) {
      final t = str(dv['t']).trim();
      final key = t.isEmpty ? 'دیگر' : t;
      if (!byType.containsKey(key)) {
        byType[key] = <Map<String, dynamic>>[];
        order.add(key);
      }
      byType[key]!.add(dv);
    }
    return [
      for (final t in order) ...[
        _subTitle(context, t),
        for (final dv in byType[t]!) _WordRow(word: dv, showType: false),
      ],
    ];
  }

  /// سادہ متن کا کارڈ (deriv متن، نوٹ، اشعار وغیرہ اضافی مواد کے لیے)
  Widget _textCard(BuildContext context, String text) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
      ),
      child: SelectableText(
        text,
        style: const TextStyle(fontSize: 16, height: 1.9),
      ),
    );
  }

  Widget _stemRow(
      BuildContext context, String label, String fa, String ro) {
    final cs = Theme.of(context).colorScheme;
    return Row(
      children: [
        SizedBox(
          width: 92,
          child: Text(label,
              style: TextStyle(color: cs.outline, fontSize: 14.5)),
        ),
        Text(fa, style: faStyle(size: 20)),
        const SizedBox(width: 10),
        Text(
          ro,
          style: TextStyle(
            fontSize: 13.5,
            color: romanBodyColor(context),
            fontStyle: FontStyle.italic,
          ),
          textDirection: TextDirection.ltr,
        ),
      ],
    );
  }
}
