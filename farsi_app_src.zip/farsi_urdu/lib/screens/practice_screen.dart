import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/repository.dart';
import '../theme.dart';

/// ایک سوال
class _Q {
  final String type; // a,b,c,d,e
  final String typeLabel;
  final String prompt;
  final bool promptFa; // true ہو تو فارسی انداز میں دکھاؤ
  final String? hint; // اضافی ہدایت (مثلاً جملے کا ترجمہ بطور اشارہ)
  final List<String> options;
  final bool optionsFa;
  final int correct;
  final String review; // نتیجے کے لیے: سوال + درست جواب کی سطر

  const _Q({
    required this.type,
    required this.typeLabel,
    required this.prompt,
    required this.promptFa,
    this.hint,
    required this.options,
    required this.optionsFa,
    required this.correct,
    required this.review,
  });
}

/// مشق و کھیل: ایپ کے اپنے مواد (لغت، جملے، گردان) سے خودکار سوالات،
/// سطح/پوائنٹس کا بڑھتا ہوا نظام اور ۶۰ سیکنڈ کا دماغی امتحان۔
class PracticeScreen extends StatefulWidget {
  const PracticeScreen({super.key});

  @override
  State<PracticeScreen> createState() => _PracticeScreenState();
}

class _PracticeScreenState extends State<PracticeScreen> {
  final _rand = Random();

  // ڈیٹا کے ذخیرے
  late final List<Map<String, dynamic>> _dict;
  late final List<Map<String, dynamic>> _sents;
  late final List<Map<String, dynamic>> _sentsW;
  late final List<Map<String, dynamic>> _verbs;

  // محفوظ پیش رفت
  int _points = 0;
  int _bestStreak = 0;
  int _examBest = 0;
  final Map<String, List<int>> _typeStats = {}; // type -> [درست, غلط]

  // موجودہ کھیل
  String _mode = 'menu'; // menu | practice | exam | result
  _Q? _q;
  int _selected = -1;
  bool _answered = false;
  int _streak = 0;
  int _sessionCorrect = 0;
  int _sessionWrong = 0;

  // امتحان
  Timer? _timer;
  int _secondsLeft = 60;
  int _examCorrect = 0;
  int _examWrong = 0;
  final List<String> _mistakes = [];
  bool _examLock = false;

  int get _level => 1 + (_points ~/ 150);

  @override
  void initState() {
    super.initState();
    _dict = repo
        .list('dictionary')
        .where((e) => str(e['fa']).isNotEmpty && str(e['ur']).isNotEmpty)
        .toList();
    _sents = repo
        .list('sentences')
        .where((e) => str(e['fa']).isNotEmpty && str(e['ur']).isNotEmpty)
        .toList();
    _sentsW = _sents.where((e) {
      final w = e['w'];
      return w is List && w.isNotEmpty;
    }).toList();
    _verbs = repo
        .list('verbs')
        .where((e) => asMaps(e['groups']).isNotEmpty)
        .toList();
    _loadProgress();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // ------------------------- محفوظ پیش رفت -------------------------

  Future<void> _loadProgress() async {
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString('practice_v1');
      if (raw != null) {
        final m = json.decode(raw) as Map<String, dynamic>;
        _points = (m['points'] as num?)?.toInt() ?? 0;
        _bestStreak = (m['bestStreak'] as num?)?.toInt() ?? 0;
        _examBest = (m['examBest'] as num?)?.toInt() ?? 0;
        final ts = m['typeStats'];
        if (ts is Map) {
          ts.forEach((k, v) {
            if (v is List && v.length >= 2) {
              _typeStats['$k'] = [
                (v[0] as num).toInt(),
                (v[1] as num).toInt(),
              ];
            }
          });
        }
      }
    } catch (_) {}
    if (mounted) setState(() {});
  }

  Future<void> _saveProgress() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(
        'practice_v1',
        json.encode({
          'points': _points,
          'bestStreak': _bestStreak,
          'examBest': _examBest,
          'typeStats': _typeStats,
        }),
      );
    } catch (_) {}
  }

  void _record(String type, bool ok) {
    final s = _typeStats.putIfAbsent(type, () => [0, 0]);
    if (ok) {
      s[0]++;
    } else {
      s[1]++;
    }
    _saveProgress();
  }

  // ------------------------- سوال سازی -------------------------

  /// سطح کے مطابق دستیاب سوالوں کی اقسام
  List<String> _availableTypes() {
    final lv = _level;
    final types = <String>['a', 'b'];
    if (lv >= 2 && _sents.isNotEmpty) types.add('c');
    if (lv >= 3 && _verbs.isNotEmpty) types.add('d');
    if (lv >= 4 && _sentsW.isNotEmpty) types.add('e');
    return types;
  }

  /// کمزور ترین قسم (جس میں غلطیاں زیادہ ہوں)
  String? _weakestType(List<String> avail) {
    String? worst;
    var worstRate = 0.25;
    for (final t in avail) {
      final s = _typeStats[t];
      if (s == null) continue;
      final total = s[0] + s[1];
      if (total < 3) continue;
      final rate = s[1] / total;
      if (rate > worstRate) {
        worstRate = rate;
        worst = t;
      }
    }
    return worst;
  }

  String _pickType() {
    final avail = _availableTypes();
    // کمزور قسم کو دوبارہ لانے کا رجحان
    final weak = _weakestType(avail);
    if (weak != null && _rand.nextDouble() < 0.45) return weak;
    return avail[_rand.nextInt(avail.length)];
  }

  List<String> _distractors(List<String> pool, String correct, int n) {
    final out = <String>{};
    var guard = 0;
    while (out.length < n && guard++ < 60 && pool.isNotEmpty) {
      final c = pool[_rand.nextInt(pool.length)];
      if (c.isNotEmpty && c != correct) out.add(c);
    }
    return out.toList();
  }

  _Q? _makeQ(String type) {
    try {
      switch (type) {
        case 'a':
          return _genFaToUr();
        case 'b':
          return _genUrToFa();
        case 'c':
          return _genSentence();
        case 'd':
          return _genVerb();
        case 'e':
          return _genBlank();
      }
    } catch (_) {}
    return null;
  }

  _Q? _genFaToUr() {
    if (_dict.length < 4) return null;
    // ابتدائی سطح پر فہرست کے پہلے (عام) حصے سے، بعد میں پورے ذخیرے سے
    final pool = _level >= 4 ? _dict : _dict.take(max(4, _dict.length ~/ 2)).toList();
    final e = pool[_rand.nextInt(pool.length)];
    final fa = str(e['fa']);
    final ur = str(e['ur']);
    final pos = str(e['pos']);
    var others = _dict
        .where((x) => pos.isEmpty || str(x['pos']) == pos)
        .map((x) => str(x['ur']))
        .toList();
    if (others.length < 4) others = _dict.map((x) => str(x['ur'])).toList();
    final ds = _distractors(others, ur, 3);
    if (ds.length < 3) return null;
    final opts = [...ds, ur]..shuffle(_rand);
    final shown = str(e['v']).isNotEmpty ? str(e['v']) : fa;
    return _Q(
      type: 'a',
      typeLabel: 'لفظ کا معنی',
      prompt: shown,
      promptFa: true,
      options: opts,
      optionsFa: false,
      correct: opts.indexOf(ur),
      review: '«$fa» کا درست معنی: $ur',
    );
  }

  _Q? _genUrToFa() {
    if (_dict.length < 4) return null;
    final pool = _level >= 4 ? _dict : _dict.take(max(4, _dict.length ~/ 2)).toList();
    final e = pool[_rand.nextInt(pool.length)];
    final fa = str(e['fa']);
    final ur = str(e['ur']);
    final ds = _distractors(_dict.map((x) => str(x['fa'])).toList(), fa, 3);
    if (ds.length < 3) return null;
    final opts = [...ds, fa]..shuffle(_rand);
    return _Q(
      type: 'b',
      typeLabel: 'معنی سے لفظ',
      prompt: ur,
      promptFa: false,
      options: opts,
      optionsFa: true,
      correct: opts.indexOf(fa),
      review: '«$ur» کے لیے درست فارسی لفظ: $fa',
    );
  }

  _Q? _genSentence() {
    if (_sents.length < 4) return null;
    // اونچی سطح پر لمبے جملے زیادہ
    var pool = _sents;
    if (_level >= 4) {
      final longs = _sents.where((s) => str(s['fa']).length > 25).toList();
      if (longs.length >= 4) pool = longs;
    } else if (_level <= 2) {
      final shorts = _sents.where((s) => str(s['fa']).length <= 30).toList();
      if (shorts.length >= 4) pool = shorts;
    }
    final e = pool[_rand.nextInt(pool.length)];
    final fa = str(e['fa']);
    final ur = str(e['ur']);
    final ds = _distractors(_sents.map((x) => str(x['ur'])).toList(), ur, 3);
    if (ds.length < 3) return null;
    final opts = [...ds, ur]..shuffle(_rand);
    return _Q(
      type: 'c',
      typeLabel: 'جملے کا ترجمہ',
      prompt: fa,
      promptFa: true,
      options: opts,
      optionsFa: false,
      correct: opts.indexOf(ur),
      review: '«$fa» کا درست ترجمہ: $ur',
    );
  }

  _Q? _genVerb() {
    if (_verbs.isEmpty) return null;
    for (var attempt = 0; attempt < 12; attempt++) {
      final v = _verbs[_rand.nextInt(_verbs.length)];
      final groups = asMaps(v['groups'])
          .where((g) => asMaps(g['forms']).length >= 2)
          .toList();
      if (groups.isEmpty) continue;
      final g = groups[_rand.nextInt(groups.length)];
      final forms = asMaps(g['forms'])
          .where((f) => str(f['fa']).isNotEmpty)
          .toList();
      if (forms.isEmpty) continue;
      final target = forms[_rand.nextInt(forms.length)];
      final correct = str(target['fa']);
      final seen = <String>{correct};
      final ds = <String>[];
      final shuffled = [...forms]..shuffle(_rand);
      for (final f in shuffled) {
        final s = str(f['fa']);
        if (seen.add(s)) ds.add(s);
        if (ds.length >= 3) break;
      }
      if (ds.length < 3) {
        // اسی مصدر کے دوسرے گروہوں سے مدد لو
        for (final g2 in asMaps(v['groups'])) {
          for (final f in asMaps(g2['forms'])) {
            final s = str(f['fa']);
            if (s.isNotEmpty && seen.add(s)) ds.add(s);
            if (ds.length >= 3) break;
          }
          if (ds.length >= 3) break;
        }
      }
      if (ds.length < 3) continue;
      final opts = [...ds, correct]..shuffle(_rand);
      final masdar = str(v['fa']);
      final gname = str(g['name']);
      final p = str(target['p']);
      return _Q(
        type: 'd',
        typeLabel: 'گردان',
        prompt: 'مصدر «$masdar» (${str(v['ur'])})\n'
            'گروہ: $gname\n'
            'صیغہ «$p» کی درست فارسی صورت کون سی ہے؟',
        promptFa: false,
        options: opts,
        optionsFa: true,
        correct: opts.indexOf(correct),
        review: '«$masdar» — $gname — $p: $correct',
      );
    }
    return null;
  }

  _Q? _genBlank() {
    if (_sentsW.isEmpty || _dict.length < 4) return null;
    for (var attempt = 0; attempt < 12; attempt++) {
      final e = _sentsW[_rand.nextInt(_sentsW.length)];
      final fa = str(e['fa']);
      final words = asMaps(e['w']);
      if (words.isEmpty) continue;
      final w = words[_rand.nextInt(words.length)];
      final word = str(w['f']);
      if (word.isEmpty || !fa.contains(word)) continue;
      final blanked = fa.replaceFirst(word, '…………');
      final ds = _distractors(_dict.map((x) => str(x['fa'])).toList(), word, 3);
      if (ds.length < 3) continue;
      final opts = [...ds, word]..shuffle(_rand);
      return _Q(
        type: 'e',
        typeLabel: 'خالی جگہ',
        prompt: blanked,
        promptFa: true,
        hint: str(e['ur']),
        options: opts,
        optionsFa: true,
        correct: opts.indexOf(word),
        review: 'مکمل جملہ: $fa',
      );
    }
    return null;
  }

  _Q? _nextQuestion() {
    final type = _pickType();
    var q = _makeQ(type);
    if (q != null) return q;
    // منتخب قسم نہ بن سکے تو باقی اقسام آزماؤ
    final rest = _availableTypes()..shuffle(_rand);
    for (final t in rest) {
      q = _makeQ(t);
      if (q != null) return q;
    }
    return null;
  }

  // ------------------------- کھیل کا بہاؤ -------------------------

  void _startPractice() {
    setState(() {
      _mode = 'practice';
      _sessionCorrect = 0;
      _sessionWrong = 0;
      _streak = 0;
      _q = _nextQuestion();
      _selected = -1;
      _answered = false;
    });
  }

  void _startExam() {
    _timer?.cancel();
    setState(() {
      _mode = 'exam';
      _secondsLeft = 60;
      _examCorrect = 0;
      _examWrong = 0;
      _mistakes.clear();
      _streak = 0;
      _examLock = false;
      _q = _nextQuestion();
      _selected = -1;
      _answered = false;
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() => _secondsLeft--);
      if (_secondsLeft <= 0) _finishExam();
    });
  }

  void _finishExam() {
    _timer?.cancel();
    final score = _examCorrect * 10;
    if (score > _examBest) {
      _examBest = score;
      _saveProgress();
    }
    if (mounted) setState(() => _mode = 'result');
  }

  void _answer(int i) {
    final q = _q;
    if (q == null || _answered) return;
    final ok = i == q.correct;
    if (_mode == 'exam') {
      if (_examLock) return;
      _examLock = true;
      setState(() {
        _selected = i;
        _answered = true;
        if (ok) {
          _examCorrect++;
          _streak++;
          if (_streak > _bestStreak) _bestStreak = _streak;
          _points += 10;
        } else {
          _examWrong++;
          _streak = 0;
          _mistakes.add(q.review);
        }
      });
      _record(q.type, ok);
      Future.delayed(const Duration(milliseconds: 450), () {
        if (!mounted || _mode != 'exam') return;
        setState(() {
          _q = _nextQuestion();
          _selected = -1;
          _answered = false;
          _examLock = false;
        });
      });
      return;
    }
    // مشق کا موڈ
    setState(() {
      _selected = i;
      _answered = true;
      if (ok) {
        _sessionCorrect++;
        _streak++;
        if (_streak > _bestStreak) _bestStreak = _streak;
        _points += 10 + (_streak >= 5 ? 5 : 0);
      } else {
        _sessionWrong++;
        _streak = 0;
      }
    });
    _record(q.type, ok);
  }

  void _next() {
    setState(() {
      _q = _nextQuestion();
      _selected = -1;
      _answered = false;
    });
  }

  void _toMenu() {
    _timer?.cancel();
    setState(() => _mode = 'menu');
  }

  // ------------------------- نمائش -------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مشق و کھیل'),
        leading: _mode == 'menu'
            ? null
            : IconButton(
                icon: const Icon(Icons.arrow_back_rounded),
                onPressed: _toMenu,
              ),
      ),
      body: switch (_mode) {
        'practice' => _playView(exam: false),
        'exam' => _playView(exam: true),
        'result' => _resultView(),
        _ => _menuView(),
      },
    );
  }

  Widget _menuView() {
    final cs = Theme.of(context).colorScheme;
    final toNext = 150 - (_points % 150);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [AppColors.plum, AppColors.lapis],
            ),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.emoji_events_rounded,
                      color: AppColors.brightYellow, size: 30),
                  const SizedBox(width: 10),
                  Text(
                    'آپ کی سطح: $_level',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                'کل پوائنٹس: $_points   •   بہترین سلسلہ: $_bestStreak',
                style: const TextStyle(color: Colors.white, fontSize: 15),
              ),
              const SizedBox(height: 4),
              Text(
                'امتحان کا بہترین اسکور: $_examBest',
                style: const TextStyle(color: Colors.white, fontSize: 15),
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: (_points % 150) / 150,
                  minHeight: 10,
                  backgroundColor: Colors.white.withAlpha(50),
                  color: AppColors.brightYellow,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'اگلی سطح کے لیے $toNext پوائنٹس باقی',
                style: TextStyle(
                    color: Colors.white.withAlpha(220), fontSize: 13),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        _modeButton(
          context,
          icon: Icons.school_rounded,
          color: AppColors.emerald,
          title: 'مشق شروع کریں',
          subtitle:
              'لغت، جملوں اور گردان سے خودکار سوالات — سطح بڑھنے سے سوالات مشکل ہوتے جائیں گے اور کمزور حصے دوبارہ آئیں گے۔',
          onTap: _startPractice,
        ),
        const SizedBox(height: 14),
        _modeButton(
          context,
          icon: Icons.timer_rounded,
          color: AppColors.rose,
          title: 'دماغ کا امتحان (۶۰ سیکنڈ)',
          subtitle:
              'ایک منٹ میں زیادہ سے زیادہ درست جواب دیں — آخر میں نتیجہ اور غلط سوالوں کے صحیح جواب ملیں گے۔',
          onTap: _startExam,
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cardFill(context),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: cs.outlineVariant.withAlpha(110)),
          ),
          child: Text(
            'سوالات اسی ایپ کے الفاظ، جملوں اور گردانوں سے خود بنتے ہیں۔ '
            'جتنا کھیلیں گے، سوالات اتنے ہی مشکل اور متنوع ہوتے جائیں گے۔',
            style: urStyle(size: 15, color: cs.onSurfaceVariant),
          ),
        ),
      ],
    );
  }

  Widget _modeButton(
    BuildContext context, {
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: cardFill(context),
      borderRadius: BorderRadius.circular(20),
      elevation: 2,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withAlpha(35),
                ),
                child: Icon(icon, color: color, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 4),
                    Text(subtitle,
                        style: urStyle(
                            size: 14,
                            color:
                                Theme.of(context).colorScheme.onSurfaceVariant)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left_rounded),
            ],
          ),
        ),
      ),
    );
  }

  Widget _playView({required bool exam}) {
    final cs = Theme.of(context).colorScheme;
    final q = _q;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
          child: Row(
            children: [
              _statChip(context, Icons.star_rounded, 'پوائنٹس: $_points'),
              const SizedBox(width: 8),
              _statChip(context, Icons.trending_up_rounded, 'سطح: $_level'),
              const SizedBox(width: 8),
              _statChip(context, Icons.local_fire_department_rounded,
                  'سلسلہ: $_streak'),
              const Spacer(),
              if (exam)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _secondsLeft <= 10
                        ? const Color(0xFFC62828)
                        : cs.primary,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.timer_rounded,
                          color: Colors.white, size: 18),
                      const SizedBox(width: 4),
                      Text(
                        '$_secondsLeft',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
        if (!exam)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                'اس نشست میں — درست: $_sessionCorrect، غلط: $_sessionWrong',
                style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant),
              ),
            ),
          ),
        if (exam)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: _secondsLeft / 60,
                minHeight: 8,
                color: _secondsLeft <= 10
                    ? const Color(0xFFC62828)
                    : AppColors.emerald,
              ),
            ),
          ),
        Expanded(
          child: q == null
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text(
                      'اس وقت سوال نہیں بن سکا — مواد لوڈ ہونے کا انتظار کریں۔',
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
                  children: [
                    Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: cs.primary.withAlpha(30),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          q.typeLabel,
                          style: TextStyle(
                            color: cs.primary,
                            fontWeight: FontWeight.w700,
                            fontSize: 13.5,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: cardFill(context),
                        borderRadius: BorderRadius.circular(20),
                        border:
                            Border.all(color: cs.outlineVariant.withAlpha(110)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            q.prompt,
                            style: q.promptFa
                                ? faStyle(size: 24)
                                : urStyle(size: 18),
                          ),
                          if (q.hint != null && q.hint!.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text(
                              'اشارہ: ${q.hint}',
                              style: urStyle(
                                  size: 15, color: cs.onSurfaceVariant),
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    for (var i = 0; i < q.options.length; i++) ...[
                      _optionButton(q, i),
                      const SizedBox(height: 10),
                    ],
                    if (_answered && !exam) ...[
                      const SizedBox(height: 4),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: (_selected == q.correct
                                  ? const Color(0xFF2E7D32)
                                  : const Color(0xFFC62828))
                              .withAlpha(28),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Text(
                          _selected == q.correct
                              ? 'درست جواب! شاباش'
                              : 'غلط — ${q.review}',
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700),
                        ),
                      ),
                      const SizedBox(height: 14),
                      FilledButton.icon(
                        onPressed: _next,
                        icon: const Icon(Icons.arrow_forward_rounded),
                        label: const Text('اگلا سوال'),
                        style: FilledButton.styleFrom(
                          minimumSize: const Size.fromHeight(52),
                        ),
                      ),
                    ],
                  ],
                ),
        ),
      ],
    );
  }

  Widget _optionButton(_Q q, int i) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final green = dark ? const Color(0xFF81C784) : const Color(0xFF2E7D32);
    final red = dark ? const Color(0xFFEF9A9A) : const Color(0xFFC62828);
    Color bg = cardFill(context);
    Color border = Theme.of(context).colorScheme.outlineVariant;
    IconData? icon;
    if (_answered) {
      if (i == q.correct) {
        bg = green.withAlpha(45);
        border = green;
        icon = Icons.check_circle_rounded;
      } else if (i == _selected) {
        bg = red.withAlpha(45);
        border = red;
        icon = Icons.cancel_rounded;
      }
    }
    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: _answered ? null : () => _answer(i),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: border, width: _answered && (i == q.correct || i == _selected) ? 2 : 1),
          ),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  q.options[i],
                  style: q.optionsFa ? faStyle(size: 20) : urStyle(size: 16),
                ),
              ),
              if (icon != null)
                Icon(icon, color: i == q.correct ? green : red),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statChip(BuildContext context, IconData icon, String label) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: cs.surfaceContainerHigh,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: cs.primary),
          const SizedBox(width: 4),
          Text(label,
              style:
                  const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }

  Widget _resultView() {
    final score = _examCorrect * 10;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [AppColors.rose, AppColors.plum],
            ),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Column(
            children: [
              const Icon(Icons.psychology_rounded,
                  color: Colors.white, size: 44),
              const SizedBox(height: 8),
              const Text(
                'امتحان مکمل!',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'اسکور: $score',
                style: const TextStyle(
                  color: AppColors.brightYellow,
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'درست: $_examCorrect    غلط: $_examWrong    بہترین اسکور: $_examBest',
                style: const TextStyle(color: Colors.white, fontSize: 15.5),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        if (_mistakes.isNotEmpty) ...[
          const Text(
            'غلط سوالوں کے صحیح جواب:',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 10),
          for (final m in _mistakes)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(13),
              decoration: BoxDecoration(
                color: cardFill(context),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                    color: const Color(0xFFC62828).withAlpha(90)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.cancel_rounded,
                      color: Color(0xFFC62828), size: 20),
                  const SizedBox(width: 8),
                  Expanded(child: Text(m, style: urStyle(size: 15))),
                ],
              ),
            ),
        ] else
          const Text(
            'کوئی غلط جواب نہیں — بہترین کارکردگی!',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          ),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: _startExam,
          icon: const Icon(Icons.replay_rounded),
          label: const Text('دوبارہ امتحان دیں'),
          style:
              FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: _toMenu,
          icon: const Icon(Icons.home_rounded),
          label: const Text('مینیو پر واپس'),
          style:
              OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
        ),
      ],
    );
  }
}
