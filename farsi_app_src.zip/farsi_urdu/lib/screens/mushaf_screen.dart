import 'dart:convert';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

import '../theme.dart';
import '../widgets/common.dart';

/// مکمل قرآن مجید — نورِ قرآن خط (انڈوپاک رسم الخط) + جالندھری اردو ترجمہ
/// لفظ ٹچ پر: اردو معنی، مادہ، اصل صورت، قسمِ کلام، قرآن میں تکرار
/// ڈیٹا: assets/data/quran_indopak.json + assets/data/quran_words.json
class MushafData {
  static Map<String, dynamic>? _quran;
  static Map<String, dynamic>? _words;
  static Future<Map<String, dynamic>> loadQuran() async {
    if (_quran != null) return _quran!;
    final s = await rootBundle.loadString('assets/data/quran_indopak.json');
    _quran = jsonDecode(s) as Map<String, dynamic>;
    return _quran!;
  }

  static Future<Map<String, dynamic>> loadWords() async {
    if (_words != null) return _words!;
    final s = await rootBundle.loadString('assets/data/quran_words.json');
    _words = jsonDecode(s) as Map<String, dynamic>;
    return _words!;
  }
}

const List<Color> _ayahColors = [
  Color(0xFF000000),
  Color(0xFF14532D),
  Color(0xFF5D4037),
  Color(0xFF0D47A1),
];
const List<String> _ayahColorNames = ['کالا', 'گہرا سبز', 'بھورا', 'نیلا'];
const List<Color> _badgeCycle = [
  Color(0xFF14532D),
  Color(0xFF5D4037),
  Color(0xFF0D47A1),
  Color(0xFF212121),
];
const Color _pageBg = Color(0xFFFFFDF4);

class MushafScreen extends StatefulWidget {
  const MushafScreen({super.key});

  @override
  State<MushafScreen> createState() => _MushafScreenState();
}

class _MushafScreenState extends State<MushafScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('قرآن مجید — تلاوت')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: MushafData.loadQuran(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final surahs = (snap.data!['surahs'] as List).cast<Map<String, dynamic>>();
          final q = _q.trim();
          final shown = surahs.where((s) {
            if (q.isEmpty) return true;
            return s['name'].toString().contains(q) || s['n'].toString() == q;
          }).toList();
          return Column(
            children: [
              SearchBox(
                hint: 'سورت تلاش کریں…',
                onChanged: (v) => setState(() => _q = v),
              ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.only(top: 4, bottom: 32),
                  itemCount: shown.length,
                  itemBuilder: (context, i) {
                    final s = shown[i];
                    final n = s['n'] as int;
                    final ayahs = (s['ayahs'] as List).length;
                    final badge = _badgeCycle[(n - 1) % _badgeCycle.length];
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                      decoration: BoxDecoration(
                        color: cardFill(context),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: badge.withOpacity(0.45)),
                      ),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: badge,
                          child: Text('$n',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15)),
                        ),
                        title: Text('سورة ${s['name']}',
                            textDirection: TextDirection.rtl,
                            style: const TextStyle(fontFamily: 'NoorQuran', fontSize: 24)),
                        subtitle: Text(
                            '${s['place']} • $ayahs آیات • ${s['rukus']} رکوع',
                            style: urStyle(size: 13)),
                        trailing: const Icon(Icons.chevron_left, color: AppColors.gold),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => SurahReaderScreen(
                                surah: s, basmala: snap.data!['basmala'].toString()),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class SurahReaderScreen extends StatefulWidget {
  final Map<String, dynamic> surah;
  final String basmala;
  const SurahReaderScreen({super.key, required this.surah, required this.basmala});

  @override
  State<SurahReaderScreen> createState() => _SurahReaderScreenState();
}

class _SurahReaderScreenState extends State<SurahReaderScreen> {
  double _size = 30;
  bool _showUr = true;
  int _colorIdx = 0;
  Map<String, dynamic>? _words;
  Map<String, dynamic>? _asbab;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (!mounted) return;
      setState(() {
        _size = p.getDouble('mushaf_font_size') ?? 30;
        _showUr = p.getBool('mushaf_show_ur') ?? true;
        _colorIdx = p.getInt('mushaf_color') ?? 0;
      });
    });
    MushafData.loadWords().then((w) {
      if (!mounted) return;
      setState(() {
        _words = (w['words'] as Map).cast<String, dynamic>();
        _asbab = (w['asbab'] as Map).cast<String, dynamic>();
      });
    });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('mushaf_font_size', _size);
    await p.setBool('mushaf_show_ur', _showUr);
    await p.setInt('mushaf_color', _colorIdx);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.surah;
    final ayahs = (s['ayahs'] as List).cast<String>();
    final urs = (s['ur'] as List).cast<String>();
    final hasBasmala = s['basmala'] == true;
    final color = _ayahColors[_colorIdx];
    return Scaffold(
      appBar: AppBar(
        title: Text('سورة ${s['name']}',
            style: const TextStyle(fontFamily: 'NoorQuran', fontSize: 22)),
        actions: [
          PopupMenuButton<int>(
            icon: const Icon(Icons.palette_outlined),
            tooltip: 'آیت کا رنگ',
            initialValue: _colorIdx,
            onSelected: (v) {
              setState(() => _colorIdx = v);
              _save();
            },
            itemBuilder: (_) => [
              for (int i = 0; i < _ayahColors.length; i++)
                PopupMenuItem(
                  value: i,
                  child: Row(children: [
                    CircleAvatar(radius: 9, backgroundColor: _ayahColors[i]),
                    const SizedBox(width: 10),
                    Text(_ayahColorNames[i], style: urStyle(size: 14)),
                  ]),
                ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.text_decrease),
            tooltip: 'حروف چھوٹے',
            onPressed: () {
              setState(() => _size = (_size - 2).clamp(20, 52));
              _save();
            },
          ),
          IconButton(
            icon: const Icon(Icons.text_increase),
            tooltip: 'حروف بڑے',
            onPressed: () {
              setState(() => _size = (_size + 2).clamp(20, 52));
              _save();
            },
          ),
          IconButton(
            icon: Icon(Icons.translate, color: _showUr ? AppColors.gold : null),
            tooltip: 'اردو ترجمہ',
            onPressed: () {
              setState(() => _showUr = !_showUr);
              _save();
            },
          ),
        ],
      ),
      body: Container(
        color: _pageBg,
        child: ListView.builder(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 48),
          itemCount: ayahs.length + (hasBasmala ? 1 : 0),
          itemBuilder: (context, i) {
            if (hasBasmala && i == 0) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 18),
                child: Text(
                  widget.basmala,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontFamily: 'NoorQuran',
                      fontSize: _size,
                      height: 2.0,
                      color: color),
                ),
              );
            }
            final idx = i - (hasBasmala ? 1 : 0);
            final key = '${s['n']}:${idx + 1}';
            return _AyahBlock(
              key: ValueKey(key),
              ayahNum: idx + 1,
              text: ayahs[idx],
              urdu: (_showUr && idx < urs.length) ? urs[idx] : null,
              fontSize: _size,
              color: color,
              wordRec: _words?[key] as Map<String, dynamic>?,
              asbab: _asbab?[key] as String?,
              surahName: s['name'].toString(),
            );
          },
        ),
      ),
    );
  }
}

class _AyahBlock extends StatefulWidget {
  final int ayahNum;
  final String text;
  final String? urdu;
  final double fontSize;
  final Color color;
  final Map<String, dynamic>? wordRec;
  final String? asbab;
  final String surahName;
  const _AyahBlock({
    super.key,
    required this.ayahNum,
    required this.text,
    required this.urdu,
    required this.fontSize,
    required this.color,
    required this.wordRec,
    required this.asbab,
    required this.surahName,
  });

  @override
  State<_AyahBlock> createState() => _AyahBlockState();
}

class _AyahBlockState extends State<_AyahBlock> {
  final List<TapGestureRecognizer> _recs = [];

  @override
  void dispose() {
    for (final r in _recs) {
      r.dispose();
    }
    super.dispose();
  }

  void _showWord(String token, List<int> wordIdxs) {
    final rec = widget.wordRec!;
    final entries = (rec['w'] as List).cast<List<dynamic>>();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(token,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontFamily: 'NoorQuran', fontSize: 36, color: Colors.black)),
              const Divider(height: 24),
              for (final wi in wordIdxs)
                if (wi < entries.length) ...[
                  _wordDetail(entries[wi]),
                  const SizedBox(height: 10),
                ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _wordDetail(List<dynamic> e) {
    // e = [اردو معنی, مادہ, مادے کی تکرار, اصل صورت, اصل صورت کی تکرار, قسمِ کلام]
    final ur = e[0].toString();
    final root = e[1].toString();
    final rc = e[2] as int;
    final lem = e[3].toString();
    final lc = e[4] as int;
    final pos = e[5].toString();
    final rootSpaced = root.split('').join(' ');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (ur.isNotEmpty)
          Text('معنی: $ur',
              textDirection: TextDirection.rtl, style: urStyle(size: 17)),
        if (pos.isNotEmpty)
          Text('قسمِ کلام: $pos',
              textDirection: TextDirection.rtl, style: urStyle(size: 15)),
        if (root.isNotEmpty)
          Text('مادہ: $rootSpaced — اس مادے کے الفاظ قرآن میں $rc بار',
              textDirection: TextDirection.rtl, style: urStyle(size: 15)),
        if (lem.isNotEmpty)
          Text('اصل صورت: $lem — یہ لفظ قرآن میں $lc بار آیا ہے',
              textDirection: TextDirection.rtl, style: urStyle(size: 15)),
      ],
    );
  }

  void _showAsbab() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('شانِ نزول — سورة ${widget.surahName}، آیت ${widget.ayahNum}',
                  textDirection: TextDirection.rtl, style: urStyle(size: 17)),
              const Divider(height: 24),
              Text(widget.asbab!,
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                      fontFamily: 'NoorQuran',
                      fontSize: 19,
                      height: 2.0,
                      color: Colors.black87)),
              const SizedBox(height: 10),
              Text('ماخذ: الواحدی، أسباب النزول',
                  textDirection: TextDirection.rtl,
                  style: urStyle(size: 12, color: Colors.black54)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final tokens = widget.text.split(' ');
    final rec = widget.wordRec;
    final List<List<int>>? amap = rec == null
        ? null
        : (rec['m'] != null
            ? (rec['m'] as List)
                .map((x) => (x as List).map((e) => e as int).toList())
                .toList()
            : List.generate(tokens.length, (i) => [i]));
    final spans = <TextSpan>[];
    for (int i = 0; i < tokens.length; i++) {
      TapGestureRecognizer? rec2;
      if (amap != null && i < amap.length) {
        final idxs = amap[i];
        rec2 = TapGestureRecognizer()..onTap = () => _showWord(tokens[i], idxs);
        _recs.add(rec2);
      }
      spans.add(TextSpan(text: tokens[i], recognizer: rec2));
      if (i < tokens.length - 1) spans.add(const TextSpan(text: ' '));
    }
    spans.add(TextSpan(
      text:
          ' ﴿${widget.ayahNum.toString().replaceAllMapped(RegExp(r'[0-9]'), (m) => '٠١٢٣٤٥٦٧٨٩'[int.parse(m[0]!)])}﴾',
      style: const TextStyle(color: AppColors.gold),
    ));
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 13,
                backgroundColor: widget.color.withOpacity(0.85),
                child: Text('${widget.ayahNum}',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.bold)),
              ),
              const SizedBox(width: 8),
              if (widget.asbab != null)
                TextButton.icon(
                  onPressed: _showAsbab,
                  icon: const Icon(Icons.history_edu_outlined, size: 18),
                  label: Text('شانِ نزول', style: urStyle(size: 13)),
                  style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      minimumSize: const Size(0, 30),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap),
                ),
            ],
          ),
          const SizedBox(height: 4),
          Text.rich(
            TextSpan(children: spans),
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.justify,
            style: TextStyle(
                fontFamily: 'NoorQuran',
                fontSize: widget.fontSize,
                height: 2.1,
                color: widget.color),
          ),
          if (widget.urdu != null)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(
                widget.urdu!,
                textDirection: TextDirection.rtl,
                style: urStyle(size: 15, color: Colors.black87),
              ),
            ),
        ],
      ),
    );
  }
}
