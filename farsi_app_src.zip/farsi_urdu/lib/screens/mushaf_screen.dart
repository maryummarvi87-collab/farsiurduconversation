import 'dart:convert';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

import '../theme.dart';
import '../widgets/common.dart';

/// مکمل قرآن مجید — نورِ قرآن خط (انڈوپاک رسم الخط) + جالندھری اردو ترجمہ
/// لفظ ٹچ پر: اردو معنی، مادہ، اصل صورت، قسمِ کلام، قرآن میں تکرار
/// ڈیٹا: assets/data/quran_indopak.json + assets/data/quran_words.json
class MushafData {
  static Map<String, dynamic>? _quran;
  static Map<String, dynamic>? _words;
  static Future<Map<String, dynamic>> loadQuran() async {
    if (_quran != null) return _quran!;
    final s = await rootBundle.loadString('assets/data/quran_indopak.json');
    _quran = jsonDecode(s) as Map<String, dynamic>;
    return _quran!;
  }

  static Future<Map<String, dynamic>> loadWords() async {
    if (_words != null) return _words!;
    final s = await rootBundle.loadString('assets/data/quran_words.json');
    _words = jsonDecode(s) as Map<String, dynamic>;
    return _words!;
  }
}

const List<Color> _ayahColors = [
  Color(0xFF000000),
  Color(0xFF14532D),
  Color(0xFF5D4037),
  Color(0xFF0D47A1),
];
const List<Color> _ayahColorsDark = [
  Color(0xFFF5EFE0),
  Color(0xFF81C784),
  Color(0xFFBCAAA4),
  Color(0xFF90CAF9),
];
const List<String> _ayahColorNames = ['کالا', 'گہرا سبز', 'بھورا', 'نیلا'];
const List<Color> _badgeCycle = [
  Color(0xFF14532D),
  Color(0xFF5D4037),
  Color(0xFF0D47A1),
  Color(0xFF212121),
];
const Color _pageBg = Color(0xFFFFFDF4);
const Color _pageBgDark = Color(0xFF101010);

class MushafScreen extends StatefulWidget {
  const MushafScreen({super.key});

  @override
  State<MushafScreen> createState() => _MushafScreenState();
}

class _MushafScreenState extends State<MushafScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('قرآن مجید — تلاوت'),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_tree_outlined),
            tooltip: 'افعال کے مادے',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const VerbRootsScreen()),
            ),
          ),
        ],
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: MushafData.loadQuran(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final surahs = (snap.data!['surahs'] as List).cast<Map<String, dynamic>>();
          final q = _q.trim();
          final shown = surahs.where((s) {
            if (q.isEmpty) return true;
            return s['name'].toString().contains(q) || s['n'].toString() == q;
          }).toList();
          return Column(
            children: [
              SearchBox(
                hint: 'سورت تلاش کریں…',
                onChanged: (v) => setState(() => _q = v),
              ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.only(top: 4, bottom: 32),
                  itemCount: shown.length,
                  itemBuilder: (context, i) {
                    final s = shown[i];
                    final n = s['n'] as int;
                    final ayahs = (s['ayahs'] as List).length;
                    final badge = _badgeCycle[(n - 1) % _badgeCycle.length];
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                      decoration: BoxDecoration(
                        color: cardFill(context),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: badge.withOpacity(0.45)),
                      ),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: badge,
                          child: Text('$n',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15)),
                        ),
                        title: Text('سورة ${s['name']}',
                            textDirection: TextDirection.rtl,
                            style: const TextStyle(fontFamily: 'NoorQuran', fontSize: 24)),
                        subtitle: Text(
                            '${s['place']} • $ayahs آیات • ${s['rukus']} رکوع',
                            style: urStyle(size: 13)),
                        trailing: const Icon(Icons.chevron_left, color: AppColors.gold),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => SurahReaderScreen(
                                surah: s, basmala: snap.data!['basmala'].toString()),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class SurahReaderScreen extends StatefulWidget {
  final Map<String, dynamic> surah;
  final String basmala;
  const SurahReaderScreen({super.key, required this.surah, required this.basmala});

  @override
  State<SurahReaderScreen> createState() => _SurahReaderScreenState();
}

class _SurahReaderScreenState extends State<SurahReaderScreen> {
  double _size = 30;
  bool _showUr = true;
  bool _dark = false;
  int _colorIdx = 0;
  double? _pinchStart;
  Map<String, dynamic>? _words;
  Map<String, dynamic>? _asbab;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (!mounted) return;
      setState(() {
        _size = p.getDouble('mushaf_font_size') ?? 30;
        _showUr = p.getBool('mushaf_show_ur') ?? true;
        _dark = p.getBool('mushaf_dark') ?? false;
        _colorIdx = p.getInt('mushaf_color') ?? 0;
      });
    });
    MushafData.loadWords().then((w) {
      if (!mounted) return;
      setState(() {
        _words = (w['words'] as Map).cast<String, dynamic>();
        _asbab = (w['asbab'] as Map).cast<String, dynamic>();
      });
    });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('mushaf_font_size', _size);
    await p.setBool('mushaf_show_ur', _showUr);
    await p.setBool('mushaf_dark', _dark);
    await p.setInt('mushaf_color', _colorIdx);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.surah;
    final ayahs = (s['ayahs'] as List).cast<String>();
    final urs = (s['ur'] as List).cast<String>();
    final hasBasmala = s['basmala'] == true;
    final color = _dark ? _ayahColorsDark[_colorIdx] : _ayahColors[_colorIdx];
    final badgeColor = _ayahColors[_colorIdx];
    return Scaffold(
      appBar: AppBar(
        title: Text('سورة ${s['name']}',
            style: const TextStyle(fontFamily: 'NoorQuran', fontSize: 22)),
        actions: [
          IconButton(
            icon: Icon(_dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
            tooltip: _dark ? 'روشن انداز' : 'ڈارک موڈ',
            onPressed: () {
              setState(() => _dark = !_dark);
              _save();
            },
          ),
          IconButton(
            icon: const Icon(Icons.account_tree_outlined),
            tooltip: 'افعال کے مادے',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const VerbRootsScreen()),
            ),
          ),
          PopupMenuButton<int>(
            icon: const Icon(Icons.palette_outlined),
            tooltip: 'آیت کا رنگ',
            initialValue: _colorIdx,
            onSelected: (v) {
              setState(() => _colorIdx = v);
              _save();
            },
            itemBuilder: (_) => [
              for (int i = 0; i < _ayahColors.length; i++)
                PopupMenuItem(
                  value: i,
                  child: Row(children: [
                    CircleAvatar(radius: 9, backgroundColor: _ayahColors[i]),
                    const SizedBox(width: 10),
                    Text(_ayahColorNames[i], style: urStyle(size: 14)),
                  ]),
                ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.text_decrease),
            tooltip: 'حروف چھوٹے',
            onPressed: () {
              setState(() => _size = (_size - 2).clamp(20, 52));
              _save();
            },
          ),
          IconButton(
            icon: const Icon(Icons.text_increase),
            tooltip: 'حروف بڑے',
            onPressed: () {
              setState(() => _size = (_size + 2).clamp(20, 52));
              _save();
            },
          ),
          IconButton(
            icon: Icon(Icons.translate, color: _showUr ? AppColors.gold : null),
            tooltip: 'اردو ترجمہ',
            onPressed: () {
              setState(() => _showUr = !_showUr);
              _save();
            },
          ),
        ],
      ),
      body: Container(
        color: _dark ? _pageBgDark : _pageBg,
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onScaleStart: (d) => _pinchStart = _size,
          onScaleUpdate: (d) {
            if (_pinchStart == null || d.scale == 1.0) return;
            setState(() => _size = (_pinchStart! * d.scale).clamp(20, 72));
          },
          onScaleEnd: (_) {
            _pinchStart = null;
            _save();
          },
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 48),
            itemCount: ayahs.length + (hasBasmala ? 1 : 0),
            itemBuilder: (context, i) {
              if (hasBasmala && i == 0) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 18),
                  child: Text(
                    widget.basmala,
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontFamily: 'NoorQuran',
                        fontSize: _size,
                        height: 2.0,
                        color: color),
                  ),
                );
              }
              final idx = i - (hasBasmala ? 1 : 0);
              final key = '${s['n']}:${idx + 1}';
              return _AyahBlock(
                key: ValueKey(key),
                ayahNum: idx + 1,
                text: ayahs[idx],
                urdu: (_showUr && idx < urs.length) ? urs[idx] : null,
                fontSize: _size,
                color: color,
                badgeColor: badgeColor,
                dark: _dark,
                wordRec: _words?[key] as Map<String, dynamic>?,
                asbab: _asbab?[key] as String?,
                surahName: s['name'].toString(),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _AyahBlock extends StatefulWidget {
  final int ayahNum;
  final String text;
  final String? urdu;
  final double fontSize;
  final Color color;
  final Color badgeColor;
  final bool dark;
  final Map<String, dynamic>? wordRec;
  final String? asbab;
  final String surahName;
  const _AyahBlock({
    super.key,
    required this.ayahNum,
    required this.text,
    required this.urdu,
    required this.fontSize,
    required this.color,
    required this.badgeColor,
    required this.dark,
    required this.wordRec,
    required this.asbab,
    required this.surahName,
  });

  @override
  State<_AyahBlock> createState() => _AyahBlockState();
}

class _AyahBlockState extends State<_AyahBlock> {
  final List<TapGestureRecognizer> _recs = [];

  @override
  void dispose() {
    for (final r in _recs) {
      r.dispose();
    }
    super.dispose();
  }

  void _showWord(String token, List<int> wordIdxs) {
    final rec = widget.wordRec!;
    final entries = (rec['w'] as List).cast<List<dynamic>>();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(token,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontFamily: 'NoorQuran', fontSize: 36, color: Colors.black)),
              const Divider(height: 24),
              for (final wi in wordIdxs)
                if (wi < entries.length) ...[
                  _wordDetail(entries[wi]),
                  const SizedBox(height: 10),
                ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _wordDetail(List<dynamic> e) {
    // e = [اردو معنی, مادہ, مادے کی تکرار, اصل صورت, اصل صورت کی تکرار, قسمِ کلام]
    final ur = e[0].toString();
    final root = e[1].toString();
    final rc = e[2] as int;
    final lem = e[3].toString();
    final lc = e[4] as int;
    final pos = e[5].toString();
    final rootSpaced = root.split('').join(' ');
    final isVerb = pos == 'فعل';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (isVerb && root.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.gold.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.gold.withOpacity(0.5)),
            ),
            child: Text('فعل کا مادہ: $rootSpaced',
                textDirection: TextDirection.rtl, style: urStyle(size: 16)),
          ),
        if (ur.isNotEmpty)
          Text('معنی: $ur',
              textDirection: TextDirection.rtl, style: urStyle(size: 17)),
        if (pos.isNotEmpty)
          Text('قسمِ کلام: $pos',
              textDirection: TextDirection.rtl, style: urStyle(size: 15)),
        if (root.isNotEmpty)
          Text('مادہ: $rootSpaced — اس مادے کے الفاظ قرآن میں $rc بار',
              textDirection: TextDirection.rtl, style: urStyle(size: 15)),
        if (lem.isNotEmpty)
          Text('اصل صورت: $lem — یہ لفظ قرآن میں $lc بار آیا ہے',
              textDirection: TextDirection.rtl, style: urStyle(size: 15)),
      ],
    );
  }

  void _showAsbab() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('شانِ نزول — سورة ${widget.surahName}، آیت ${widget.ayahNum}',
                  textDirection: TextDirection.rtl, style: urStyle(size: 17)),
              const Divider(height: 24),
              Text(widget.asbab!,
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                      fontFamily: 'NoorQuran',
                      fontSize: 19,
                      height: 2.0,
                      color: Colors.black87)),
              const SizedBox(height: 10),
              Text('ماخذ: الواحدی، أسباب النزول',
                  textDirection: TextDirection.rtl,
                  style: urStyle(size: 12, color: Colors.black54)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final tokens = widget.text.split(' ');
    final rec = widget.wordRec;
    final List<List<int>>? amap = rec == null
        ? null
        : (rec['m'] != null
            ? (rec['m'] as List)
                .map((x) => (x as List).map((e) => e as int).toList())
                .toList()
            : List.generate(tokens.length, (i) => [i]));
    final spans = <TextSpan>[];
    for (int i = 0; i < tokens.length; i++) {
      TapGestureRecognizer? rec2;
      if (amap != null && i < amap.length) {
        final idxs = amap[i];
        rec2 = TapGestureRecognizer()..onTap = () => _showWord(tokens[i], idxs);
        _recs.add(rec2);
      }
      spans.add(TextSpan(text: tokens[i], recognizer: rec2));
      if (i < tokens.length - 1) spans.add(const TextSpan(text: ' '));
    }
    spans.add(TextSpan(
      text:
          ' ﴿${widget.ayahNum.toString().replaceAllMapped(RegExp(r'[0-9]'), (m) => '٠١٢٣٤٥٦٧٨٩'[int.parse(m[0]!)])}﴾',
      style: const TextStyle(color: AppColors.gold),
    ));
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 13,
                backgroundColor: widget.badgeColor.withOpacity(0.85),
                child: Text('${widget.ayahNum}',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.bold)),
              ),
              const SizedBox(width: 8),
              if (widget.asbab != null)
                TextButton.icon(
                  onPressed: _showAsbab,
                  icon: const Icon(Icons.history_edu_outlined, size: 18),
                  label: Text('شانِ نزول', style: urStyle(size: 13)),
                  style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      minimumSize: const Size(0, 30),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap),
                ),
            ],
          ),
          const SizedBox(height: 4),
          Text.rich(
            TextSpan(children: spans),
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.justify,
            style: TextStyle(
                fontFamily: 'NoorQuran',
                fontSize: widget.fontSize,
                height: 2.1,
                color: widget.color),
          ),
          if (widget.urdu != null)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(
                widget.urdu!,
                textDirection: TextDirection.rtl,
                style: urStyle(
                    size: 15,
                    color: widget.dark ? const Color(0xFFE8E8E8) : Colors.black87),
              ),
            ),
        ],
      ),
    );
  }
}

/// قرآن کے افعال کے مادے — ہر مادے کے افعال (اصل صورتیں) گنتی کے ساتھ
class VerbRootsScreen extends StatefulWidget {
  const VerbRootsScreen({super.key});

  @override
  State<VerbRootsScreen> createState() => _VerbRootsScreenState();
}

class _VerbRootsScreenState extends State<VerbRootsScreen> {
  String _q = '';
  List<Map<String, dynamic>>? _roots;

  @override
  void initState() {
    super.initState();
    MushafData.loadWords().then((w) {
      final words = (w['words'] as Map).cast<String, dynamic>();
      final byRoot = <String, Map<String, dynamic>>{};
      for (final rec in words.values) {
        final entries = ((rec as Map)['w'] as List).cast<List<dynamic>>();
        for (final e in entries) {
          // e = [اردو معنی, مادہ, مادے کی تکرار, اصل صورت, اصل صورت کی تکرار, قسمِ کلام]
          if (e.length < 6 || e[5].toString() != 'فعل') continue;
          final root = e[1].toString();
          if (root.isEmpty) continue;
          final r = byRoot.putIfAbsent(
              root,
              () => <String, dynamic>{
                    'root': root,
                    'count': e[2] as int,
                    'lemmas': <String, Map<String, dynamic>>{},
                  });
          final lemma = e[3].toString();
          if (lemma.isNotEmpty) {
            (r['lemmas'] as Map<String, Map<String, dynamic>>).putIfAbsent(
                lemma,
                () => <String, dynamic>{
                      'lemma': lemma,
                      'count': e[4] as int,
                      'ur': e[0].toString(),
                    });
          }
        }
      }
      final list = byRoot.values.toList()
        ..sort((a, b) => (b['count'] as int).compareTo(a['count'] as int));
      if (!mounted) return;
      setState(() => _roots = list);
    });
  }

  void _showRoot(Map<String, dynamic> r) {
    final lemmas = (r['lemmas'] as Map<String, Map<String, dynamic>>)
        .values
        .toList()
      ..sort((a, b) => (b['count'] as int).compareTo(a['count'] as int));
    final rootSpaced = r['root'].toString().split('').join(' ');
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('مادہ: $rootSpaced',
                  textDirection: TextDirection.rtl, style: urStyle(size: 18)),
              Text('اس مادے کے الفاظ قرآن میں ${r['count']} بار آئے ہیں',
                  textDirection: TextDirection.rtl, style: urStyle(size: 14)),
              const Divider(height: 24),
              Text('اس مادے کے افعال:',
                  textDirection: TextDirection.rtl, style: urStyle(size: 15)),
              const SizedBox(height: 6),
              for (final l in lemmas)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(l['lemma'].toString(),
                            textDirection: TextDirection.rtl,
                            style: const TextStyle(
                                fontFamily: 'NoorQuran',
                                fontSize: 21,
                                color: Colors.black)),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                            '${l['ur']} — ${l['count']} بار',
                            textDirection: TextDirection.rtl,
                            style: urStyle(size: 13)),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('قرآن کے افعال کے مادے')),
      body: _roots == null
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                SearchBox(
                  hint: 'مادہ تلاش کریں…',
                  onChanged: (v) => setState(() => _q = v),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
                  child: Text(
                      'کل ${_roots!.length} مادے — کسی مادے پر ٹیپ کریں، اس کے افعال نظر آئیں گے',
                      style: urStyle(size: 13)),
                ),
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.only(bottom: 32),
                    itemCount: _roots!.length,
                    itemBuilder: (context, i) {
                      final r = _roots![i];
                      final q = _q.replaceAll(' ', '');
                      if (q.isNotEmpty &&
                          !r['root'].toString().replaceAll(' ', '').contains(q)) {
                        return const SizedBox.shrink();
                      }
                      final lemmaCount =
                          (r['lemmas'] as Map<String, dynamic>).length;
                      return Container(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 4),
                        decoration: BoxDecoration(
                          color: cardFill(context),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                              color: AppColors.gold.withOpacity(0.35)),
                        ),
                        child: ListTile(
                          title: Text(r['root'].toString(),
                              textDirection: TextDirection.rtl,
                              style: const TextStyle(
                                  fontFamily: 'NoorQuran', fontSize: 23)),
                          subtitle: Text(
                              'اس مادے کے الفاظ قرآن میں ${r['count']} بار • $lemmaCount افعال',
                              style: urStyle(size: 13)),
                          trailing: const Icon(Icons.chevron_left,
                              color: AppColors.gold),
                          onTap: () => _showRoot(r),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}
