import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../theme.dart';

const String _geminiApiKey = '__GEMINI_KEY__';

/// AI سے پوچھیں — فارسی زبان کے بارے میں آن لائن تفصیلی جوابات
/// (معنی، گرامر، مترادف، متضاد، مذکر و مؤنث، واحد و جمع، صرفی تجزیہ، ندائی جملے، مثالیں)
class AskAiScreen extends StatefulWidget {
  final String? initialQuery;
  final int? initialTopic;
  const AskAiScreen({super.key, this.initialQuery, this.initialTopic});

  @override
  State<AskAiScreen> createState() => _AskAiScreenState();
}

class _Topic {
  final String label;
  final String focus;
  final String hint;
  const _Topic(this.label, this.focus, this.hint);
}

const _topics = <_Topic>[
  _Topic('عام سوال', 'Answer the question in detail.',
      'فارسی کے بارے میں اپنا سوال لکھیں'),
  _Topic('لفظ کے معنی',
      'Give the detailed meanings of this Persian word: its part of speech, all common meanings in Urdu, and how it is used.',
      'فارسی لفظ لکھیں، جیسے: کتاب'),
  _Topic('گرامر کی وضاحت',
      'Explain this Persian grammar point in simple detail with rules and examples.',
      'گرامر کا نکتہ لکھیں، جیسے: اضافه'),
  _Topic('مترادف',
      'Give the synonyms (ہم معنی الفاظ) of this Persian word, with the small differences between them, plus an example for each.',
      'فارسی لفظ لکھیں، جیسے: بزرگ'),
  _Topic('متضاد',
      'Give the antonyms (متضاد الفاظ) of this Persian word with an example sentence for each.',
      'فارسی لفظ لکھیں، جیسے: بزرگ'),
  _Topic('مذکر و مؤنث',
      'Explain the masculine and feminine (مذکر و مؤنث) forms related to this word or point, and the rules for gender in Persian.',
      'لفظ یا سوال لکھیں، جیسے: معلم'),
  _Topic('واحد و جمع',
      'Give the singular and plural (واحد و جمع) forms of this Persian word, including Arabic-style broken plurals if used, with rules and examples.',
      'فارسی لفظ لکھیں، جیسے: کتاب'),
  _Topic('صرفی تجزیہ',
      'Do a full morphological analysis (صرفی تجزیہ) of this Persian word or verb: root/infinitive (مصدر), past stem (بن ماضی), present stem (بن مضارع), derivatives (مشتقات) such as اسم فاعل، اسم مفعول، اسم ظرف، صفت — each with meaning.',
      'فارسی لفظ یا مصدر لکھیں، جیسے: نوشتن'),
  _Topic('ندائی جملے',
      'Explain and give vocative (ندائی) expressions in Persian related to this input: the particles used (ای، یا، ـا) and natural calling sentences with Urdu translations.',
      'لفظ یا نام لکھیں، جیسے: دوست'),
  _Topic('مثالی جملے',
      'Give several natural example sentences in Persian for this word or point, each with its Urdu translation.',
      'فارسی لفظ لکھیں، جیسے: رفتن'),
  _Topic('جملے کی گرامر',
      'Analyse the grammar of this Persian sentence in full detail: the role of every word (فاعل، مفعول، فعل، حرفِ جر، اضافه), the verb (its مصدر، tense, person and stem), ezafe constructions, object marker را, prepositions and word order — explained simply, and also list the masdars (infinitives) used in the sentence.',
      'فارسی جملہ لکھیں'),
];

class _AskAiScreenState extends State<AskAiScreen> {
  final _controller = TextEditingController();
  int _topicIndex = 0;
  bool _loading = false;
  String? _result;
  String? _error;

  @override
  void initState() {
    super.initState();
    if (widget.initialTopic != null &&
        widget.initialTopic! >= 0 &&
        widget.initialTopic! < _topics.length) {
      _topicIndex = widget.initialTopic!;
    }
    final q = (widget.initialQuery ?? '').trim();
    if (q.isNotEmpty) {
      _controller.text = q;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _ask();
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _cleanAiText(String s) {
    var t = s;
    t = t.replaceAllMapped(RegExp(r'\\frac\{([^{}]+)\}\{([^{}]+)\}'),
        (m) => '${m[1]}/${m[2]}');
    t = t.replaceAll(RegExp(r'\\[\(\[\)\]]'), '');
    t = t.replaceAll('**', '');
    t = t.replaceAll(RegExp(r'^#{1,6}\s*', multiLine: true), '');
    return t.trim();
  }


  static const List<String> _geminiModels = [
    'gemini-3.5-flash',
    'gemini-3.1-flash-lite',
    'gemini-3.6-flash',
  ];

  Future<String> _askGemini(String prompt) async {
    final completer = Completer<String>();
    var pending = _geminiModels.length;
    for (final model in _geminiModels) {
      _askGeminiModel(model, prompt).then((t) {
        if (t.isNotEmpty && !completer.isCompleted) {
          completer.complete(t);
        }
        pending--;
        if (pending == 0 && !completer.isCompleted) completer.complete('');
      });
    }
    return completer.future
        .timeout(const Duration(seconds: 32), onTimeout: () => '');
  }

  Future<String> _askGeminiModel(String model, String prompt) async {
    try {
      final res = await http
          .post(
            Uri.parse(
                'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent'),
            headers: {
              'Content-Type': 'application/json',
              'x-goog-api-key': _geminiApiKey,
            },
            body: jsonEncode({
              'contents': [
                {
                  'parts': [
                    {'text': prompt}
                  ]
                }
              ],
              'generationConfig': {
                'temperature': 0.3,
                'maxOutputTokens': 2048,
              },
            }),
          )
          .timeout(const Duration(seconds: 30));
      if (res.statusCode != 200) return '';
      final j = jsonDecode(utf8.decode(res.bodyBytes));
      final parts = j['candidates']?[0]?['content']?['parts'] as List?;
      if (parts == null) return '';
      return parts.map((p) => (p['text'] ?? '') as String).join().trim();
    } catch (_) {
      return '';
    }
  }

  Future<String> _askPollinations(String prompt) async {
    try {
      final res = await http
          .post(
            Uri.parse('https://text.pollinations.ai/'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'messages': [
                {'role': 'user', 'content': prompt}
              ],
              'model': 'openai',
            }),
          )
          .timeout(const Duration(seconds: 60));
      if (res.statusCode != 200) return '';
      return utf8.decode(res.bodyBytes).trim();
    } catch (_) {
      return '';
    }
  }

  Future<void> _ask() async {
    final q = _controller.text.trim();
    if (q.isEmpty) {
      setState(() => _error = 'پہلے اپنا سوال یا لفظ لکھیں');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
      _result = null;
    });
    final topic = _topics[_topicIndex];
    final prompt = 'You are an expert teacher of the Persian (Farsi) language '
        'for Urdu-speaking learners. Answer accurately and in focused detail, in Urdu (Urdu script). Accuracy matters most: give only correct forms and meanings; if unsure of a form or meaning, say so instead of guessing. '
        'Write all Persian words and sentences in Persian script with '
        'diacritics where helpful, and give the Urdu translation of every '
        'Persian example. Where relevant, also cover: meanings, grammar, '
        'synonyms, antonyms, masculine/feminine, singular/plural, morphology '
        'and vocative use, with at least two example sentences. '
        'Do not use markdown tables and do not use Latin transliteration. '
        '${topic.focus} Learner input: $q';
    var text = '';
    try {
      text = await _askGemini(prompt);
    } catch (_) {}
    if (text.isEmpty) {
      try {
        text = await _askPollinations(prompt);
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (text.isNotEmpty) {
        _result = _cleanAiText(text);
      } else {
        _error = 'انٹرنیٹ سے رابطہ نہیں ہو سکا، دوبارہ کوشش کریں';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final topic = _topics[_topicIndex];
    return Scaffold(
      appBar: AppBar(title: const Text('AI سے پوچھیں')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: [
          Text(
            'فارسی زبان کے بارے میں جو چاہیں پوچھیں: لفظ کے معنی، گرامر، مترادف، '
            'متضاد، مذکر و مؤنث، واحد و جمع، صرفی تجزیہ، ندائی جملے اور مثالیں — '
            'جواب آن لائن، تفصیل کے ساتھ اردو میں ملے گا۔ (انٹرنیٹ ضروری ہے)',
            style: urStyle(size: 15, color: cs.onSurface),
          ),
          const SizedBox(height: 16),
          Text('موضوع منتخب کریں',
              style: urStyle(size: 15, color: cs.onSurface)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (var i = 0; i < _topics.length; i++)
                ChoiceChip(
                  label: Text(_topics[i].label),
                  selected: _topicIndex == i,
                  onSelected: (_) => setState(() => _topicIndex = i),
                ),
            ],
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _controller,
            minLines: 1,
            maxLines: 4,
            textInputAction: TextInputAction.newline,
            decoration: InputDecoration(
              labelText: 'سوال یا لفظ',
              hintText: topic.hint,
              border: const OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _loading ? null : _ask,
            icon: const Icon(Icons.smart_toy_rounded),
            label: const Text('جواب حاصل کریں'),
          ),
          if (_loading) ...[
            const SizedBox(height: 24),
            const Center(child: CircularProgressIndicator()),
            const SizedBox(height: 8),
            Center(
              child: Text('جواب تیار ہو رہا ہے…',
                  style: urStyle(size: 14, color: cs.onSurface)),
            ),
          ],
          if (_error != null) ...[
            const SizedBox(height: 16),
            Text(_error!, style: urStyle(size: 15, color: cs.error)),
          ],
          if (_result != null) ...[
            const SizedBox(height: 20),
            Text('جواب',
                style: urStyle(size: 16, color: cs.onSurface)),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: SelectableText(
                  _result!,
                  style: urStyle(size: 15, color: cs.onSurface),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
