import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../services/tts_service.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/ayah_card.dart';
import '../widgets/common.dart';
import '../widgets/sentence_detail.dart';
import '../widgets/word_tap_text.dart';

/// کتابی سبق کا صفحہ — کتاب کی طرح سیدھا بہتا ہوا متن، خوبصورت رنگوں میں۔
/// ہر سطر: اعراب‌دار فارسی — رومن — اردو معنی؛ فارسی لفظ پر ٹچ کرنے سے معنی کھلتا ہے۔
/// اوپر کاپی اور شیئر کے بٹن — پورا سبق ایک ٹچ میں کاپی ہو جاتا ہے۔
class BookPageScreen extends StatefulWidget {
  final Map<String, dynamic> item;
  const BookPageScreen({super.key, required this.item});

  @override
  State<BookPageScreen> createState() => _BookPageScreenState();
}

class _BookPageScreenState extends State<BookPageScreen> {
  late final String _title;
  late final String _sub;
  late final String _body;
  late final bool _quranSection;
  late final bool _isTafsir;

  /// سطروں کی درجہ بندی صفحہ کھلتے ہی ایک بار ہوتی ہے؛ ہر سطر کا وجٹ صرف
  /// اس وقت بنتا ہے جب وہ اسکرین پر آنے والی ہو (سست رینڈرنگ) — ورنہ
  /// تفسیر نمونه جیسا بڑا اندراج (دس لاکھ حروف سے زیادہ) کھولتے ہی ہزاروں
  /// وجٹ ایک ساتھ بن کر ایپ ہینگ/کریش ہو جاتی تھی۔
  late final List<Widget Function(BuildContext)> _lineBuilders;

  @override
  void initState() {
    super.initState();
    _title = str(widget.item['title']);
    _sub = str(widget.item['subtitle']);
    _body = str(widget.item['body']);
    // قرآن و حدیث سیکشن: قرآنی عربی و حدیثی عربی پر کمپیوٹر آواز بالکل نہیں
    // (آیات پر اصل تلاوت، باقی عربی بے اسپیکر) — ترجمہ/شرح کی آواز بدستور۔
    // تفسیر نمونه Books میں منتقل ہو جائے تب بھی یہی تحفظات رہیں، اس لیے
    // عنوان میں «تفسیر» ہو تو بھی یہی اصول لاگو ہوتا ہے۔
    _quranSection = _title.contains('تفسیر') ||
        repo.list('quran').any((e) =>
            identical(e, widget.item) ||
            (str(e['title']) == _title && str(e['subtitle']) == _sub));
    _isTafsir = _title.contains('تفسیر');
    _lineBuilders = _buildLineBuilders(_body);
  }

  @override
  Widget build(BuildContext context) {
    final title = _title;
    final sub = _sub;
    final full = '$_title\n\n$_body';
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          IconButton(
            tooltip: 'پورا سبق کاپی کریں',
            icon: const Icon(Icons.copy_rounded),
            onPressed: () => copyText(context, full),
          ),
          IconButton(
            tooltip: 'شیئر',
            icon: const Icon(Icons.ios_share_rounded),
            onPressed: () => shareText(full),
          ),
        ],
      ),
      body: CustomScrollView(
        slivers: [
          // رنگین سرخی پٹی
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
            sliver: SliverToBoxAdapter(
              child: Container(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.deepTeal, AppColors.teal],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(
                  color: AppColors.teal.withAlpha(60),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('📖', style: TextStyle(fontSize: 26)),
                const SizedBox(height: 6),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    height: 1.6,
                  ),
                ),
                if (sub.isNotEmpty)
                  Text(
                    sub,
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.white.withAlpha(210),
                      height: 1.8,
                    ),
                  ),
              ],
            ),
          ),
            ),
          ),
          // کتاب کا صفحہ — ایک ہی بہاؤ میں سارا سبق؛ سطریں سست رینڈرنگ سے
          // صرف نظر آنے پر بنتی ہیں، کارڈ کا پس منظر/سایہ ایک ہی رہتا ہے
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            sliver: DecoratedSliver(
              decoration: BoxDecoration(
                color: cardFill(context),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: cs.outlineVariant.withAlpha(110)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withAlpha(14),
                    blurRadius: 14,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              sliver: SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 22),
                sliver: SliverList.builder(
                  itemCount: _lineBuilders.length,
                  itemBuilder: (ctx, i) => _lineBuilders[i](ctx),
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
            sliver: SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  OutlinedButton.icon(
                    onPressed: () => copyText(context, full),
                    icon: const Icon(Icons.copy_rounded),
                    label: const Text('پورا سبق کاپی کریں'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: () => openFeedback(context, full),
                    icon: const Icon(Icons.edit_note_rounded),
                    label: const Text('تصحیح / اضافے کی تجویز'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// مشق والی سطروں کا رنگ — سنہری/روشن پیلا (موڈ کے مطابق)،
  /// تاکہ کتاب کے عام متن سے الگ اور دونوں موڈز میں صاف نظر آئیں
  Color _exerciseColor(BuildContext context) => goldAccentColor(context);

  bool _isExerciseStart(String line) =>
      line.contains('مشق') ||
      line.contains('کامل کنید') ||
      line.contains('انتخاب کنید') ||
      line.contains('بنویسید') ||
      line.contains('......');

  bool _isExerciseEnd(String line) =>
      line.contains('گوش کنید') ||
      line.contains('آوازیں') ||
      line.contains('توجّه') ||
      line.startsWith('بخوانید') ||
      line.startsWith('درسِ');

  /// تفسیر میں ترجمے کا رنگ — نیلا (دونوں موڈز میں صاف نظر آئے)
  Color _tarjumaColor(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFF90CAF9)
          : const Color(0xFF1565C0);

  /// تفسیر میں شرح/توضیحات کا رنگ — سبز (آیت سنہری، ترجمہ نیلا، شرح سبز)
  Color _sharhColor(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFFA5D6A7)
          : const Color(0xFF2E7D32);

  /// سطر کی زبان آواز کے لیے: خالص لاطینی متن انگریزی، ورنہ ایپ کی زبان (فارسی)
  String _speakLang(String s) =>
      (!RegExp(r'[؀-ۿ]').hasMatch(s) && RegExp(r'[a-zA-Z]').hasMatch(s))
          ? 'en'
          : 'fa';

  Widget _tafsirLine(BuildContext context,
      {required String label,
      required String text,
      required bool urdu,
      required Color color,
      bool quranSection = false}) {
    // قرآن سیکشن میں اردو سطر کے اندر آئے قرآنی عربی الفاظ اردو آواز
    // نہیں بولتی — صرف اردو حصہ بولا جاتا ہے (ڈسپلے متن بعینہٖ رہتا ہے)
    final spoken = urdu && quranSection ? urduSpeechText(text) : text;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w800, color: color)),
                if (text.isNotEmpty)
                  urdu
                      ? UrduTapText(
                          ur: text,
                          style: urStyle(size: 16.5, color: color),
                          hideFaSpeaker: quranSection)
                      : WordTapText(
                          fa: text,
                          style: faStyle(size: 19, color: color),
                          hideFaSpeaker: quranSection),
              ],
            ),
          ),
          // ترجمہ/شرح کی سطر براہ راست سننے کے لیے — اردو سطر اردو آواز میں۔
          // قرآن سیکشن میں فارسی شرح کی آواز بدستور، مگر نقل شدہ عربی
          // (آیت/عبارت) پر کوئی کمپیوٹر آواز نہیں۔
          if (text.isNotEmpty &&
              (urdu
                  ? spoken.isNotEmpty
                  : (!quranSection ||
                      _speakLang(text) == 'en' ||
                      _persianLike(text))))
            SpeakButton(
                text: spoken, lang: urdu ? 'ur' : _speakLang(text), size: 20),
        ],
      ),
    );
  }

  Widget _tafsirPlain(BuildContext context, String line,
      {required bool urdu, Color? color, bool quranSection = false}) {
    final c = color ?? _sharhColor(context);
    // اردو سطر میں آئے قرآنی عربی الفاظ اردو آواز نہیں بولتی (اوپر دیکھیں)
    final spoken = urdu && quranSection ? urduSpeechText(line) : line;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: urdu
                ? UrduTapText(
                    ur: line,
                    style: urStyle(size: 16.5, color: c),
                    hideFaSpeaker: quranSection)
                : WordTapText(
                    fa: line,
                    style: faStyle(size: 19, color: c),
                    hideFaSpeaker: quranSection),
          ),
          if (urdu
              ? spoken.isNotEmpty
              : (!quranSection ||
                  _speakLang(line) == 'en' ||
                  _persianLike(line)))
            SpeakButton(
                text: spoken, lang: urdu ? 'ur' : _speakLang(line), size: 20),
        ],
      ),
    );
  }

  /// سطروں کی درجہ بندی — نتیجہ وجٹ نہیں، وجٹ بنانے والے فنکشن ہیں؛
  /// اصل وجٹ SliverList.builder صرف نظر آنے والی سطروں کے لیے بناتا ہے۔
  List<Widget Function(BuildContext)> _buildLineBuilders(String body) {
    final out = <Widget Function(BuildContext)>[];
    var inExercise = false;
    var tafsirUrduSharah = false;
    final seenTafsirLabels = <String>{};
    for (final raw in body.split('\n')) {
      final line = raw.trim();
      if (line.isEmpty) {
        out.add((_) => const SizedBox(height: 10));
        continue;
      }
      if (_isExerciseStart(line)) inExercise = true;
      if (_isExerciseEnd(line)) inExercise = false;
      final ex = inExercise;
      // مزین سرخی ﴿ … ﴾ — آیت کارڈ: میچ پر اصل تلاوت + ٹچ ایبل الفاظ،
      // ورنہ سادہ سنہرا کارڈ؛ قرآنی عربی پر کمپیوٹر آواز کبھی نہیں
      final orn = RegExp(r'^﴿\s*(.+?)\s*﴾$').firstMatch(line);
      if (orn != null) {
        final ayahText = orn.group(1)!;
        out.add((ctx) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: AyahCard(text: ayahText),
            ));
        continue;
      }
      // فاصلہ سطر — صرف ۞ نشانات
      if (line.replaceAll(' ', '') == '۞۞۞' || line == '۞') {
        out.add((ctx) => _ornamentDivider(ctx));
        continue;
      }
      // تفسیر (مثلاً تفسیر نمونه): آیت سنہری (اوپر مزین کارڈ)،
      // ترجمہ نیلا، شرح/توضیحات سبز — تینوں رنگ الگ الگ
      if (_isTafsir) {
        if (RegExp(r'^سوره .+ — ').hasMatch(line)) {
          tafsirUrduSharah = false;
          seenTafsirLabels.clear();
          out.add((ctx) => _heading(ctx, line));
          continue;
        }
        final ci = line.indexOf(':');
        final ciF = line.indexOf('：');
        final colon = ci < 0 ? ciF : (ciF < 0 ? ci : (ci < ciF ? ci : ciF));
        String? label;
        String rest = line;
        if (colon > 0) {
          label = line.substring(0, colon + 1);
          rest = line.substring(colon + 1).trim();
        }
        if (label == 'ترجمه:' ||
            label == 'اردو ترجمہ:' ||
            label == 'توضیحات:' ||
            label == 'اردو شرح:') {
          final isTarj = label == 'ترجمه:' || label == 'اردو ترجمہ:';
          final isUrduLabel = label == 'اردو ترجمہ:' || label == 'اردو شرح:';
          if (label == 'توضیحات:') tafsirUrduSharah = false;
          if (label == 'اردو شرح:') tafsirUrduSharah = true;
          final lbl = label!;
          final rst = rest;
          if (seenTafsirLabels.contains(label)) {
            // دہرا لیبل (پیراگراف وار گتھی ہوئی شرح) — لیبل دوبارہ نہ دکھاؤ،
            // صرف متن اسی رنگ و خط میں
            if (rst.isNotEmpty) {
              out.add((ctx) => _tafsirPlain(ctx, rst,
                  urdu: isUrduLabel,
                  color: isTarj ? _tarjumaColor(ctx) : _sharhColor(ctx),
                  quranSection: _quranSection));
            }
          } else {
            seenTafsirLabels.add(lbl);
            out.add((ctx) => _tafsirLine(ctx,
                label: lbl,
                text: rst,
                urdu: isUrduLabel,
                color: isTarj ? _tarjumaColor(ctx) : _sharhColor(ctx),
                quranSection: _quranSection));
          }
          continue;
        }
        final tu = tafsirUrduSharah;
        out.add((ctx) =>
            _tafsirPlain(ctx, line, urdu: tu, quranSection: _quranSection));
        continue;
      }
      // عنوانی سطر (آخر میں :) — داخلے سے پہلے جانچو
      if (line.endsWith(':') || line.endsWith('：')) {
        out.add((ctx) => _heading(ctx, line, exercise: ex));
        continue;
      }
      if (line.contains(' — ')) {
        for (final seg in line.split('؛')) {
          final s = seg.trim();
          if (s.isNotEmpty) {
            out.add((ctx) =>
                _entry(ctx, s, exercise: ex, quranSection: _quranSection));
          }
        }
        continue;
      }
      if (line.contains('آوازیں')) {
        out.add((ctx) => _soundStrip(ctx, line));
        continue;
      }
      out.add((ctx) =>
          _prose(ctx, line, exercise: ex, quranSection: _quranSection));
    }
    return out;
  }

  Widget _heading(BuildContext context, String line, {bool exercise = false}) {
    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 5,
            height: 26,
            margin: const EdgeInsets.only(left: 10, top: 4),
            decoration: BoxDecoration(
              color: goldAccentColor(context),
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          Expanded(
            child: Text(
              line,
              style: TextStyle(
                fontSize: 18.5,
                fontWeight: FontWeight.w800,
                color: exercise
                    ? _exerciseColor(context)
                    : contentHeadingColor(context),
                height: 1.9,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// سنہری فاصلہ سطر ۞ ۞ ۞
  Widget _ornamentDivider(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Center(
        child: Text(
          '۞ ۞ ۞',
          style: TextStyle(
            fontSize: 15,
            letterSpacing: 4,
            color: goldAccentColor(context).withAlpha(200),
          ),
        ),
      ),
    );
  }

  Widget _soundStrip(BuildContext context, String line) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.saffron.withAlpha(dark ? 52 : 28),
        borderRadius: BorderRadius.circular(14),
        border:
            Border.all(color: AppColors.saffron.withAlpha(dark ? 150 : 90)),
      ),
      child: Text(
        line,
        // ڈارک موڈ میں باکس کے اندر بھی متن خالص سفید — مدھم teal ختم
        style: faStyle(
            size: 19, color: dark ? Colors.white : AppColors.deepTeal),
      ),
    );
  }

  Widget _prose(BuildContext context, String line,
      {bool exercise = false, bool quranSection = false}) {
    // قرآن سیکشن میں اردو سطر کے اندر آئے قرآنی عربی الفاظ (مثلاً تعلیم
    // القرآن کی گرامری تحلیل) اردو آواز نہیں بولتی — صرف اردو حصہ بولے گا
    final spoken = quranSection ? urduSpeechText(line) : line;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: UrduTapText(
              ur: line,
              style: urStyle(
                  size: 16.5,
                  color: exercise
                      ? _exerciseColor(context)
                      : urBodyColor(context)),
              hideFaSpeaker: quranSection,
            ),
          ),
          // اردو نثر/وضاحت کی سطر اردو آواز میں سننے کے لیے — قرآن سیکشن
          // میں مکمل اعراب والی خالص عربی سطر (حدیث/عبارت) بے اسپیکر رہتی ہے
          if (!quranSection ||
              (_urduProseLine(line) && spoken.isNotEmpty))
            SpeakButton(text: spoken, lang: 'ur', size: 19),
        ],
      ),
    );
  }

  /// ایک داخلہ: فارسی — رومن — اردو (رومن نہ ہو تو فارسی — اردو)
  Widget _entry(BuildContext context, String seg,
      {bool exercise = false, bool quranSection = false}) {
    var parts = seg.split(' — ');
    String fa, ur;
    String? ro;
    // زبان کی پہچان — ہر اسپیکر بٹن صرف اپنی زبان کا متن بولے، اس لیے
    // فارسی/اردو کی سرحد درست نکالنا ضروری ہے۔ اردو کے مخصوص حروف
    // (ٹ ڈ ڑ ھ ے) فارسی/عربی میں نہیں ہوتے؛ اردو کے عام الفاظ بھی نشانی ہیں۔
    bool urduLike(String s) {
      if (RegExp(r'[ٹڈڑھے]').hasMatch(s)) return true;
      final hits = RegExp(
              r'(?:^|\s)(ہے|ہیں|کا|کی|کے|میں|نے|اور|یہ|وہ|نہیں|بھی|سے|پر|کو|تھا|تھی|ہو|کر|گا|گی|گے)(?=\s|$|[۔،؟!؛:])')
          .allMatches(s)
          .length;
      return hits >= 2;
    }

    // آخری حصہ خالص لاطینی ہو تو وہ رومن ہے، اردو نہیں
    // (مثلاً حروفِ تہجی کی سطر: «۱۔ ا — اَلِف — alef»)
    if (parts.length >= 2 &&
        RegExp(r'[a-zA-Z]').hasMatch(parts.last) &&
        !RegExp(r'[؀-ۿ]').hasMatch(parts.last)) {
      ro = parts.removeLast();
    }
    if (parts.length >= 3 &&
        RegExp(r'[a-zA-Z]').hasMatch(parts[parts.length - 2])) {
      fa = parts.sublist(0, parts.length - 2).join(' — ');
      ro = parts[parts.length - 2];
      ur = parts[parts.length - 1];
    } else if (parts.length >= 2) {
      // اردو درمیان سے بھی شروع ہو سکتی ہے — اردو متن کے اندر « — » آ جائے
      // تو پرانا طریقہ اردو کا ابتدائی حصہ فارسی میں ملا دیتا تھا اور
      // فارسی بٹن اردو بھی پڑھ دیتا تھا۔ اردو نما حصے سے آگے سب اردو ہے۔
      var urStart = -1;
      for (var i = 1; i < parts.length; i++) {
        if (urduLike(parts[i])) {
          urStart = i;
          break;
        }
      }
      if (urStart > 0) {
        fa = parts.sublist(0, urStart).join(' — ');
        ur = parts.sublist(urStart).join(' — ');
      } else if (ro != null) {
        // رومن الگ ہو چکی اور کوئی حصہ اردو نما نہیں — باقی سب فارسی ہے
        // (مثلاً «۱۔ ا — اَلِف»: اَلِف فارسی نام ہے، اردو نہیں)
        fa = parts.join(' — ');
        ur = '';
      } else {
        fa = parts.sublist(0, parts.length - 1).join(' — ');
        ur = parts[parts.length - 1];
      }
    } else {
      fa = parts[0];
      ur = '';
    }
    // پوری سطر ہی اردو نثر ہو (گرامر وضاحت وغیرہ) تو «فارسی» حصہ بھی اصل
    // میں اردو ہے — اسے اردو میں ملا دو: فارسی بٹن (خالی متن) خودکار بند
    // رہے گا اور اردو بٹن پوری سطر پڑھے گا۔
    if (fa.isNotEmpty && urduLike(fa)) {
      ur = ur.isEmpty ? fa : '$fa — $ur';
      fa = '';
    }
    // لیبل الگ کرو، جیسے «پلیٹ: آن بشقاب است»
    String? label;
    final ci = fa.indexOf(': ');
    if (ci > 0 && ci < 14) {
      label = fa.substring(0, ci);
      fa = fa.substring(ci + 2);
    }
    // نمبر الگ کرو، جیسے «۱۔ آب»
    String? num;
    final m = RegExp(r'^([۰-۹0-9]+۔)\s*').firstMatch(fa);
    if (m != null) {
      num = m.group(1);
      fa = fa.substring(m.end);
    }
    // قرآن سیکشن میں اردو حصے کے اندر آئے قرآنی عربی الفاظ اردو آواز نہ بولے
    final urSpoken = quranSection ? urduSpeechText(ur) : ur;
    final row = Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (num != null)
            Padding(
              padding: const EdgeInsets.only(left: 8, top: 5),
              child: Text(
                num,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: goldAccentColor(context),
                ),
              ),
            ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (label != null)
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                      color: exercise
                          ? _exerciseColor(context)
                          : labelAccentColor(context),
                    ),
                  ),
                WordTapText(
                    fa: fa,
                    style: faStyle(
                        size: 21,
                        color: exercise
                            ? _exerciseColor(context)
                            : faBodyColor(context)),
                    hideFaSpeaker: quranSection),
                if (ro != null && ro.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 1),
                    child: Text(
                      ro,
                      style: TextStyle(
                        fontSize: 14,
                        fontStyle: FontStyle.italic,
                        color: exercise
                            ? _exerciseColor(context)
                            : romanBodyColor(context),
                        fontWeight: FontWeight.w600,
                      ),
                      textDirection: TextDirection.ltr,
                    ),
                  ),
                if (ur.isNotEmpty)
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: UrduTapText(
                          ur: ur,
                          style: urStyle(
                              size: 16,
                              color: exercise
                                  ? _exerciseColor(context)
                                  : urBodyColor(context)),
                          hideFaSpeaker: quranSection,
                        ),
                      ),
                      if (urSpoken.isNotEmpty)
                        SpeakButton(text: urSpoken, lang: 'ur', size: 19),
                    ],
                  ),
              ],
            ),
          ),
          // پوری سطر (فارسی/انگریزی) براہ راست سننے کے لیے اسپیکر بٹن —
          // قرآن سیکشن میں عربی ٹکڑے پر کمپیوٹر آواز نہیں (صرف ترجمہ بولے گا)
          if (!quranSection)
            SpeakButton(text: fa, lang: _speakLang(fa), size: 20),
        ],
      ),
    );
    // پورا داخلہ ٹچ کرنے پر جملے کی مکمل تفصیل (معانی + گرامر) کھلتی ہے؛
    // انفرادی الفاظ پر ٹچ ان کے اپنے معنی کھولتا ہے
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => openSentenceDetail(context,
            fa: fa, roman: ro, ur: ur, hideFaSpeaker: quranSection),
        child: row,
      ),
    );
  }
}

/// قرآن سیکشن کی نثری سطر اردو/وضاحت ہے یا خالص عربی؟
/// اردو نشانی (مخصوص حروف یا عام اردو لفظ) ہو تو اردو؛ ورنہ اعراب کی
/// کثافت دیکھو — مکمل اعراب والی سطر عربی عبارت ہے، بے اسپیکر رہے گی۔
bool _urduProseLine(String s) {
  if (RegExp(r'[ٹڈڑھے]').hasMatch(s)) return true;
  final hits = RegExp(
          r'(?:^|\s)(ہے|ہیں|کا|کی|کے|میں|نے|اور|یہ|وہ|نہیں|بھی|سے|پر|کو|تھا|تھی|ہو|کر|گا|گی|گے)(?=\s|$|[۔،؟!؛:])')
      .allMatches(s)
      .length;
  if (hits >= 1) return true;
  var marks = 0, letters = 0;
  for (final r in s.runes) {
    if ((r >= 0x064B && r <= 0x065F) || r == 0x0670 || (r >= 0x06D6 && r <= 0x06ED)) {
      marks++;
    }
    if (r >= 0x0621 && r <= 0x06D3) letters++;
  }
  if (letters == 0) return true;
  return marks / letters < 0.25;
}

/// سطر فارسی شرح ہے؟ (تفسیر کے لیے) — فارسی مخصوص حروف یا فارسی
/// شناختی الفاظ؛ نقل شدہ عربی عبارت ان سے خالی ہوتی ہے۔
bool _persianLike(String s) {
  if (RegExp(r'[گچپژ]').hasMatch(s)) return true;
  const markers = {
    'است', 'نیست', 'بود', 'باشد', 'شود', 'خواهد', 'زیرا', 'چون', 'اگر',
    'اما', 'نیز', 'این', 'آن', 'سوره', 'آیه', 'مى', 'می', 'ها', 'هاى',
    'را', 'به', 'از', 'در', 'که', 'تا', 'بر', 'خود', 'هر', 'او', 'آنها',
    'اینها', 'دیگر', 'براى', 'باید', 'کرده',
  };
  for (final t in s.split(RegExp(r'[\s،۔؛:؟!«»()]+'))) {
    if (markers.contains(t)) return true;
  }
  return false;
}
