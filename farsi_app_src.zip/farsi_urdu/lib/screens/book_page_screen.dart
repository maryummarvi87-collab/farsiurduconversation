import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/sentence_detail.dart';
import '../widgets/word_tap_text.dart';

/// کتابی سبق کا صفحہ — کتاب کی طرح سیدھا بہتا ہوا متن، خوبصورت رنگوں میں۔
/// ہر سطر: اعراب‌دار فارسی — رومن — اردو معنی؛ فارسی لفظ پر ٹچ کرنے سے معنی کھلتا ہے۔
/// اوپر کاپی اور شیئر کے بٹن — پورا سبق ایک ٹچ میں کاپی ہو جاتا ہے۔
class BookPageScreen extends StatelessWidget {
  final Map<String, dynamic> item;
  const BookPageScreen({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final title = str(item['title']);
    final sub = str(item['subtitle']);
    final body = str(item['body']);
    final full = '$title\n\n$body';
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          IconButton(
            tooltip: 'پورا سبق کاپی کریں',
            icon: const Icon(Icons.copy_rounded),
            onPressed: () => copyText(context, full),
          ),
          IconButton(
            tooltip: 'شیئر',
            icon: const Icon(Icons.ios_share_rounded),
            onPressed: () => shareText(full),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          // رنگین سرخی پٹی
          Container(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.deepTeal, AppColors.teal],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(
                  color: AppColors.teal.withAlpha(60),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('📖', style: TextStyle(fontSize: 26)),
                const SizedBox(height: 6),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    height: 1.6,
                  ),
                ),
                if (sub.isNotEmpty)
                  Text(
                    sub,
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.white.withAlpha(210),
                      height: 1.8,
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          // کتاب کا صفحہ — ایک ہی بہاؤ میں سارا سبق
          Container(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 22),
            decoration: BoxDecoration(
              color: cardFill(context),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: cs.outlineVariant.withAlpha(110)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withAlpha(14),
                  blurRadius: 14,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: _buildLines(context, body, title.contains('تفسیر')),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => copyText(context, full),
            icon: const Icon(Icons.copy_rounded),
            label: const Text('پورا سبق کاپی کریں'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => openFeedback(context, full),
            icon: const Icon(Icons.edit_note_rounded),
            label: const Text('تصحیح / اضافے کی تجویز'),
          ),
        ],
      ),
    );
  }

  /// مشق والی سطروں کا رنگ — سنہری/روشن پیلا (موڈ کے مطابق)،
  /// تاکہ کتاب کے عام متن سے الگ اور دونوں موڈز میں صاف نظر آئیں
  Color _exerciseColor(BuildContext context) => goldAccentColor(context);

  bool _isExerciseStart(String line) =>
      line.contains('مشق') ||
      line.contains('کامل کنید') ||
      line.contains('انتخاب کنید') ||
      line.contains('بنویسید') ||
      line.contains('......');

  bool _isExerciseEnd(String line) =>
      line.contains('گوش کنید') ||
      line.contains('آوازیں') ||
      line.contains('توجّه') ||
      line.startsWith('بخوانید') ||
      line.startsWith('درسِ');

  /// تفسیر میں ترجمے کا رنگ — نیلا (دونوں موڈز میں صاف نظر آئے)
  Color _tarjumaColor(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFF90CAF9)
          : const Color(0xFF1565C0);

  /// تفسیر میں شرح/توضیحات کا رنگ — سبز (آیت سنہری، ترجمہ نیلا، شرح سبز)
  Color _sharhColor(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFFA5D6A7)
          : const Color(0xFF2E7D32);

  Widget _tafsirLine(BuildContext context,
      {required String label,
      required String text,
      required bool urdu,
      required Color color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: TextStyle(
                  fontSize: 15, fontWeight: FontWeight.w800, color: color)),
          if (text.isNotEmpty)
            urdu
                ? UrduTapText(ur: text, style: urStyle(size: 16.5, color: color))
                : WordTapText(fa: text, style: faStyle(size: 19, color: color)),
        ],
      ),
    );
  }

  Widget _tafsirPlain(BuildContext context, String line,
      {required bool urdu, Color? color}) {
    final c = color ?? _sharhColor(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: urdu
          ? UrduTapText(ur: line, style: urStyle(size: 16.5, color: c))
          : WordTapText(fa: line, style: faStyle(size: 19, color: c)),
    );
  }

  List<Widget> _buildLines(BuildContext context, String body, bool isTafsir) {
    final out = <Widget>[];
    var inExercise = false;
    var tafsirUrduSharah = false;
    final seenTafsirLabels = <String>{};
    for (final raw in body.split('\n')) {
      final line = raw.trim();
      if (line.isEmpty) {
        out.add(const SizedBox(height: 10));
        continue;
      }
      if (_isExerciseStart(line)) inExercise = true;
      if (_isExerciseEnd(line)) inExercise = false;
      // مزین سرخی ﴿ … ﴾ — سنہرے کارڈ میں (تعلیم القرآن وغیرہ کے لیے)
      final orn = RegExp(r'^﴿\s*(.+?)\s*﴾$').firstMatch(line);
      if (orn != null) {
        out.add(_ornamentTitle(context, orn.group(1)!));
        continue;
      }
      // فاصلہ سطر — صرف ۞ نشانات
      if (line.replaceAll(' ', '') == '۞۞۞' || line == '۞') {
        out.add(_ornamentDivider(context));
        continue;
      }
      // تفسیر (مثلاً تفسیر نمونه): آیت سنہری (اوپر مزین کارڈ)،
      // ترجمہ نیلا، شرح/توضیحات سبز — تینوں رنگ الگ الگ
      if (isTafsir) {
        if (RegExp(r'^سوره .+ — ').hasMatch(line)) {
          tafsirUrduSharah = false;
          seenTafsirLabels.clear();
          out.add(_heading(context, line));
          continue;
        }
        final ci = line.indexOf(':');
        final ciF = line.indexOf('：');
        final colon = ci < 0 ? ciF : (ciF < 0 ? ci : (ci < ciF ? ci : ciF));
        String? label;
        String rest = line;
        if (colon > 0) {
          label = line.substring(0, colon + 1);
          rest = line.substring(colon + 1).trim();
        }
        if (label == 'ترجمه:' ||
            label == 'اردو ترجمہ:' ||
            label == 'توضیحات:' ||
            label == 'اردو شرح:') {
          final isTarj = label == 'ترجمه:' || label == 'اردو ترجمہ:';
          final isUrduLabel = label == 'اردو ترجمہ:' || label == 'اردو شرح:';
          if (label == 'توضیحات:') tafsirUrduSharah = false;
          if (label == 'اردو شرح:') tafsirUrduSharah = true;
          final color =
              isTarj ? _tarjumaColor(context) : _sharhColor(context);
          if (seenTafsirLabels.contains(label)) {
            // دہرا لیبل (پیراگراف وار گتھی ہوئی شرح) — لیبل دوبارہ نہ دکھاؤ،
            // صرف متن اسی رنگ و خط میں
            if (rest.isNotEmpty) {
              out.add(_tafsirPlain(context, rest,
                  urdu: isUrduLabel, color: color));
            }
          } else {
            seenTafsirLabels.add(label!);
            out.add(_tafsirLine(context,
                label: label,
                text: rest,
                urdu: isUrduLabel,
                color: color));
          }
          continue;
        }
        out.add(_tafsirPlain(context, line, urdu: tafsirUrduSharah));
        continue;
      }
      // عنوانی سطر (آخر میں :) — داخلے سے پہلے جانچو
      if (line.endsWith(':') || line.endsWith('：')) {
        if (!inExercise && !_isExerciseStart(line)) inExercise = false;
        out.add(_heading(context, line, exercise: inExercise));
        continue;
      }
      if (line.contains(' — ')) {
        for (final seg in line.split('؛')) {
          final s = seg.trim();
          if (s.isNotEmpty) out.add(_entry(context, s, exercise: inExercise));
        }
        continue;
      }
      if (line.contains('آوازیں')) {
        out.add(_soundStrip(context, line));
        continue;
      }
      out.add(_prose(context, line, exercise: inExercise));
    }
    return out;
  }

  Widget _heading(BuildContext context, String line, {bool exercise = false}) {
    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 5,
            height: 26,
            margin: const EdgeInsets.only(left: 10, top: 4),
            decoration: BoxDecoration(
              color: goldAccentColor(context),
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          Expanded(
            child: Text(
              line,
              style: TextStyle(
                fontSize: 18.5,
                fontWeight: FontWeight.w800,
                color: exercise
                    ? _exerciseColor(context)
                    : contentHeadingColor(context),
                height: 1.9,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// مزین سرخی کارڈ — عربی متن (اعراب بھرپور یا طویل سطر) نورِ قرآن خط میں
  /// سنہرا؛ اردو سرخی نستعلیق میں گہری سرخی رنگ کے ساتھ
  Widget _ornamentTitle(BuildContext context, String text) {
    final diacritics =
        RegExp(r'[ً-ْٰۖ-ۭ]').allMatches(text).length;
    final letters = text.replaceAll(RegExp(r'\s'), '').length;
    final isArabic =
        text.length > 60 || (letters > 0 && diacritics / letters >= 0.2);
    final gold = goldAccentColor(context);
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: gold.withAlpha(170), width: 1.2),
      ),
      child: Center(
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: isArabic
              ? TextStyle(
                  fontFamily: 'NoorQuran',
                  fontSize: 27,
                  height: 1.9,
                  fontWeight: FontWeight.w700,
                  color: gold,
                )
              : urStyle(size: 19, color: contentHeadingColor(context))
                  .copyWith(fontWeight: FontWeight.w800),
        ),
      ),
    );
  }

  /// سنہری فاصلہ سطر ۞ ۞ ۞
  Widget _ornamentDivider(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Center(
        child: Text(
          '۞ ۞ ۞',
          style: TextStyle(
            fontSize: 15,
            letterSpacing: 4,
            color: goldAccentColor(context).withAlpha(200),
          ),
        ),
      ),
    );
  }

  Widget _soundStrip(BuildContext context, String line) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.saffron.withAlpha(dark ? 52 : 28),
        borderRadius: BorderRadius.circular(14),
        border:
            Border.all(color: AppColors.saffron.withAlpha(dark ? 150 : 90)),
      ),
      child: Text(
        line,
        // ڈارک موڈ میں باکس کے اندر بھی متن خالص سفید — مدھم teal ختم
        style: faStyle(
            size: 19, color: dark ? Colors.white : AppColors.deepTeal),
      ),
    );
  }

  Widget _prose(BuildContext context, String line, {bool exercise = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: UrduTapText(
        ur: line,
        style: urStyle(
            size: 16.5,
            color:
                exercise ? _exerciseColor(context) : urBodyColor(context)),
      ),
    );
  }

  /// ایک داخلہ: فارسی — رومن — اردو (رومن نہ ہو تو فارسی — اردو)
  Widget _entry(BuildContext context, String seg, {bool exercise = false}) {
    final parts = seg.split(' — ');
    String fa, ur;
    String? ro;
    if (parts.length >= 3 &&
        RegExp(r'[a-zA-Z]').hasMatch(parts[parts.length - 2])) {
      fa = parts.sublist(0, parts.length - 2).join(' — ');
      ro = parts[parts.length - 2];
      ur = parts[parts.length - 1];
    } else if (parts.length >= 2) {
      fa = parts.sublist(0, parts.length - 1).join(' — ');
      ur = parts[parts.length - 1];
    } else {
      fa = parts[0];
      ur = '';
    }
    // لیبل الگ کرو، جیسے «پلیٹ: آن بشقاب است»
    String? label;
    final ci = fa.indexOf(': ');
    if (ci > 0 && ci < 14) {
      label = fa.substring(0, ci);
      fa = fa.substring(ci + 2);
    }
    // نمبر الگ کرو، جیسے «۱۔ آب»
    String? num;
    final m = RegExp(r'^([۰-۹0-9]+۔)\s*').firstMatch(fa);
    if (m != null) {
      num = m.group(1);
      fa = fa.substring(m.end);
    }
    final row = Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (num != null)
            Padding(
              padding: const EdgeInsets.only(left: 8, top: 5),
              child: Text(
                num,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: goldAccentColor(context),
                ),
              ),
            ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (label != null)
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                      color: exercise
                          ? _exerciseColor(context)
                          : labelAccentColor(context),
                    ),
                  ),
                WordTapText(
                    fa: fa,
                    style: faStyle(
                        size: 21,
                        color: exercise
                            ? _exerciseColor(context)
                            : faBodyColor(context))),
                if (ro != null && ro.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 1),
                    child: Text(
                      ro,
                      style: TextStyle(
                        fontSize: 14,
                        fontStyle: FontStyle.italic,
                        color: exercise
                            ? _exerciseColor(context)
                            : romanBodyColor(context),
                        fontWeight: FontWeight.w600,
                      ),
                      textDirection: TextDirection.ltr,
                    ),
                  ),
                if (ur.isNotEmpty)
                  UrduTapText(
                    ur: ur,
                    style: urStyle(
                        size: 16,
                        color: exercise
                            ? _exerciseColor(context)
                            : urBodyColor(context)),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
    // پورا داخلہ ٹچ کرنے پر جملے کی مکمل تفصیل (معانی + گرامر) کھلتی ہے؛
    // انفرادی الفاظ پر ٹچ ان کے اپنے معنی کھولتا ہے
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => openSentenceDetail(context, fa: fa, roman: ro, ur: ur),
        child: row,
      ),
    );
  }
}
