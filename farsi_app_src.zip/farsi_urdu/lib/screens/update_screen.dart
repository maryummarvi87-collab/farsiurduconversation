import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';

/// آن لائن اپڈیٹ: نیا مواد (اسباق، لغت وغیرہ) انٹرنیٹ سے حاصل کرتا ہے
class UpdateScreen extends StatefulWidget {
  const UpdateScreen({super.key});

  @override
  State<UpdateScreen> createState() => _UpdateScreenState();
}

class _UpdateScreenState extends State<UpdateScreen> {
  bool _busy = false;
  String? _msg;
  bool _ok = true;

  Future<void> _check() async {
    setState(() {
      _busy = true;
      _msg = null;
    });
    final r = await repo.checkForUpdate();
    if (!mounted) return;
    setState(() {
      _busy = false;
      _ok = r.ok;
      _msg = r.message;
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('آن لائن اپڈیٹ')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: cardFill(context),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: cs.outlineVariant.withAlpha(110)),
            ),
            child: Column(
              children: [
                Icon(Icons.cloud_download_rounded, size: 56, color: cs.primary),
                const SizedBox(height: 12),
                Text(
                  'موجودہ مواد کا ورژن: ${localDigits(repo.version)}',
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                ),
                if (repo.updated.isNotEmpty)
                  Text('آخری تازہ کاری: ${repo.updated}',
                      style: TextStyle(color: cs.outline)),
                const SizedBox(height: 18),
                FilledButton.icon(
                  onPressed: _busy ? null : _check,
                  icon: _busy
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.refresh_rounded),
                  label: const Text('اپڈیٹ چیک کریں'),
                ),
                if (_msg != null) ...[
                  const SizedBox(height: 16),
                  Text(
                    _msg!,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: _ok ? cs.primary : cs.error,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'نیا مواد انٹرنیٹ سے آ کر فون میں محفوظ ہو جاتا ہے، پھر بغیر انٹرنیٹ کے بھی چلتا ہے۔',
            textAlign: TextAlign.center,
            style: TextStyle(color: cs.outline),
          ),
        ],
      ),
    );
  }
}
