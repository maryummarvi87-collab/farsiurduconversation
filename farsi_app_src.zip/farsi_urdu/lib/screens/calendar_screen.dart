import 'package:flutter/material.dart';

import '../state.dart';
import '../theme.dart';
import '../utils/calendars.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';

/// ایرانی، عیسوی اور اسلامی کیلنڈر
class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  int _sys = 0; // 0 ایرانی، 1 عیسوی، 2 اسلامی
  late int _year;
  late int _month;
  late int _selected;

  CalSystem get _cal => calendarSystems[_sys];

  @override
  void initState() {
    super.initState();
    _selected = todayJdn();
    _syncToSelected();
  }

  void _syncToSelected() {
    final d = _cal.fromJdn(_selected);
    _year = d[0];
    _month = d[1];
  }

  void _shiftMonth(int delta) {
    setState(() {
      var y = _year;
      var m = _month + delta;
      if (m > 12) {
        m = 1;
        y += 1;
      } else if (m < 1) {
        m = 12;
        y -= 1;
      }
      _year = y;
      _month = m;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: settings,
      builder: (context, _) {
        // اسلامی ایڈجسٹمنٹ بدلنے پر مہینہ دوبارہ ترتیب دیں
        final cs = Theme.of(context).colorScheme;
        final today = todayJdn();
        final cal = _cal;
        final first = cal.toJdn(_year, _month, 1);
        final len = cal.monthLength(_year, _month);
        final lead = saturdayColumn(first);
        final other = _sys == 1 ? calendarSystems[0] : calendarSystems[1];

        final cells = <Widget>[
          for (final h in const ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'])
            Center(
              child: Text(
                h,
                style: TextStyle(
                  color: h == 'ج' ? AppColors.rose : cs.outline,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          for (var i = 0; i < lead; i++) const SizedBox.shrink(),
          for (var d = 1; d <= len; d++)
            _dayCell(context, cal, other, first + d - 1, d, today),
        ];

        final sel = _selected;
        final wd = weekdayIndex(sel);

        return Scaffold(
          appBar: AppBar(
            title: const Text('کیلنڈر'),
            actions: [
              IconButton(
                tooltip: 'آج',
                icon: const Icon(Icons.today_rounded),
                onPressed: () => setState(() {
                  _selected = todayJdn();
                  _syncToSelected();
                }),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
            children: [
              SegmentedButton<int>(
                segments: [
                  for (var i = 0; i < calendarSystems.length; i++)
                    ButtonSegment(value: i, label: Text(calendarSystems[i].label)),
                ],
                selected: {_sys},
                onSelectionChanged: (s) => setState(() {
                  _sys = s.first;
                  _syncToSelected();
                }),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.fromLTRB(8, 10, 8, 12),
                decoration: BoxDecoration(
                  color: cardFill(context),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: cs.outlineVariant.withAlpha(110)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.chevron_right_rounded),
                          onPressed: () => _shiftMonth(-1),
                        ),
                        Expanded(
                          child: Text(
                            '${cal.monthName(_month)} ${localDigits(_year)}',
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                fontSize: 19, fontWeight: FontWeight.w800),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.chevron_left_rounded),
                          onPressed: () => _shiftMonth(1),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    GridView.count(
                      crossAxisCount: 7,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      childAspectRatio: 0.82,
                      children: cells,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              _detailCard(context, sel, wd),
              if (_sys == 2) ...[
                const SizedBox(height: 14),
                _adjustCard(context),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _dayCell(BuildContext context, CalSystem cal, CalSystem other,
      int jdn, int day, int today) {
    final cs = Theme.of(context).colorScheme;
    final isToday = jdn == today;
    final isSel = jdn == _selected;
    final isFri = weekdayIndex(jdn) == 4;
    final otherDay = other.fromJdn(jdn)[2];

    Color? fill;
    Color textColor = isFri ? AppColors.rose : cs.onSurface;
    if (isSel) {
      fill = cs.primary;
      textColor = cs.onPrimary;
    } else if (isToday) {
      fill = AppColors.gold.withAlpha(60);
    }

    return Padding(
      padding: const EdgeInsets.all(2),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => setState(() => _selected = jdn),
        child: Container(
          decoration: BoxDecoration(
            color: fill,
            borderRadius: BorderRadius.circular(14),
            border: isToday && !isSel
                ? Border.all(color: AppColors.gold, width: 1.5)
                : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                localDigits(day),
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  color: textColor,
                ),
              ),
              Text(
                localDigits(otherDay),
                style: TextStyle(
                  fontSize: 10,
                  color: textColor.withAlpha(150),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _detailCard(BuildContext context, int jdn, int wd) {
    final cs = Theme.of(context).colorScheme;
    final lines = [
      for (final c in calendarSystems) '${c.label}: ${c.format(jdn)}',
    ];
    final share =
        '${weekdayFa[wd]} (${weekdayUr[wd]})\n${lines.join('\n')}';
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 14, 8, 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [AppColors.teal, AppColors.deepTeal],
        ),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${weekdayFa[wd]}  ·  ${weekdayUr[wd]}',
                  style: const TextStyle(
                    color: AppColors.gold,
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                for (final c in calendarSystems)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Text(
                      '${c.label}:  ${c.format(jdn)}',
                      style: const TextStyle(color: Colors.white, fontSize: 15),
                    ),
                  ),
              ],
            ),
          ),
          Column(
            children: [
              IconButton(
                tooltip: 'شیئر',
                icon: const Icon(Icons.ios_share_rounded, color: Colors.white),
                onPressed: () => shareText(share),
              ),
              IconButton(
                tooltip: 'کاپی',
                icon: Icon(Icons.copy_rounded, color: cs.onPrimary),
                onPressed: () => copyText(context, share),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _adjustCard(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final v = settings.hijriAdjust;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
      ),
      child: Column(
        children: [
          const Text('اسلامی تاریخ میں ایڈجسٹمنٹ',
              style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(
            'اسلامی تاریخ حسابی طریقے سے نکالی جاتی ہے؛ چاند دیکھنے کے مطابق ایک دن کا فرق ہو سکتا ہے۔',
            textAlign: TextAlign.center,
            style: TextStyle(color: cs.outline, fontSize: 13),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton.filledTonal(
                icon: const Icon(Icons.add_rounded),
                onPressed: () {
                  settings.setHijriAdjust(v + 1);
                  setState(_syncToSelected);
                },
              ),
              SizedBox(
                width: 90,
                child: Text(
                  v == 0 ? 'کوئی فرق نہیں' : '${v > 0 ? '+' : '-'}${localDigits(v.abs())} دن',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              IconButton.filledTonal(
                icon: const Icon(Icons.remove_rounded),
                onPressed: () {
                  settings.setHijriAdjust(v - 1);
                  setState(_syncToSelected);
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}
