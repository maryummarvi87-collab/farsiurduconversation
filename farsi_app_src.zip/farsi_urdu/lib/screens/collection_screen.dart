import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/repository.dart';
import '../state.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';
import 'book_page_screen.dart';
import 'mushaf_screen.dart';

/// اسباق / بول چال / کہانیاں / شاعری کی فہرست — تلاش کے ساتھ
/// ڈیٹا کی شکل: [{title, subtitle, items: [{fa, ur, who?}]}]
class CollectionScreen extends StatefulWidget {
  final String dataKey;
  final String title;
  const CollectionScreen({super.key, required this.dataKey, required this.title});

  @override
  State<CollectionScreen> createState() => _CollectionScreenState();
}

class _CollectionScreenState extends State<CollectionScreen> {
  String _q = '';

  bool _itemMatches(Map<String, dynamic> it, String nq) =>
      normalize('${str(it['fa'])} ${str(it['ur'])} ${str(it['who'])}')
          .contains(nq);

  @override
  Widget build(BuildContext context) {
    final sets = repo.list(widget.dataKey);
    final cs = Theme.of(context).colorScheme;
    final nq = normalize(_q);
    // ہر سیٹ کے ساتھ: عنوان ملا؟ اور کتنے جملے ملے؟
    final shown = <(Map<String, dynamic>, bool, int)>[];
    for (final s in sets) {
      // «کتاب» صورت اندراج (مثلاً مثنوی کا دفتر): اسباق اندر ہوں تو ان کے اشعار بھی گنے/تلاشے جائیں
      final lessons = asMaps(s['lessons']);
      final items = lessons.isEmpty
          ? asMaps(s['items'])
          : [for (final l in lessons) ...asMaps(l['items'])];
      if (nq.isEmpty) {
        shown.add((s, true, items.length));
        continue;
      }
      final titleHit = normalize(
              '${str(s['title'])} ${str(s['subtitle'])} ${str(s['body'])}')
          .contains(nq);
      final matched = items.where((it) => _itemMatches(it, nq)).length;
      if (titleHit || matched > 0) shown.add((s, titleHit, matched));
    }
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: (sets.isEmpty && widget.dataKey != 'quran')
          ? const EmptyState(
              message: 'ابھی یہاں کوئی مواد نہیں۔\nآن لائن اپڈیٹ سے نیا مواد حاصل کریں۔')
          : Column(
              children: [
                if (widget.dataKey == 'quran' && _q.isEmpty)
                  Container(
                    margin: const EdgeInsets.fromLTRB(16, 10, 16, 2),
                    decoration: BoxDecoration(
                      color: cardFill(context),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.gold.withOpacity(0.5)),
                    ),
                    child: ListTile(
                      leading: const Icon(Icons.menu_book_rounded,
                          color: AppColors.gold, size: 30),
                      title: Text('مکمل قرآن مجید — تلاوت', style: urStyle(size: 17)),
                      subtitle: Text('نورِ قرآن خط • اردو ترجمہ (جالندھری)',
                          style: urStyle(size: 12)),
                      trailing:
                          const Icon(Icons.chevron_left, color: AppColors.gold),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const MushafScreen()),
                      ),
                    ),
                  ),
                if (widget.dataKey == 'quran' && _q.isEmpty)
                  Container(
                    margin: const EdgeInsets.fromLTRB(16, 8, 16, 2),
                    decoration: BoxDecoration(
                      color: cardFill(context),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppColors.gold.withOpacity(0.5)),
                    ),
                    child: ListTile(
                      leading: const Icon(Icons.library_books_rounded,
                          color: AppColors.gold, size: 30),
                      title: Text('احادیث', style: urStyle(size: 17)),
                      subtitle: Text('کتبِ احادیث — یہاں سے آغاز ہوگا',
                          style: urStyle(size: 12)),
                      trailing:
                          const Icon(Icons.chevron_left, color: AppColors.gold),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const CollectionScreen(
                                dataKey: 'hadith_books', title: 'کتبِ احادیث')),
                      ),
                    ),
                  ),
                SearchBox(
                  hint: 'عنوان یا جملہ تلاش کریں…',
                  onChanged: (v) => setState(() => _q = v),
                ),
                Expanded(
                  child: shown.isEmpty
                      ? EmptyState(
                          message: (widget.dataKey == 'quran' && _q.isEmpty)
                              ? 'مکمل قرآن اوپر والے کارڈ سے پڑھیں۔'
                              : 'کوئی نتیجہ نہیں ملا۔')
                      : ListView.builder(
                          padding: const EdgeInsets.only(top: 4, bottom: 24),
                          itemCount: shown.length,
                          itemBuilder: (context, i) {
                            final (s, titleHit, matched) = shown[i];
                            final bookLessons = asMaps(s['lessons']);
                            final count = bookLessons.isEmpty
                                ? asMaps(s['items']).length
                                : bookLessons.fold<int>(
                                    0, (a, l) => a + asMaps(l['items']).length);
                            final sub = str(s['subtitle']);
                            final searching = nq.isNotEmpty;
                            final detail = searching && !titleHit
                                ? '${localDigits(matched)} جملے ملے'
                                : (bookLessons.isNotEmpty
                                    ? (count == 0
                                        ? '${localDigits(bookLessons.length)} اسباق'
                                        : '${localDigits(bookLessons.length)} اسباق · ${localDigits(count)} اشعار')
                                    : (str(s['body']).isNotEmpty && count == 0
                                        ? 'کتاب کا صفحہ'
                                        : '$count جملے'));
                            return Container(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 6),
                              decoration: BoxDecoration(
                                color: cardFill(context),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                    color: cs.outlineVariant.withAlpha(110)),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withAlpha(16),
                                    blurRadius: 14,
                                    offset: const Offset(0, 5),
                                  ),
                                ],
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 6),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20)),
                                leading: CircleAvatar(
                                  backgroundColor: cs.primary.withAlpha(30),
                                  foregroundColor: cs.primary,
                                  child: Text(
                                      '${localDigits(sets.indexOf(s) + 1)}',
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w800)),
                                ),
                                title: Text(str(s['title']),
                                    style: const TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700)),
                                subtitle: Text(
                                  sub.isEmpty ? detail : '$sub  ·  $detail',
                                ),
                                trailing:
                                    const Icon(Icons.chevron_left_rounded),
                                onTap: () => Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        // «کتاب» صورت اندراج (دفتر وغیرہ): پہلے اسباق کی فہرست
                                        bookLessons.isNotEmpty
                                            ? PoemBookScreen(book: s)
                                            :
                                            // کتابی سبق (سیدھا متن) — خانوں کی بجائے صفحے کی طرح
                                            str(s['body']).isNotEmpty &&
                                                    asMaps(s['items']).isEmpty
                                                ? BookPageScreen(item: s)
                                                : PhraseSetScreen(
                                                    data: s,
                                                    poetry:
                                                        widget.dataKey == 'poems',
                                                    initialQuery:
                                                        (searching && !titleHit)
                                                            ? _q
                                                            : '',
                                                  ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

/// ایک سبق / مکالمہ / کہانی / نظم کے جملے — اندر بھی تلاش
class PhraseSetScreen extends StatefulWidget {
  final Map<String, dynamic> data;
  final String initialQuery;

  /// شاعری سیکشن: فارسی و اردو کے الگ رنگ
  final bool poetry;
  const PhraseSetScreen(
      {super.key, required this.data, this.initialQuery = '', this.poetry = false});

  @override
  State<PhraseSetScreen> createState() => _PhraseSetScreenState();
}

class _PhraseSetScreenState extends State<PhraseSetScreen> {
  late String _q = widget.initialQuery;
  double _scale = 1.0;
  double? _pinchStart;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (!mounted) return;
      setState(() => _scale = p.getDouble('reader_scale') ?? 1.0);
    });
  }

  Future<void> _saveReader() async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('reader_scale', _scale);
  }

  @override
  Widget build(BuildContext context) {
    // کتابی سبق (صرف body، خانے نہیں) غلطی سے یہاں آ جائے تو کتابی صفحہ دکھائیں
    // — ورنہ سبق خالی نظر آتا ہے («کوئی جملہ نہیں ملا»)۔
    if (asMaps(widget.data['items']).isEmpty &&
        str(widget.data['body']).isNotEmpty) {
      return BookPageScreen(item: widget.data);
    }
    final items = asMaps(widget.data['items']);
    final title = str(widget.data['title']);
    final sub = str(widget.data['subtitle']);
    final nq = normalize(_q);
    final shown = nq.isEmpty
        ? items
        : items
            .where((it) => normalize(
                    '${str(it['fa'])} ${str(it['ur'])} ${str(it['who'])}')
                .contains(nq))
            .toList();
    final all = StringBuffer(title);
    for (final it in items) {
      all.write('\n\n${str(it['fa'])}\n${str(it['ur'])}');
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          IconButton(
            tooltip: Theme.of(context).brightness == Brightness.dark
                ? 'روشن انداز'
                : 'ڈارک موڈ (پوری ایپ)',
            icon: Icon(Theme.of(context).brightness == Brightness.dark
                ? Icons.light_mode_outlined
                : Icons.dark_mode_outlined),
            onPressed: () => settings.setThemeMode(
                Theme.of(context).brightness == Brightness.dark
                    ? ThemeMode.light
                    : ThemeMode.dark),
          ),
          IconButton(
            tooltip: 'پورا شیئر کریں',
            icon: const Icon(Icons.ios_share_rounded),
            onPressed: () => shareText(all.toString()),
          ),
        ],
      ),
      body: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onScaleStart: (d) => _pinchStart = _scale,
        onScaleUpdate: (d) {
          if (_pinchStart == null || d.scale == 1.0) return;
          setState(() => _scale = (_pinchStart! * d.scale).clamp(0.8, 1.8));
        },
        onScaleEnd: (_) {
          _pinchStart = null;
          _saveReader();
        },
        child: MediaQuery(
          data: MediaQuery.of(context)
              .copyWith(textScaler: TextScaler.linear(_scale)),
          child: Column(
        children: [
          SearchBox(
            hint: 'اس حصے میں تلاش کریں…',
            initialValue: widget.initialQuery,
            onChanged: (v) => setState(() => _q = v),
          ),
          Expanded(
            child: shown.isEmpty
                ? const EmptyState(message: 'کوئی جملہ نہیں ملا۔')
                : ListView(
                    padding: const EdgeInsets.only(top: 4, bottom: 28),
                    children: [
                      if (sub.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                          child: Text(sub,
                              style: TextStyle(
                                  color:
                                      Theme.of(context).colorScheme.outline)),
                        ),
                      for (final it in shown)
                        PhraseCard(
                          fa: str(it['fa']),
                          ur: str(it['ur']),
                          who: str(it['who']).isEmpty ? null : str(it['who']),
                          roman: str(it['ro']),
                          vocalized: str(it['v']),
                          words: it['w'] as List<dynamic>?,
                          poetry: widget.poetry,
                        ),
                    ],
                  ),
          ),
        ],
          ),
        ),
      ),
    );
  }
}

/// شاعری کے سیکشن میں «کتاب» صورت اندراج (مثلاً مثنوی کا ایک دفتر):
/// اسباق کی فہرست، ہر سبق اپنے اشعار کے ساتھ الگ کھلتا ہے
class PoemBookScreen extends StatelessWidget {
  final Map<String, dynamic> book;
  const PoemBookScreen({super.key, required this.book});

  @override
  Widget build(BuildContext context) {
    final lessons = asMaps(book['lessons']);
    final cs = Theme.of(context).colorScheme;
    final sub = str(book['subtitle']);
    return Scaffold(
      appBar: AppBar(title: Text(str(book['title']))),
      body: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 24),
        children: [
          if (sub.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Text(sub,
                  style: TextStyle(color: cs.outline)),
            ),
          for (var i = 0; i < lessons.length; i++)
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                color: cardFill(context),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: cs.outlineVariant.withAlpha(110)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withAlpha(16),
                    blurRadius: 14,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: ListTile(
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                leading: CircleAvatar(
                  backgroundColor: cs.primary.withAlpha(30),
                  foregroundColor: cs.primary,
                  child: Text('${localDigits(i + 1)}',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
                title: Text(str(lessons[i]['title']),
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w700)),
                subtitle: Text(
                  asMaps(lessons[i]['items']).isEmpty
                      ? (str(lessons[i]['subtitle']).isEmpty
                          ? 'کتابی سبق'
                          : str(lessons[i]['subtitle']))
                      : (str(lessons[i]['subtitle']).isEmpty
                          ? '${localDigits(asMaps(lessons[i]['items']).length)} اشعار'
                          : '${str(lessons[i]['subtitle'])}  ·  ${localDigits(asMaps(lessons[i]['items']).length)} اشعار'),
                ),
                trailing: const Icon(Icons.chevron_left_rounded),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => PhraseSetScreen(
                      data: lessons[i],
                      poetry: true,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// گرامر / مضامین کی فہرست — عنوان اور متن میں تلاش
/// ڈیٹا کی شکل: [{title, body}]
class TextCollectionScreen extends StatefulWidget {
  final String dataKey;
  final String title;
  const TextCollectionScreen({super.key, required this.dataKey, required this.title});

  @override
  State<TextCollectionScreen> createState() => _TextCollectionScreenState();
}

class _TextCollectionScreenState extends State<TextCollectionScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final items = repo.list(widget.dataKey);
    final cs = Theme.of(context).colorScheme;
    final nq = normalize(_q);
    final shown = nq.isEmpty
        ? items
        : items
            .where((it) =>
                normalize('${str(it['title'])} ${str(it['body'])}').contains(nq))
            .toList();
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: items.isEmpty
          ? const EmptyState(
              message: 'ابھی یہاں کوئی مواد نہیں۔\nآن لائن اپڈیٹ سے نیا مواد حاصل کریں۔')
          : Column(
              children: [
                SearchBox(
                  hint: 'عنوان یا متن تلاش کریں…',
                  onChanged: (v) => setState(() => _q = v),
                ),
                Expanded(
                  child: shown.isEmpty
                      ? const EmptyState(message: 'کوئی نتیجہ نہیں ملا۔')
                      : ListView.builder(
                          padding: const EdgeInsets.only(top: 4, bottom: 24),
                          itemCount: shown.length,
                          itemBuilder: (context, i) {
                            final it = shown[i];
                            return Container(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 6),
                              decoration: BoxDecoration(
                                color: cardFill(context),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                    color: cs.outlineVariant.withAlpha(110)),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withAlpha(16),
                                    blurRadius: 14,
                                    offset: const Offset(0, 5),
                                  ),
                                ],
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 6),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20)),
                                leading: CircleAvatar(
                                  backgroundColor:
                                      AppColors.gold.withAlpha(40),
                                  foregroundColor: AppColors.gold,
                                  child: const Icon(Icons.notes_rounded),
                                ),
                                title: Text(str(it['title']),
                                    style: const TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700)),
                                trailing:
                                    const Icon(Icons.chevron_left_rounded),
                                onTap: () => Navigator.of(context).push(
                                  MaterialPageRoute(
                                      builder: (_) =>
                                          TextDetailScreen(item: it)),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

class TextDetailScreen extends StatelessWidget {
  final Map<String, dynamic> item;
  const TextDetailScreen({super.key, required this.item});

  @override
  Widget build(BuildContext context) => BookPageScreen(item: item);
}
