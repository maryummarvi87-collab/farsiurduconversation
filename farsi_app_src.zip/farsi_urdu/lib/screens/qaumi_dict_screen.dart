import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import '../config.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';

/// قومی انگریزی اُردو لغت (مدیر: ڈاکٹر جمیل جالبی) — لغت ایپ کے اندر
/// بھی شامل ہے (آف لائن چلتی ہے) اور آن لائن ڈیٹا فائل
/// (qaumi_dict.json) سے خود تازہ بھی ہوتی رہتی ہے: روزانہ کے نئے
/// صفحات اپلوڈ ہوتے ہی ایپ کھولنے پر آ جاتے ہیں اور فون میں محفوظ
/// ہو جاتے ہیں۔ تلاش انگریزی اور اردو دونوں میں؛ ہر اندراج پر
/// کاپی و شیئر۔
class QaumiDictScreen extends StatefulWidget {
  const QaumiDictScreen({super.key});

  @override
  State<QaumiDictScreen> createState() => _QaumiDictScreenState();
}

class _QEntry {
  final String h;
  final String u;
  final String nh;
  final String nu;
  const _QEntry(this.h, this.u, this.nh, this.nu);
}

class _QaumiDictScreenState extends State<QaumiDictScreen> {
  List<_QEntry> _all = [];
  List<_QEntry> _shown = [];
  bool _loading = true;
  bool _failed = false;
  String _query = '';
  int _pages = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<File> _cacheFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/qaumi_dict.json');
  }

  /// ڈیٹا لگاتا ہے — صرف تب جب موجودہ سے پرانا نہ ہو (صفحات کی گنتی
  /// سے موازنہ)۔ کامیابی پر true۔
  bool _setData(String raw) {
    try {
      final j = jsonDecode(raw) as Map<String, dynamic>;
      final pages = (j['pages'] as num?)?.toInt() ?? 0;
      if (_all.isNotEmpty && pages < _pages) return false;
      final list = (j['entries'] as List).map((e) {
        final m = e as Map<String, dynamic>;
        final h = (m['h'] ?? '').toString();
        final u = (m['u'] ?? '').toString();
        return _QEntry(h, u, normalize(h), normalize(u));
      }).toList();
      if (!mounted) return false;
      setState(() {
        _all = list;
        _pages = pages;
        _loading = false;
        _failed = false;
        _applyFilter();
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _load() async {
    // ۱) ایپ کے اندر شامل لغت — آف لائن، انسٹال کے ساتھ ہی دستیاب
    try {
      final raw = await rootBundle.loadString('assets/data/qaumi_dict.json');
      _setData(raw);
    } catch (_) {}
    // ۲) فون میں محفوظ شدہ تازہ نقل (پچھلی آن لائن تازہ کاری)
    try {
      final f = await _cacheFile();
      if (await f.exists()) _setData(await f.readAsString());
    } catch (_) {}
    // ۳) آن لائن تازہ ترین صورت — نئے صفحات آئے ہوں تو لے کر محفوظ کر لو
    try {
      final res = await http
          .get(Uri.parse(AppConfig.qaumiDictUrl))
          .timeout(const Duration(seconds: 120));
      if (res.statusCode == 200) {
        final raw = utf8.decode(res.bodyBytes);
        if (_setData(raw)) {
          try {
            await (await _cacheFile()).writeAsString(raw);
          } catch (_) {}
        }
      }
    } catch (_) {}
    if (_all.isEmpty && mounted) {
      setState(() {
        _loading = false;
        _failed = true;
      });
    }
  }

  void _applyFilter() {
    final nq = normalize(_query);
    if (nq.isEmpty) {
      _shown = _all;
    } else {
      _shown = _all.where((e) => e.nh.contains(nq) || e.nu.contains(nq)).toList();
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('قومی انگریزی اُردو لغت'),
      ),
      body: Column(
        children: [
          const SizedBox(height: 8),
          SearchBox(
            hint: 'انگریزی یا اردو میں تلاش کریں',
            onChanged: (v) => setState(() {
              _query = v;
              _applyFilter();
            }),
          ),
          if (!_loading && !_failed)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
              child: Align(
                alignment: Alignment.centerRight,
                child: Text(
                  _query.isEmpty
                      ? 'کل ${_all.length} اندراجات — مدیر: ڈاکٹر جمیل جالبی'
                      : '${_shown.length} نتائج',
                  style: urStyle(size: 13, color: cs.outline),
                ),
              ),
            ),
          Expanded(child: _body(cs)),
        ],
      ),
    );
  }

  Widget _body(ColorScheme cs) {
    if (_loading) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('لغت لوڈ ہو رہی ہے…'),
          ],
        ),
      );
    }
    if (_failed) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_rounded, size: 44),
            const SizedBox(height: 12),
            const Text('لغت لوڈ نہیں ہو سکی — انٹرنیٹ چیک کریں'),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () {
                setState(() {
                  _loading = true;
                  _failed = false;
                });
                _load();
              },
              child: const Text('دوبارہ کوشش'),
            ),
          ],
        ),
      );
    }
    if (_shown.isEmpty) {
      return const Center(child: Text('کوئی اندراج نہیں ملا'));
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 16),
      itemCount: _shown.length,
      itemBuilder: (context, i) {
        final e = _shown[i];
        final text = '${e.h}\n${e.u}';
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text(
                    e.h,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 6),
                Text(e.u, style: urStyle(size: 16)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    IconButton(
                      tooltip: 'کاپی',
                      icon: const Icon(Icons.copy_rounded, size: 20),
                      onPressed: () => copyText(context, text),
                    ),
                    IconButton(
                      tooltip: 'شیئر',
                      icon: const Icon(Icons.ios_share_rounded, size: 20),
                      onPressed: () => shareText(text),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
