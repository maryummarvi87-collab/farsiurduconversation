import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme.dart';

/// کمپیوٹرائزڈ کیلکولیٹر — عام + سائنسی، الجبرا حل
class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class CalcError implements Exception {
  final String message;
  CalcError(this.message);
  @override
  String toString() => message;
}

// ---------------- ٹوکنر + پارser ----------------

class _Tok {
  final String kind; // num, ident, op, lp, rp
  final String text;
  final double value;
  const _Tok(this.kind, this.text, [this.value = 0]);
}

List<_Tok> _tokenize(String src) {
  final s = src
      .replaceAll('×', '*')
      .replaceAll('÷', '/')
      .replaceAll('−', '-')
      .replaceAll('²', '^2')
      .replaceAll(' ', '');
  final toks = <_Tok>[];
  var i = 0;
  while (i < s.length) {
    final c = s[i];
    if ('0123456789.'.contains(c)) {
      var j = i;
      var dots = 0;
      while (j < s.length && '0123456789.'.contains(s[j])) {
        if (s[j] == '.') dots++;
        j++;
      }
      final numText = s.substring(i, j);
      final v = double.tryParse(numText);
      if (v == null || dots > 1) throw CalcError('عدد درست نہیں: $numText');
      toks.add(_Tok('num', numText, v));
      i = j;
    } else if ('+-*/^!%()'.contains(c)) {
      toks.add(_Tok(c == '(' ? 'lp' : (c == ')' ? 'rp' : 'op'), c));
      i++;
    } else if (c == '√') {
      toks.add(const _Tok('ident', '√'));
      i++;
    } else if (c == 'π') {
      toks.add(const _Tok('ident', 'π'));
      i++;
    } else if (RegExp(r'[a-zA-Z]').hasMatch(c)) {
      var j = i;
      while (j < s.length && RegExp(r'[a-zA-Z]').hasMatch(s[j])) j++;
      toks.add(_Tok('ident', s.substring(i, j)));
      i = j;
    } else {
      throw CalcError('یہ علامت سمجھ نہیں آئی: $c');
    }
  }
  return toks;
}

class _Parser {
  final List<_Tok> toks;
  final double? xValue;
  final bool degrees;
  int pos = 0;
  _Parser(this.toks, {this.xValue, this.degrees = true});

  _Tok? get _peek => pos < toks.length ? toks[pos] : null;

  double parse() {
    if (toks.isEmpty) throw CalcError('پہلے کچھ لکھیں');
    final v = _expr();
    if (pos != toks.length) throw CalcError('اظہار مکمل نہیں ہوا');
    return v;
  }

  double _expr() {
    var v = _term();
    while (_peek != null && _peek!.kind == 'op' && (_peek!.text == '+' || _peek!.text == '-')) {
      final op = toks[pos++].text;
      final rhs = _term();
      v = op == '+' ? v + rhs : v - rhs;
    }
    return v;
  }

  bool _startsPrimary(_Tok t) =>
      t.kind == 'num' || t.kind == 'lp' || t.kind == 'ident';

  double _term() {
    var v = _unary();
    while (true) {
      final t = _peek;
      if (t == null) break;
      if (t.kind == 'op' && (t.text == '*' || t.text == '/')) {
        pos++;
        final rhs = _unary();
        if (t.text == '/') {
          if (rhs == 0) throw CalcError('صفر سے تقسیم ممکن نہیں');
          v = v / rhs;
        } else {
          v = v * rhs;
        }
      } else if (_startsPrimary(t)) {
        // ضربِ مضمر: 2π ، 3(4) ، (2)(3)
        v = v * _unary();
      } else {
        break;
      }
    }
    return v;
  }

  double _unary() {
    final t = _peek;
    if (t != null && t.kind == 'op' && (t.text == '-' || t.text == '+')) {
      pos++;
      final v = _unary();
      return t.text == '-' ? -v : v;
    }
    return _power();
  }

  double _power() {
    final base = _postfix();
    final t = _peek;
    if (t != null && t.kind == 'op' && t.text == '^') {
      pos++;
      final exp = _unary();
      final r = math.pow(base, exp).toDouble();
      if (r.isNaN) throw CalcError('یہ طاقت ممکن نہیں');
      return r;
    }
    return base;
  }

  double _postfix() {
    var v = _primary();
    while (true) {
      final t = _peek;
      if (t != null && t.kind == 'op' && t.text == '!') {
        pos++;
        v = _factorial(v);
      } else if (t != null && t.kind == 'op' && t.text == '%') {
        pos++;
        v = v / 100;
      } else {
        break;
      }
    }
    return v;
  }

  double _factorial(double v) {
    if (v < 0 || v != v.roundToDouble()) {
      throw CalcError('n! صرف مکمل مثبت عدد پر ہوتا ہے');
    }
    if (v > 170) throw CalcError('عدد بہت بڑا ہے');
    var r = 1.0;
    for (var i = 2; i <= v.toInt(); i++) {
      r *= i;
    }
    return r;
  }

  double _primary() {
    final t = _peek;
    if (t == null) throw CalcError('اظہار ادھورا ہے');
    if (t.kind == 'num') {
      pos++;
      return t.value;
    }
    if (t.kind == 'lp') {
      pos++;
      final v = _expr();
      if (_peek == null || _peek!.kind != 'rp') throw CalcError('قوس بند نہیں ہوا');
      pos++;
      return v;
    }
    if (t.kind == 'ident') {
      pos++;
      switch (t.text) {
        case 'π':
          return math.pi;
        case 'e':
          return math.e;
        case 'x':
          if (xValue == null) throw CalcError('x کی قدر معلوم نہیں');
          return xValue!;
        case '√':
          final v = _primary();
          if (v < 0) throw CalcError('منفی عدد کا جذر ممکن نہیں');
          return math.sqrt(v);
        case 'sin':
        case 'cos':
        case 'tan':
        case 'ln':
        case 'log':
          if (_peek == null || _peek!.kind != 'lp') {
            throw CalcError('${t.text} کے بعد ( لکھیں');
          }
          pos++;
          final v = _expr();
          if (_peek == null || _peek!.kind != 'rp') throw CalcError('قوس بند نہیں ہوا');
          pos++;
          final rad = degrees ? v * math.pi / 180 : v;
          switch (t.text) {
            case 'sin':
              return math.sin(rad);
            case 'cos':
              return math.cos(rad);
            case 'tan':
              if (math.cos(rad).abs() < 1e-12) throw CalcError('tan یہاں غیر متعین ہے');
              return math.tan(rad);
            case 'ln':
              if (v <= 0) throw CalcError('ln صرف مثبت عدد کا ہوتا ہے');
              return math.log(v);
            default:
              if (v <= 0) throw CalcError('log صرف مثبت عدد کا ہوتا ہے');
              return math.log(v) / math.ln10;
          }
      }
      throw CalcError('نامعلوم علامت: ${t.text}');
    }
    throw CalcError('اظہار درست نہیں');
  }
}

double evaluateExpr(String expr, {double? xValue, bool degrees = true}) {
  return _Parser(_tokenize(expr), xValue: xValue, degrees: degrees).parse();
}

String fmtNum(double v) {
  if (v.isNaN || v.isInfinite) throw CalcError('نتیجہ ممکن نہیں');
  if (v == v.roundToDouble() && v.abs() < 1e15) return v.toInt().toString();
  var s = v.toStringAsPrecision(10);
  if (s.contains('.')) {
    s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }
  return s;
}

// ---------------- اسکرین ----------------

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _expr = '';
  String _preview = '';
  String? _error;
  List<String> _steps = const [];
  bool _degrees = true;

  void _refreshPreview() {
    _error = null;
    if (_expr.isEmpty || _expr.contains('=') || _expr.contains('x')) {
      _preview = '';
      return;
    }
    try {
      _preview = '= ${fmtNum(evaluateExpr(_expr, degrees: _degrees))}';
    } catch (_) {
      _preview = '';
    }
  }

  void _append(String token) {
    setState(() {
      _steps = const [];
      _expr += token;
      _refreshPreview();
    });
  }

  void _backspace() {
    if (_expr.isEmpty) return;
    setState(() {
      _steps = const [];
      _expr = _expr.substring(0, _expr.length - 1);
      _refreshPreview();
    });
  }

  void _clear() {
    setState(() {
      _expr = '';
      _preview = '';
      _error = null;
      _steps = const [];
    });
  }

  void _toggleSign() {
    if (_expr.isEmpty) return;
    setState(() {
      _steps = const [];
      if (_expr.startsWith('−')) {
        _expr = _expr.substring(1);
      } else {
        _expr = '−' + _expr;
      }
      _refreshPreview();
    });
  }

  void _reciprocal() {
    if (_expr.isEmpty) return;
    setState(() {
      _steps = const [];
      _expr = '1/($_expr)';
      _refreshPreview();
    });
  }

  void _equals() {
    if (_expr.contains('=')) {
      _solveAlgebra();
      return;
    }
    if (_expr.contains('x')) {
      setState(() => _error = 'x والی مساوات کے لیے = بھی لکھیں، مثلاً 2x+3=7');
      return;
    }
    try {
      final v = evaluateExpr(_expr, degrees: _degrees);
      setState(() {
        _expr = fmtNum(v);
        _preview = '';
        _error = null;
        _steps = const [];
      });
    } on CalcError catch (e) {
      setState(() => _error = e.message);
    } catch (_) {
      setState(() => _error = 'اظہار درست نہیں');
    }
  }

  void _solveAlgebra() {
    final parts = _expr.split('=');
    if (parts.length != 2 || parts[0].trim().isEmpty || parts[1].trim().isEmpty) {
      setState(() => _error = 'مساوات درست لکھیں، مثلاً 2x+3=7');
      return;
    }
    double f(double xv) =>
        evaluateExpr(parts[0], xValue: xv, degrees: _degrees) -
        evaluateExpr(parts[1], xValue: xv, degrees: _degrees);
    try {
      final f0 = f(0), f1 = f(1), fm1 = f(-1), f2 = f(2);
      final c = f0;
      final a = (f1 + fm1 - 2 * c) / 2;
      final b = (f1 - fm1) / 2;
      final check = 4 * a + 2 * b + c;
      final scale = [f0, f1, fm1, f2, check].map((e) => e.abs()).reduce(math.max);
      if ((f2 - check).abs() > 1e-6 * (scale + 1)) {
        setState(() => _error = 'یہ مساوات خطی یا دو درجی نہیں — حل ممکن نہیں');
        return;
      }
      final steps = <String>[];
      const eps = 1e-9;
      if (a.abs() < eps && b.abs() < eps) {
        setState(() {
          _error = c.abs() < eps ? 'بے شمار حل ہیں — ہر x درست ہے' : 'اس مساوات کا کوئی حل نہیں';
          _steps = const [];
        });
        return;
      }
      if (a.abs() < eps) {
        steps.add('خطی مساوات: ${fmtNum(b)}x + ${fmtNum(c)} = 0');
        final x = -c / b;
        steps.add('x = −(${fmtNum(c)}) ÷ ${fmtNum(b)}');
        steps.add('x = ${fmtNum(x)}');
        setState(() {
          _steps = steps;
          _preview = 'x = ${fmtNum(x)}';
          _error = null;
        });
        return;
      }
      steps.add('دو درجی مساوات: ${fmtNum(a)}x² + ${fmtNum(b)}x + ${fmtNum(c)} = 0');
      final d = b * b - 4 * a * c;
      steps.add('ممیز D = b² − 4ac = ${fmtNum(d)}');
      if (d < -eps) {
        setState(() {
          _steps = steps;
          _error = 'ممیز منفی ہے — حقیقی حل موجود نہیں';
        });
        return;
      }
      if (d.abs() <= eps) {
        final x = -b / (2 * a);
        steps.add('x = −b ÷ 2a = ${fmtNum(x)}');
        setState(() {
          _steps = steps;
          _preview = 'x = ${fmtNum(x)}';
          _error = null;
        });
        return;
      }
      final sd = math.sqrt(d);
      final x1 = (-b + sd) / (2 * a);
      final x2 = (-b - sd) / (2 * a);
      steps.add('x = (−b ± √D) ÷ 2a');
      steps.add('x₁ = ${fmtNum(x1)}');
      steps.add('x₂ = ${fmtNum(x2)}');
      setState(() {
        _steps = steps;
        _preview = 'x = ${fmtNum(x1)} یا ${fmtNum(x2)}';
        _error = null;
      });
    } on CalcError catch (e) {
      setState(() => _error = e.message);
    } catch (_) {
      setState(() => _error = 'اس مساوات کو حل نہیں کیا جا سکا');
    }
  }

  // -------- UI --------

  /// ایک بٹن — لیبل ہمیشہ LTR میں تاکہ «n!»، «1/x»، «x^y» درست نظر آئیں
  Widget _btn(String label, VoidCallback onTap,
      {Color? bg, Color? fg, double size = 20}) {
    final cs = Theme.of(context).colorScheme;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(3),
        child: Material(
          color: bg ?? cardFill(context),
          borderRadius: BorderRadius.circular(14),
          elevation: bg == null ? 1 : 0,
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Container(
              height: 52,
              alignment: Alignment.center,
              child: Text(
                label,
                textDirection: TextDirection.ltr,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: size,
                  fontWeight: FontWeight.w700,
                  color: fg ?? cs.onSurface,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final opBg = cs.primaryContainer;
    final opFg = cs.onPrimaryContainer;
    return Scaffold(
      appBar: AppBar(title: const Text('کیلکولیٹر')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 14),
          children: [
            _display(cs),
            const SizedBox(height: 8),
            // مختصر ہدایت — صرف ایک سطر
            Text(
              'x والی مساوات بھی حل ہوتی ہے',
              style: urStyle(size: 13, color: cs.onSurfaceVariant),
            ),
            const SizedBox(height: 8),
            // زاویے کی اکائی — اپنی الگ صاف صف
            Row(
              children: [
                ChoiceChip(
                  label: const Text('درجہ (DEG)'),
                  selected: _degrees,
                  onSelected: (_) => setState(() {
                    _degrees = true;
                    _refreshPreview();
                  }),
                ),
                const SizedBox(width: 8),
                ChoiceChip(
                  label: const Text('ریڈین (RAD)'),
                  selected: !_degrees,
                  onSelected: (_) => setState(() {
                    _degrees = false;
                    _refreshPreview();
                  }),
                ),
              ],
            ),
            const SizedBox(height: 8),
            // سائنسی صفیں
            Row(children: [
              _btn('sin', () => _append('sin('), bg: opBg, fg: opFg, size: 16),
              _btn('cos', () => _append('cos('), bg: opBg, fg: opFg, size: 16),
              _btn('tan', () => _append('tan('), bg: opBg, fg: opFg, size: 16),
              _btn('√', () => _append('√('), bg: opBg, fg: opFg),
              _btn('x²', () => _append('²'), bg: opBg, fg: opFg, size: 17),
            ]),
            Row(children: [
              _btn('ln', () => _append('ln('), bg: opBg, fg: opFg, size: 16),
              _btn('log', () => _append('log('), bg: opBg, fg: opFg, size: 16),
              _btn('π', () => _append('π'), bg: opBg, fg: opFg),
              _btn('e', () => _append('e'), bg: opBg, fg: opFg),
              _btn('n!', () => _append('!'), bg: opBg, fg: opFg, size: 17),
            ]),
            Row(children: [
              _btn('(', () => _append('('), bg: opBg, fg: opFg),
              _btn(')', () => _append(')'), bg: opBg, fg: opFg),
              _btn('x^y', () => _append('^'), bg: opBg, fg: opFg, size: 16),
              _btn('1/x', _reciprocal, bg: opBg, fg: opFg, size: 16),
              _btn('x', () => _append('x'), bg: opBg, fg: opFg),
            ]),
            Row(children: [
              _btn('=', () => _append('='),
                  bg: cs.secondaryContainer,
                  fg: cs.onSecondaryContainer,
                  size: 22),
            ]),
            const SizedBox(height: 4),
            // ہندسوں کا پیڈ
            Row(children: [
              _btn('C', _clear, bg: cs.error, fg: cs.onError),
              _btn('⌫', _backspace, bg: opBg, fg: opFg),
              _btn('%', () => _append('%'), bg: opBg, fg: opFg),
              _btn('÷', () => _append('÷'), bg: opBg, fg: opFg),
            ]),
            Row(children: [
              _btn('7', () => _append('7')),
              _btn('8', () => _append('8')),
              _btn('9', () => _append('9')),
              _btn('×', () => _append('×'), bg: opBg, fg: opFg),
            ]),
            Row(children: [
              _btn('4', () => _append('4')),
              _btn('5', () => _append('5')),
              _btn('6', () => _append('6')),
              _btn('−', () => _append('−'), bg: opBg, fg: opFg),
            ]),
            Row(children: [
              _btn('1', () => _append('1')),
              _btn('2', () => _append('2')),
              _btn('3', () => _append('3')),
              _btn('+', () => _append('+'), bg: opBg, fg: opFg),
            ]),
            Row(children: [
              _btn('±', _toggleSign, bg: opBg, fg: opFg),
              _btn('0', () => _append('0')),
              _btn('.', () => _append('.')),
              _btn('=', _equals, bg: cs.primary, fg: cs.onPrimary, size: 22),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _display(ColorScheme cs) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: cs.outlineVariant, width: 1.4),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Directionality(
            textDirection: TextDirection.ltr,
            child: Text(
              _expr.isEmpty ? '0' : _expr,
              textAlign: TextAlign.right,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.w800,
                color: _expr.isEmpty ? cs.outline : cs.onSurface,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Text(
              _error ?? _preview,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: _error != null ? cs.error : cs.secondary,
              ),
            ),
          ),
          if (_steps.isNotEmpty) ...[
            const SizedBox(height: 8),
            Container(
              constraints: const BoxConstraints(maxHeight: 132),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('حل کے مراحل:',
                        style: urStyle(size: 14, color: cs.onSurfaceVariant)),
                    for (final s in _steps)
                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: Text(
                          s,
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontSize: 16.5,
                            fontWeight: FontWeight.w600,
                            color: cs.onSurface,
                            height: 1.5,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
