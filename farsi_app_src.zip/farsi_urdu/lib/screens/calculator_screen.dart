import 'dart:math' as math;

import 'package:flutter/material.dart' hide Ink;

import '../theme.dart';

/// کمپیوٹرائزڈ کیلکولیٹر — عام + سائنسی، الجبرا حل
class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class CalcError implements Exception {
  final String message;
  CalcError(this.message);
  @override
  String toString() => message;
}

// ---------------- ٹوکنر + پارser ----------------

class _Tok {
  final String kind; // num, ident, op, lp, rp
  final String text;
  final double value;
  const _Tok(this.kind, this.text, [this.value = 0]);
}

List<_Tok> _tokenize(String src) {
  final s = src
      .replaceAll('×', '*')
      .replaceAll('÷', '/')
      .replaceAll('−', '-')
      .replaceAll('²', '^2')
      .replaceAll(' ', '');
  final toks = <_Tok>[];
  var i = 0;
  while (i < s.length) {
    final c = s[i];
    if ('0123456789.'.contains(c)) {
      var j = i;
      var dots = 0;
      while (j < s.length && '0123456789.'.contains(s[j])) {
        if (s[j] == '.') dots++;
        j++;
      }
      final numText = s.substring(i, j);
      final v = double.tryParse(numText);
      if (v == null || dots > 1) throw CalcError('عدد درست نہیں: $numText');
      toks.add(_Tok('num', numText, v));
      i = j;
    } else if ('+-*/^!%()'.contains(c)) {
      toks.add(_Tok(c == '(' ? 'lp' : (c == ')' ? 'rp' : 'op'), c));
      i++;
    } else if (c == '√') {
      toks.add(const _Tok('ident', '√'));
      i++;
    } else if (c == 'π') {
      toks.add(const _Tok('ident', 'π'));
      i++;
    } else if (RegExp(r'[a-zA-Z]').hasMatch(c)) {
      var j = i;
      while (j < s.length && RegExp(r'[a-zA-Z]').hasMatch(s[j])) j++;
      toks.add(_Tok('ident', s.substring(i, j)));
      i = j;
    } else {
      throw CalcError('یہ علامت سمجھ نہیں آئی: $c');
    }
  }
  return toks;
}

class _Parser {
  final List<_Tok> toks;
  final double? xValue;
  int pos = 0;
  _Parser(this.toks, {this.xValue});

  _Tok? get _peek => pos < toks.length ? toks[pos] : null;

  double parse() {
    if (toks.isEmpty) throw CalcError('پہلے کچھ لکھیں');
    final v = _expr();
    if (pos != toks.length) throw CalcError('اظہار مکمل نہیں ہوا');
    return v;
  }

  double _expr() {
    var v = _term();
    while (_peek != null && _peek!.kind == 'op' && (_peek!.text == '+' || _peek!.text == '-')) {
      final op = toks[pos++].text;
      final rhs = _term();
      v = op == '+' ? v + rhs : v - rhs;
    }
    return v;
  }

  bool _startsPrimary(_Tok t) =>
      t.kind == 'num' || t.kind == 'lp' || t.kind == 'ident';

  double _term() {
    var v = _unary();
    while (true) {
      final t = _peek;
      if (t == null) break;
      if (t.kind == 'op' && (t.text == '*' || t.text == '/')) {
        pos++;
        final rhs = _unary();
        if (t.text == '/') {
          if (rhs == 0) throw CalcError('صفر سے تقسیم ممکن نہیں');
          v = v / rhs;
        } else {
          v = v * rhs;
        }
      } else if (_startsPrimary(t)) {
        // ضربِ مضمر: 2π ، 3(4) ، (2)(3)
        v = v * _unary();
      } else {
        break;
      }
    }
    return v;
  }

  double _unary() {
    final t = _peek;
    if (t != null && t.kind == 'op' && (t.text == '-' || t.text == '+')) {
      pos++;
      final v = _unary();
      return t.text == '-' ? -v : v;
    }
    return _power();
  }

  double _power() {
    final base = _postfix();
    final t = _peek;
    if (t != null && t.kind == 'op' && t.text == '^') {
      pos++;
      final exp = _unary();
      final r = math.pow(base, exp).toDouble();
      if (r.isNaN) throw CalcError('یہ طاقت ممکن نہیں');
      return r;
    }
    return base;
  }

  double _postfix() {
    var v = _primary();
    while (true) {
      final t = _peek;
      if (t != null && t.kind == 'op' && t.text == '!') {
        pos++;
        v = _factorial(v);
      } else if (t != null && t.kind == 'op' && t.text == '%') {
        pos++;
        v = v / 100;
      } else {
        break;
      }
    }
    return v;
  }

  double _factorial(double v) {
    if (v < 0 || v != v.roundToDouble()) {
      throw CalcError('n! صرف مکمل مثبت عدد پر ہوتا ہے');
    }
    if (v > 170) throw CalcError('عدد بہت بڑا ہے');
    var r = 1.0;
    for (var i = 2; i <= v.toInt(); i++) {
      r *= i;
    }
    return r;
  }

  double _primary() {
    final t = _peek;
    if (t == null) throw CalcError('اظہار ادھورا ہے');
    if (t.kind == 'num') {
      pos++;
      return t.value;
    }
    if (t.kind == 'lp') {
      pos++;
      final v = _expr();
      if (_peek == null || _peek!.kind != 'rp') throw CalcError('قوس بند نہیں ہوا');
      pos++;
      return v;
    }
    if (t.kind == 'ident') {
      pos++;
      switch (t.text) {
        case 'π':
          return math.pi;
        case 'e':
          return math.e;
        case 'x':
          if (xValue == null) throw CalcError('x کی قدر معلوم نہیں');
          return xValue!;
        case '√':
          final v = _primary();
          if (v < 0) throw CalcError('منفی عدد کا جذر ممکن نہیں');
          return math.sqrt(v);
        case 'sin':
        case 'cos':
        case 'tan':
        case 'ln':
        case 'log':
          if (_peek == null || _peek!.kind != 'lp') {
            throw CalcError('${t.text} کے بعد ( لکھیں');
          }
          pos++;
          final v = _expr();
          if (_peek == null || _peek!.kind != 'rp') throw CalcError('قوس بند نہیں ہوا');
          pos++;
          final rad = v * math.pi / 180;
          switch (t.text) {
            case 'sin':
              return math.sin(rad);
            case 'cos':
              return math.cos(rad);
            case 'tan':
              if (math.cos(rad).abs() < 1e-12) throw CalcError('tan یہاں غیر متعین ہے');
              return math.tan(rad);
            case 'ln':
              if (v <= 0) throw CalcError('ln صرف مثبت عدد کا ہوتا ہے');
              return math.log(v);
            default:
              if (v <= 0) throw CalcError('log صرف مثبت عدد کا ہوتا ہے');
              return math.log(v) / math.ln10;
          }
      }
      throw CalcError('نامعلوم علامت: ${t.text}');
    }
    throw CalcError('اظہار درست نہیں');
  }
}

double evaluateExpr(String expr, {double? xValue}) {
  return _Parser(_tokenize(expr), xValue: xValue).parse();
}

String fmtNum(double v) {
  if (v.isNaN || v.isInfinite) throw CalcError('نتیجہ ممکن نہیں');
  if (v == v.roundToDouble() && v.abs() < 1e15) return v.toInt().toString();
  var s = v.toStringAsPrecision(10);
  if (s.contains('.')) {
    s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }
  return s;
}

// ---------------- اسکرین ----------------

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _expr = '';
  String _preview = '';
  String? _error;
  List<String> _steps = const [];

  void _refreshPreview() {
    _error = null;
    if (_expr.isEmpty || _expr.contains('=') || _expr.contains('x')) {
      _preview = '';
      return;
    }
    try {
      _preview = '= ${fmtNum(evaluateExpr(_expr))}';
    } catch (_) {
      _preview = '';
    }
  }

  void _append(String token) {
    setState(() {
      _steps = const [];
      _expr += token;
      _refreshPreview();
    });
  }

  void _backspace() {
    if (_expr.isEmpty) return;
    setState(() {
      _steps = const [];
      _expr = _expr.substring(0, _expr.length - 1);
      _refreshPreview();
    });
  }

  void _clear() {
    setState(() {
      _expr = '';
      _preview = '';
      _error = null;
      _steps = const [];
    });
  }

  void _toggleSign() {
    if (_expr.isEmpty) return;
    setState(() {
      _steps = const [];
      if (_expr.startsWith('−')) {
        _expr = _expr.substring(1);
      } else {
        _expr = '−' + _expr;
      }
      _refreshPreview();
    });
  }

  void _reciprocal() {
    if (_expr.isEmpty) return;
    setState(() {
      _steps = const [];
      _expr = '1/($_expr)';
      _refreshPreview();
    });
  }

  void _equals() {
    if (_expr.contains('=')) {
      _solveAlgebra();
      return;
    }
    if (_expr.contains('x')) {
      setState(() => _error = 'x والی مساوات کے لیے = بھی لکھیں، مثلاً 2x+3=7');
      return;
    }
    try {
      final v = evaluateExpr(_expr);
      setState(() {
        _expr = fmtNum(v);
        _preview = '';
        _error = null;
        _steps = const [];
      });
    } on CalcError catch (e) {
      setState(() => _error = e.message);
    } catch (_) {
      setState(() => _error = 'اظہار درست نہیں');
    }
  }

  void _solveAlgebra() {
    final parts = _expr.split('=');
    if (parts.length != 2 || parts[0].trim().isEmpty || parts[1].trim().isEmpty) {
      setState(() => _error = 'مساوات درست لکھیں، مثلاً 2x+3=7');
      return;
    }
    double f(double xv) =>
        evaluateExpr(parts[0], xValue: xv) - evaluateExpr(parts[1], xValue: xv);
    try {
      final f0 = f(0), f1 = f(1), fm1 = f(-1), f2 = f(2);
      final c = f0;
      final a = (f1 + fm1 - 2 * c) / 2;
      final b = (f1 - fm1) / 2;
      final check = 4 * a + 2 * b + c;
      final scale = [f0, f1, fm1, f2, check].map((e) => e.abs()).reduce(math.max);
      if ((f2 - check).abs() > 1e-6 * (scale + 1)) {
        setState(() => _error = 'یہ مساوات خطی یا دو درجی نہیں — حل ممکن نہیں');
        return;
      }
      final steps = <String>[];
      const eps = 1e-9;
      if (a.abs() < eps && b.abs() < eps) {
        setState(() {
          _error = c.abs() < eps ? 'بے شمار حل ہیں — ہر x درست ہے' : 'اس مساوات کا کوئی حل نہیں';
          _steps = const [];
        });
        return;
      }
      if (a.abs() < eps) {
        steps.add('خطی مساوات: ${fmtNum(b)}x + ${fmtNum(c)} = 0');
        final x = -c / b;
        steps.add('x = −(${fmtNum(c)}) ÷ ${fmtNum(b)}');
        steps.add('x = ${fmtNum(x)}');
        setState(() {
          _steps = steps;
          _preview = 'x = ${fmtNum(x)}';
          _error = null;
        });
        return;
      }
      steps.add('دو درجی مساوات: ${fmtNum(a)}x² + ${fmtNum(b)}x + ${fmtNum(c)} = 0');
      final d = b * b - 4 * a * c;
      steps.add('ممیز D = b² − 4ac = ${fmtNum(d)}');
      if (d < -eps) {
        setState(() {
          _steps = steps;
          _error = 'ممیز منفی ہے — حقیقی حل موجود نہیں';
        });
        return;
      }
      if (d.abs() <= eps) {
        final x = -b / (2 * a);
        steps.add('x = −b ÷ 2a = ${fmtNum(x)}');
        setState(() {
          _steps = steps;
          _preview = 'x = ${fmtNum(x)}';
          _error = null;
        });
        return;
      }
      final sd = math.sqrt(d);
      final x1 = (-b + sd) / (2 * a);
      final x2 = (-b - sd) / (2 * a);
      steps.add('x = (−b ± √D) ÷ 2a');
      steps.add('x₁ = ${fmtNum(x1)}');
      steps.add('x₂ = ${fmtNum(x2)}');
      setState(() {
        _steps = steps;
        _preview = 'x = ${fmtNum(x1)} یا ${fmtNum(x2)}';
        _error = null;
      });
    } on CalcError catch (e) {
      setState(() => _error = e.message);
    } catch (_) {
      setState(() => _error = 'اس مساوات کو حل نہیں کیا جا سکا');
    }
  }

  // -------- UI --------

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(title: const Text('کیلکولیٹر')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
          child: Column(
            children: [
              _display(cs, dark),
              const SizedBox(height: 10),
              _scienceStrip(cs),
              const SizedBox(height: 8),
              Expanded(child: _keypad(cs)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _display(ColorScheme cs, bool dark) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: cs.outlineVariant, width: 1.4),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Directionality(
            textDirection: TextDirection.ltr,
            child: Text(
              _expr.isEmpty ? '0' : _expr,
              textAlign: TextAlign.right,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.w800,
                color: _expr.isEmpty ? cs.outline : cs.onSurface,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Text(
              _error ?? _preview,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: _error != null ? cs.error : cs.secondary,
              ),
            ),
          ),
          if (_steps.isNotEmpty) ...[
            const SizedBox(height: 8),
            Container(
              constraints: const BoxConstraints(maxHeight: 132),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('حل کے مراحل:',
                        style: urStyle(size: 14, color: cs.onSurfaceVariant)),
                    for (final s in _steps)
                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: Text(
                          s,
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontSize: 16.5,
                            fontWeight: FontWeight.w600,
                            color: cs.onSurface,
                            height: 1.5,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _scienceStrip(ColorScheme cs) {
    final items = <(String, VoidCallback)>[
      ('sin', () => _append('sin(')),
      ('cos', () => _append('cos(')),
      ('tan', () => _append('tan(')),
      ('ln', () => _append('ln(')),
      ('log', () => _append('log(')),
      ('√', () => _append('√(')),
      ('x²', () => _append('²')),
      ('x^y', () => _append('^')),
      ('%', () => _append('%')),
      ('π', () => _append('π')),
      ('e', () => _append('e')),
      ('n!', () => _append('!')),
      ('1/x', _reciprocal),
      ('x', () => _append('x')),
      ('=', () => _append('=')),
      ('±', _toggleSign),
    ];
    return SizedBox(
      height: 42,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 7),
        itemBuilder: (context, i) {
          final (label, fn) = items[i];
          return Material(
            color: cs.tertiaryContainer,
            borderRadius: BorderRadius.circular(12),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: fn,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 13),
                alignment: Alignment.center,
                child: Text(
                  label,
                  style: TextStyle(
                    fontSize: 15.5,
                    fontWeight: FontWeight.w700,
                    color: cs.onTertiaryContainer,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _keypad(ColorScheme cs) {
    final keys = <(String, String, VoidCallback)>[
      // (label, kind, action) — kind: digit, op, danger, equals
      ('C', 'danger', _clear),
      ('(', 'op', () => _append('(')),
      (')', 'op', () => _append(')')),
      ('⌫', 'danger', _backspace),
      ('7', 'digit', () => _append('7')),
      ('8', 'digit', () => _append('8')),
      ('9', 'digit', () => _append('9')),
      ('÷', 'op', () => _append('÷')),
      ('4', 'digit', () => _append('4')),
      ('5', 'digit', () => _append('5')),
      ('6', 'digit', () => _append('6')),
      ('×', 'op', () => _append('×')),
      ('1', 'digit', () => _append('1')),
      ('2', 'digit', () => _append('2')),
      ('3', 'digit', () => _append('3')),
      ('−', 'op', () => _append('−')),
      ('0', 'digit', () => _append('0')),
      ('.', 'digit', () => _append('.')),
      ('=', 'equals', _equals),
      ('+', 'op', () => _append('+')),
    ];
    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        childAspectRatio: 1.45,
      ),
      itemCount: keys.length,
      itemBuilder: (context, i) {
        final (label, kind, fn) = keys[i];
        Color bg, fg;
        switch (kind) {
          case 'op':
            bg = cs.primaryContainer;
            fg = cs.onPrimaryContainer;
            break;
          case 'danger':
            bg = cs.errorContainer;
            fg = cs.onErrorContainer;
            break;
          case 'equals':
            bg = cs.primary;
            fg = cs.onPrimary;
            break;
          default:
            bg = cardFill(context);
            fg = cs.onSurface;
        }
        return Material(
          color: bg,
          borderRadius: BorderRadius.circular(14),
          elevation: kind == 'digit' ? 1 : 0,
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: fn,
            child: Center(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: kind == 'digit' ? 23 : 21,
                  fontWeight: FontWeight.w800,
                  color: fg,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

