import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';
import '../widgets/sentence_detail.dart';
import 'book_page_screen.dart';

/// کتابوں کی فہرست — پہلے کتابِ اَوَّل
class BooksScreen extends StatelessWidget {
  const BooksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final books = repo.list('books');
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('کتابیں')),
      body: books.isEmpty
          ? const EmptyState(
              message: 'ابھی کوئی کتاب شامل نہیں۔\nآن لائن اپڈیٹ سے نیا مواد حاصل کریں۔')
          : ListView.builder(
              padding: const EdgeInsets.only(top: 8, bottom: 24),
              itemCount: books.length,
              itemBuilder: (context, i) {
                final b = books[i];
                final lessons = asMaps(b['lessons']);
                return Container(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(
                    color: cardFill(context),
                    borderRadius: BorderRadius.circular(20),
                    border:
                        Border.all(color: cs.outlineVariant.withAlpha(110)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withAlpha(16),
                        blurRadius: 14,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: ListTile(
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    leading: CircleAvatar(
                      backgroundColor: AppColors.gold.withAlpha(40),
                      foregroundColor: AppColors.gold,
                      child: Text('${localDigits(i + 1)}',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                    title: Text(str(b['title']),
                        style: const TextStyle(
                            fontSize: 17.5, fontWeight: FontWeight.w700)),
                    subtitle: Text(
                      '${str(b['subtitle'])}  ·  ${localDigits(lessons.length)} اسباق',
                    ),
                    trailing: const Icon(Icons.chevron_left_rounded),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => BookScreen(book: b)),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

/// ایک کتاب: اوپر تلاش (دونوں زبانوں میں)، نیچے اسباق کی فہرست
class BookScreen extends StatefulWidget {
  final Map<String, dynamic> book;
  const BookScreen({super.key, required this.book});

  @override
  State<BookScreen> createState() => _BookScreenState();
}

class _BookScreenState extends State<BookScreen> {
  String _q = '';

  /// کتاب کے سارے اسباق کی سطروں میں تلاش — فارسی اور اردو دونوں میں
  List<(Map<String, dynamic>, String, String?, String)> _search(
      List<Map<String, dynamic>> lessons, String q) {
    final nq = normalize(q);
    final out = <(Map<String, dynamic>, String, String?, String)>[];
    for (final lesson in lessons) {
      for (final raw in str(lesson['body']).split('\n')) {
        final line = raw.trim();
        if (line.isEmpty || !line.contains(' — ')) continue;
        for (final seg in line.split('؛')) {
          final s = seg.trim();
          if (s.isEmpty || !normalize(s).contains(nq)) continue;
          final parts = s.split(' — ');
          String fa, ur;
          String? ro;
          if (parts.length >= 3 &&
              RegExp(r'[a-zA-Z]').hasMatch(parts[parts.length - 2])) {
            fa = parts.sublist(0, parts.length - 2).join(' — ');
            ro = parts[parts.length - 2];
            ur = parts[parts.length - 1];
          } else if (parts.length >= 2) {
            fa = parts.sublist(0, parts.length - 1).join(' — ');
            ur = parts[parts.length - 1];
          } else {
            continue;
          }
          final m = RegExp(r'^([۰-۹0-9]+۔)\s*').firstMatch(fa);
          if (m != null) fa = fa.substring(m.end);
          out.add((lesson, fa, ro, ur));
          if (out.length >= 100) return out;
        }
      }
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final lessons = asMaps(widget.book['lessons']);
    final cs = Theme.of(context).colorScheme;
    final searching = _q.trim().isNotEmpty;
    final results = searching ? _search(lessons, _q) : null;
    return Scaffold(
      appBar: AppBar(title: Text(str(widget.book['title']))),
      body: Column(
        children: [
          SearchBox(
            hint: 'اس کتاب میں تلاش کریں… (فارسی یا اردو)',
            onChanged: (v) => setState(() => _q = v),
          ),
          Expanded(
            child: searching
                ? (results!.isEmpty
                    ? const EmptyState(message: 'اس کتاب میں کوئی نتیجہ نہیں ملا۔')
                    : ListView.builder(
                        padding: const EdgeInsets.only(top: 4, bottom: 24),
                        itemCount: results.length,
                        itemBuilder: (context, i) {
                          final (lesson, fa, ro, ur) = results[i];
                          return Container(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 5),
                            decoration: BoxDecoration(
                              color: cardFill(context),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                  color: cs.outlineVariant.withAlpha(110)),
                            ),
                            child: ListTile(
                              title: Text(fa, style: faStyle(size: 19)),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  if (ro != null)
                                    Text(ro,
                                        style: const TextStyle(
                                            fontSize: 13,
                                            fontStyle: FontStyle.italic),
                                        textDirection: TextDirection.ltr),
                                  Text(ur, style: urStyle(size: 15.5)),
                                  Text(str(lesson['title']),
                                      style: TextStyle(
                                          fontSize: 12.5,
                                          color: cs.outline)),
                                ],
                              ),
                              onTap: () => openSentenceDetail(context,
                                  fa: fa, roman: ro, ur: ur),
                            ),
                          );
                        },
                      ))
                : ListView.builder(
                    padding: const EdgeInsets.only(top: 4, bottom: 24),
                    itemCount: lessons.length,
                    itemBuilder: (context, i) {
                      final l = lessons[i];
                      return Container(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 6),
                        decoration: BoxDecoration(
                          color: cardFill(context),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: cs.outlineVariant.withAlpha(110)),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withAlpha(16),
                              blurRadius: 14,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 6),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20)),
                          leading: CircleAvatar(
                            backgroundColor: cs.primary.withAlpha(30),
                            foregroundColor: cs.primary,
                            child: Text('${localDigits(i + 1)}',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w800)),
                          ),
                          title: Text(str(l['title']),
                              style: const TextStyle(
                                  fontSize: 17, fontWeight: FontWeight.w700)),
                          subtitle: Text(
                              '${str(l['subtitle'])}  ·  کتاب کا صفحہ'),
                          trailing: const Icon(Icons.chevron_left_rounded),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                                builder: (_) => BookPageScreen(item: l)),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
