import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const Color teal = Color(0xFF0E6E6E);
  static const Color deepTeal = Color(0xFF094A4F);
  static const Color gold = Color(0xFFC9A227);
  static const Color ivory = Color(0xFFFBF7EE);
  static const Color night = Color(0xFF0B1F24);
  static const Color lapis = Color(0xFF2F4B8F);
  static const Color rose = Color(0xFFA23B5A);
  static const Color emerald = Color(0xFF2E7D5B);
  static const Color saffron = Color(0xFFD98324);
  static const Color plum = Color(0xFF6B3F8C);

  // مضبوط رنگ نظام — لائٹ موڈ
  static const Color inkText = Color(0xFF10243E); // گہرا بحری متن
  static const Color inkTextSoft = Color(0xFF3D4A5C); // ثانوی متن (گہرا)
  static const Color inkOutline = Color(0xFF46586E); // متن کے طور پر بھی واضح
  static const Color inkBorder = Color(0xFF7C8DA3);
  static const Color goldDeep = Color(0xFF8A6D00);

  // مضبوط رنگ نظام — ڈارک موڈ
  static const Color nightCard = Color(0xFF12323A);
  static const Color nightCardDeep = Color(0xFF0D1526);
  static const Color brightYellow = Color(0xFFFFD740);
  static const Color skyBlue = Color(0xFF82B1FF);
  static const Color brightTeal = Color(0xFF45C8BC);
  static const Color darkTextSoft = Color(0xFFD9E6EE);
  static const Color darkOutline = Color(0xFFC3D5E0);
  static const Color darkBorder = Color(0xFF63808F);
}

ColorScheme _lightScheme() => const ColorScheme(
      brightness: Brightness.light,
      primary: AppColors.teal,
      onPrimary: Colors.white,
      primaryContainer: Color(0xFFCDEAE6),
      onPrimaryContainer: Color(0xFF063A3E),
      secondary: AppColors.goldDeep,
      onSecondary: Colors.white,
      secondaryContainer: Color(0xFFF3E3B3),
      onSecondaryContainer: Color(0xFF4A3A00),
      tertiary: AppColors.lapis,
      onTertiary: Colors.white,
      tertiaryContainer: Color(0xFFD3DDF5),
      onTertiaryContainer: Color(0xFF16294F),
      error: Color(0xFFB3261E),
      onError: Colors.white,
      errorContainer: Color(0xFFF9DEDC),
      onErrorContainer: Color(0xFF410E0B),
      surface: AppColors.ivory,
      onSurface: AppColors.inkText,
      onSurfaceVariant: AppColors.inkTextSoft,
      surfaceContainerLowest: Colors.white,
      surfaceContainerLow: Color(0xFFF7F1E3),
      surfaceContainer: Color(0xFFF1EAD8),
      surfaceContainerHigh: Color(0xFFECE2CB),
      surfaceContainerHighest: Color(0xFFE4D8BC),
      outline: AppColors.inkOutline,
      outlineVariant: AppColors.inkBorder,
      inverseSurface: AppColors.inkText,
      onInverseSurface: Color(0xFFF5EFE0),
      inversePrimary: Color(0xFF7FD1C8),
      shadow: Colors.black,
      scrim: Colors.black,
      surfaceTint: AppColors.teal,
    );

ColorScheme _darkScheme() => const ColorScheme(
      brightness: Brightness.dark,
      primary: AppColors.brightTeal,
      onPrimary: Color(0xFF062A28),
      primaryContainer: Color(0xFF124A45),
      onPrimaryContainer: Color(0xFFB2EFE7),
      secondary: AppColors.brightYellow,
      onSecondary: Color(0xFF3A2E00),
      secondaryContainer: Color(0xFF544A12),
      onSecondaryContainer: Color(0xFFFFEFB0),
      tertiary: AppColors.skyBlue,
      onTertiary: Color(0xFF0A2350),
      tertiaryContainer: Color(0xFF27436E),
      onTertiaryContainer: Color(0xFFD6E4FF),
      error: Color(0xFFF2B8B5),
      onError: Color(0xFF601410),
      errorContainer: Color(0xFF8C1D18),
      onErrorContainer: Color(0xFFF9DEDC),
      surface: AppColors.night,
      onSurface: Colors.white,
      onSurfaceVariant: AppColors.darkTextSoft,
      surfaceContainerLowest: Color(0xFF08161B),
      surfaceContainerLow: AppColors.nightCardDeep,
      surfaceContainer: AppColors.nightCard,
      surfaceContainerHigh: Color(0xFF173F49),
      surfaceContainerHighest: Color(0xFF1E4C57),
      outline: AppColors.darkOutline,
      outlineVariant: AppColors.darkBorder,
      inverseSurface: Color(0xFFF5EFE0),
      onInverseSurface: AppColors.inkText,
      inversePrimary: AppColors.teal,
      shadow: Colors.black,
      scrim: Colors.black,
      surfaceTint: AppColors.brightTeal,
    );

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final scheme = dark ? _darkScheme() : _lightScheme();
  final base = ThemeData(useMaterial3: true, colorScheme: scheme);
  final text = GoogleFonts.notoNaskhArabicTextTheme(base.textTheme)
      .apply(bodyColor: scheme.onSurface, displayColor: scheme.onSurface);
  final card = dark ? AppColors.nightCard : Colors.white;
  final divider = dark ? const Color(0xFF2E5561) : const Color(0xFFCFC4AC);
  return base.copyWith(
    scaffoldBackgroundColor: dark ? AppColors.night : AppColors.ivory,
    cardColor: card,
    dividerColor: divider,
    dividerTheme: DividerThemeData(color: divider, thickness: 1, space: 1),
    iconTheme: IconThemeData(color: scheme.onSurface),
    textTheme: text,
    appBarTheme: AppBarTheme(
      centerTitle: true,
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      foregroundColor: scheme.onSurface,
      iconTheme: IconThemeData(color: scheme.onSurface),
      titleTextStyle: GoogleFonts.notoNaskhArabic(
        fontSize: 21,
        fontWeight: FontWeight.w700,
        color: scheme.onSurface,
      ),
    ),
    cardTheme: CardThemeData(
      color: card,
      elevation: dark ? 1 : 2,
      shadowColor: Colors.black.withAlpha(dark ? 90 : 45),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}

/// کارڈ کا پس منظر (روشن/تاریک دونوں کے لیے)
Color cardFill(BuildContext context) =>
    Theme.of(context).brightness == Brightness.dark
        ? const Color(0xFF12323A)
        : Colors.white;

bool _dark(BuildContext context) =>
    Theme.of(context).brightness == Brightness.dark;

// ---------- کتابی / موادی متن کے مضبوط رنگ (موڈ کے مطابق) ----------
// ڈارک موڈ میں ہلکی مدھم رنگت (فیروزی/نارنجی/گہرا teal) ختم کر کے روشن،
// اور لائٹ موڈ میں گہرے رنگ — تاکہ متن دونوں موڈز میں صاف پڑھا جائے۔

/// فارسی متن: ڈارک میں روشن آسمانی، لائٹ میں گہرا بحری
Color faBodyColor(BuildContext context) =>
    _dark(context) ? const Color(0xFFA5F3FC) : AppColors.inkText;

/// اردو متن: ڈارک میں خالص سفید، لائٹ میں گہرا بحری
Color urBodyColor(BuildContext context) =>
    _dark(context) ? Colors.white : AppColors.inkText;

/// رومن متن: ڈارک میں روشن پیلا، لائٹ میں گہرا سنہرا
Color romanBodyColor(BuildContext context) =>
    _dark(context) ? AppColors.brightYellow : AppColors.goldDeep;

/// مواد کی سرخی: ڈارک میں روشن پیلا، لائٹ میں گہرا teal
Color contentHeadingColor(BuildContext context) =>
    _dark(context) ? AppColors.brightYellow : AppColors.deepTeal;

/// سنہرا لہجہ (نمبر، چپ، مشق): ڈارک میں روشن پیلا، لائٹ میں گہرا سنہرا
Color goldAccentColor(BuildContext context) =>
    _dark(context) ? AppColors.brightYellow : AppColors.goldDeep;

/// شاعری: فارسی اشعار کا رنگ — ڈارک میں روشن پیلا، لائٹ میں گہرا سنہرا
/// (Ayesh کی ہدایت 31 اکتوبر 2026: اشعار میں فارسی و اردو کے رنگ الگ ہوں)
Color poetryFaColor(BuildContext context) =>
    _dark(context) ? AppColors.brightYellow : AppColors.goldDeep;

/// شاعری: اردو ترجمے کا رنگ — ڈارک میں روشن آسمانی نیلا، لائٹ میں گہرا نیلا
Color poetryUrColor(BuildContext context) =>
    _dark(context) ? AppColors.skyBlue : AppColors.lapis;

/// لیبل کا لہجہ: ڈارک میں ہلکا گلابی، لائٹ میں گلابی (rose)
Color labelAccentColor(BuildContext context) =>
    _dark(context) ? const Color(0xFFFF9EBB) : AppColors.rose;

/// فارسی متن کا انداز
TextStyle faStyle({double size = 22, FontWeight w = FontWeight.w600, Color? color}) =>
    GoogleFonts.vazirmatn(fontSize: size, fontWeight: w, color: color, height: 1.7);

/// اردو متن کا انداز (نستعلیق)
TextStyle urStyle({double size = 17, Color? color}) =>
    GoogleFonts.notoNastaliqUrdu(fontSize: size, color: color, height: 2.0);
