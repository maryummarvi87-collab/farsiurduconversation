import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const Color teal = Color(0xFF0E6E6E);
  static const Color deepTeal = Color(0xFF094A4F);
  static const Color gold = Color(0xFFC9A227);
  static const Color ivory = Color(0xFFFBF7EE);
  static const Color night = Color(0xFF0B1F24);
  static const Color lapis = Color(0xFF2F4B8F);
  static const Color rose = Color(0xFFA23B5A);
  static const Color emerald = Color(0xFF2E7D5B);
  static const Color saffron = Color(0xFFD98324);
  static const Color plum = Color(0xFF6B3F8C);
}

ThemeData buildTheme(Brightness b) {
  final scheme = ColorScheme.fromSeed(seedColor: AppColors.teal, brightness: b);
  final base = ThemeData(useMaterial3: true, colorScheme: scheme);
  final text = GoogleFonts.notoNaskhArabicTextTheme(base.textTheme)
      .apply(bodyColor: scheme.onSurface, displayColor: scheme.onSurface);
  return base.copyWith(
    scaffoldBackgroundColor:
        b == Brightness.light ? AppColors.ivory : AppColors.night,
    textTheme: text,
    appBarTheme: AppBarTheme(
      centerTitle: true,
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      foregroundColor: scheme.onSurface,
      titleTextStyle: GoogleFonts.notoNaskhArabic(
        fontSize: 21,
        fontWeight: FontWeight.w700,
        color: scheme.onSurface,
      ),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}

/// کارڈ کا پس منظر (روشن/تاریک دونوں کے لیے)
Color cardFill(BuildContext context) =>
    Theme.of(context).brightness == Brightness.dark
        ? const Color(0xFF12323A)
        : Colors.white;

/// فارسی متن کا انداز
TextStyle faStyle({double size = 22, FontWeight w = FontWeight.w600, Color? color}) =>
    GoogleFonts.vazirmatn(fontSize: size, fontWeight: w, color: color, height: 1.7);

/// اردو متن کا انداز (نستعلیق)
TextStyle urStyle({double size = 17, Color? color}) =>
    GoogleFonts.notoNastaliqUrdu(fontSize: size, color: color, height: 2.0);
