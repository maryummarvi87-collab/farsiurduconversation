/// ایپ کی بنیادی ترتیبات۔ اپنی ایپ شائع کرنے سے پہلے نیچے کے لنک بدل لیں۔
class AppConfig {
  static const String appName = 'فارسی اُردو بول چال';

  /// ایپ کا لنک (پلے اسٹور یا اپنی ویب سائٹ)۔ ہر شیئر کے ساتھ یہی لنک جاتا ہے۔
  /// TODO: اپنا اصل لنک یہاں لکھیں۔
  static const String appLink = 'https://maryummarvi87-collab.github.io/farsiurduconversation/';

  /// وہ پیغام جو "ایپ شیئر کریں" کے ساتھ جاتا ہے۔
  static const String shareMessage =
      'فارسی بول چال اردو کے ذریعے سیکھیں: اسباق، گرامر، کہانیاں، لغت اور کیلنڈر۔ ایپ یہاں سے حاصل کریں:';

  /// آن لائن اپڈیٹ کے لیے content.json کا لنک (ویب سائٹ، GitHub Pages وغیرہ)۔
  /// TODO: اپنا اصل لنک یہاں لکھیں۔
  static const String contentUrl = 'https://maryummarvi87-collab.github.io/farsiurduconversation/content.json';

  /// تصحیح و اضافہ کی تجاویز اس ای میل پر آئیں گی۔
  /// TODO: اپنا ای میل یہاں لکھیں۔
  static const String feedbackEmail = 'example@example.com';

  /// اگر آپ کے پاس سرور ہے جو تجاویز JSON کی صورت میں لیتا ہے تو اس کا لنک دیں،
  /// ورنہ خالی چھوڑ دیں اور ای میل استعمال ہوگی۔
  static const String feedbackPostUrl = '';
}
