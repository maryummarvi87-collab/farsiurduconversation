import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../config.dart';
import '../screens/feedback_screen.dart';
import '../theme.dart';
import 'detail_sheet.dart';
import 'word_tap_text.dart';

/// ہر شیئر کے آخر میں ایپ کا نام اور لنک خود شامل ہوتا ہے۔
String withFooter(String text) =>
    '$text\n\n— ${AppConfig.appName}\n${AppConfig.appLink}';

const _shareChannel = MethodChannel('app.share/text');

Future<void> _nativeShare(String text) async {
  try {
    await _shareChannel.invokeMethod('shareText', {'text': text});
  } on PlatformException {
    await Clipboard.setData(ClipboardData(text: text));
  }
}

Future<void> shareText(String text) async {
  await _nativeShare(withFooter(text));
}

/// پوری ایپ شیئر کرنے کے لیے
Future<void> shareApp() async {
  await _nativeShare(
      '${AppConfig.appName}\n${AppConfig.shareMessage}\n${AppConfig.appLink}');
}

void showSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

Future<void> copyText(BuildContext context, String text) async {
  await Clipboard.setData(ClipboardData(text: text));
  if (context.mounted) showSnack(context, 'کاپی ہو گیا');
}

void openFeedback(BuildContext context, String prefill) {
  Navigator.of(context).push(
    MaterialPageRoute(builder: (_) => FeedbackScreen(prefill: prefill)),
  );
}

/// فارسی جملہ + اردو ترجمہ کا کارڈ، شیئر / کاپی / تصحیح کے بٹنوں کے ساتھ
/// ٹیپ کرنے پر تفصیل شیٹ کھلتی ہے (اعراب، رومن، لفظی معانی)
class PhraseCard extends StatelessWidget {
  final String fa;
  final String ur;
  final String? who;
  final String? tag;
  final String? roman;
  final String? vocalized;
  final List<dynamic>? words;
  final VoidCallback? onTap;
  final String? en;
  final String? aiWord;
  final String? urRo;

  /// شاعری کارڈ: فارسی سنہری، اردو نیلا (Ayesh کی ہدایت)
  final bool poetry;

  const PhraseCard({
    super.key,
    required this.fa,
    required this.ur,
    this.who,
    this.tag,
    this.roman,
    this.vocalized,
    this.words,
    this.onTap,
    this.en,
    this.aiWord,
    this.urRo,
    this.poetry = false,
  });

  void _open(BuildContext context) {
    if (onTap != null) {
      onTap!();
      return;
    }
    openDetail(
      context,
      fa: fa,
      ur: ur,
      vocalized: vocalized,
      roman: roman,
      words: words,
      tag: tag ?? who,
      en: en,
      aiWord: aiWord,
      urRoman: urRo,
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final text = ur.isEmpty ? fa : '$fa\n$ur';
    // اعراب والا روپ پہلے دکھاؤ تاکہ سیکھنے والوں کو آسانی ہو
    final faShown =
        (vocalized != null && vocalized!.isNotEmpty) ? vocalized! : fa;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(16),
            blurRadius: 14,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => _open(context),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 14, 18, 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (who != null || tag != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Wrap(
                      spacing: 6,
                      children: [
                        if (who != null)
                          _chip(context, who!, goldAccentColor(context)),
                        if (tag != null) _chip(context, tag!, cs.primary),
                      ],
                    ),
                  ),
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: WordTapText(
                    fa: faShown,
                    words: words,
                    style: poetry
                        ? faStyle(size: 22, color: poetryFaColor(context))
                        : null,
                    wordColor: poetry ? poetryFaColor(context) : null,
                  ),
                ),
                if (roman != null && roman!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(left: 10, top: 2),
                    child: Text(
                      roman!,
                      style: TextStyle(
                        fontSize: 14,
                        color: romanBodyColor(context),
                        fontStyle: FontStyle.italic,
                        fontWeight: FontWeight.w600,
                      ),
                      textDirection: TextDirection.ltr,
                    ),
                  ),
                if (ur.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(left: 10, top: 2),
                    child: Text(
                      ur,
                      style: urStyle(
                          color: poetry
                              ? poetryUrColor(context)
                              : urBodyColor(context)),
                    ),
                  ),
                if (urRo != null && urRo!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(left: 10, top: 1),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        urRo!,
                        style: TextStyle(
                            fontSize: 13,
                            fontStyle: FontStyle.italic,
                            fontWeight: FontWeight.w600,
                            color: romanBodyColor(context)),
                        textDirection: TextDirection.ltr,
                        textAlign: TextAlign.left,
                      ),
                    ),
                  ),
                if (en != null && en!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(left: 10, top: 2),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        en!,
                        style: TextStyle(
                            fontSize: 13.5,
                            fontStyle: FontStyle.italic,
                            color: cs.onSurfaceVariant),
                        textDirection: TextDirection.ltr,
                        textAlign: TextAlign.left,
                      ),
                    ),
                  ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    IconButton(
                      tooltip: 'تصحیح',
                      visualDensity: VisualDensity.compact,
                      icon: const Icon(Icons.edit_note_rounded, size: 22),
                      onPressed: () => openFeedback(context, text),
                    ),
                    IconButton(
                      tooltip: 'کاپی',
                      visualDensity: VisualDensity.compact,
                      icon: const Icon(Icons.copy_rounded, size: 20),
                      onPressed: () => copyText(context, text),
                    ),
                    IconButton(
                      tooltip: 'شیئر',
                      visualDensity: VisualDensity.compact,
                      icon: const Icon(Icons.ios_share_rounded, size: 21),
                      onPressed: () => shareText(text),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _chip(BuildContext context, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
      decoration: BoxDecoration(
        color: color.withAlpha(30),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.w700),
      ),
    );
  }
}

/// ہر حصے کے لیے مشترکہ تلاش خانہ
class SearchBox extends StatefulWidget {
  final String hint;
  final ValueChanged<String> onChanged;
  final String initialValue;
  final bool autofocus;
  const SearchBox({
    super.key,
    required this.hint,
    required this.onChanged,
    this.initialValue = '',
    this.autofocus = false,
  });

  @override
  State<SearchBox> createState() => _SearchBoxState();
}

class _SearchBoxState extends State<SearchBox> {
  late final TextEditingController _ctrl =
      TextEditingController(text: widget.initialValue);

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: TextField(
        controller: _ctrl,
        autofocus: widget.autofocus,
        onChanged: widget.onChanged,
        decoration: InputDecoration(
          hintText: widget.hint,
          prefixIcon: const Icon(Icons.search_rounded),
          suffixIcon: _ctrl.text.isEmpty
              ? null
              : IconButton(
                  icon: const Icon(Icons.close_rounded),
                  onPressed: () {
                    _ctrl.clear();
                    widget.onChanged('');
                    setState(() {});
                  },
                ),
          filled: true,
          fillColor: cardFill(context),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  final String message;
  const EmptyState({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inbox_rounded,
                size: 64, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
