import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../screens/ask_ai_screen.dart';
import '../screens/verbs_screen.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import 'common.dart';
import 'word_tap_text.dart';

/// عام الفاظ کے گرامری نوٹ (کلید: normalize شدہ شکل)
const Map<String, String> _grammarNotes = {
  'این': 'این — اشارہ قریب: «یہ» (قریب کی چیز کے لیے)',
  'ان': 'آن — اشارہ بعید: «وہ» (دور کی چیز کے لیے)',
  'است': 'است — امدادی فعل: «ہے»؛ جملے کے آخر میں آتا ہے',
  'نیست': 'نیست — منفی امدادی فعل: «نہیں ہے»',
  'چیست': 'چیست — سوالیہ لفظ: «کیا ہے؟» (بول چال میں: چیه)',
  'در': 'در — حرفِ جر: «میں»',
  'به': 'به — حرفِ جر: «کو / کی طرف»',
  'از': 'از — حرفِ جر: «سے»',
  'را': 'را — مفعول کی نشانی: «کو»',
  'با': 'با — حرفِ جر: «کے ساتھ»',
  'هم': 'هم — «بھی»',
  'که': 'که — «کہ / جو» (جوڑنے والا لفظ)',
  'من': 'من — ضمیر: «میں»',
  'تو': 'تو — ضمیر: «تو / تم»',
  'او': 'او — ضمیر: «وہ»',
  'ما': 'ما — ضمیر: «ہم»',
  'شما': 'شما — ضمیر: «آپ / تم»',
  'خود': 'خود — «خود / اپنا»',
};

String _cleanToken(String t) =>
    t.replaceAll(RegExp(r'^[«"\(\[؟?۔.,؛;:!…]+|[»"\)\]؟?۔.,؛;:!…]+$'), '');

/// جملے میں استعمال شدہ مصادر: ٹوکنز کو مصادر، بنوں اور گردان صورتوں سے ملاؤ
List<Map<String, dynamic>> verbsInSentence(String fa) {
  final tokens = <String>{};
  for (final raw in fa.split(RegExp(r'\s+'))) {
    final t = normalize(_cleanToken(raw));
    if (t.isNotEmpty) tokens.add(t);
  }
  final out = <Map<String, dynamic>>[];
  for (final vb in repo.list('verbs')) {
    var hit = tokens.contains(normalize(str(vb['fa']))) ||
        tokens.contains(normalize(str(vb['past']))) ||
        tokens.contains(normalize(str(vb['pres'])));
    if (!hit) {
      outer:
      for (final g in asMaps(vb['groups'])) {
        for (final f in asMaps(g['forms'])) {
          if (tokens.contains(normalize(str(f['fa'])))) {
            hit = true;
            break outer;
          }
        }
      }
    }
    if (hit) out.add(vb);
    if (out.length >= 5) break;
  }
  return out;
}

/// جملے کی مکمل تفصیل: لفظی معانی + مصادر + گرامر نوٹ
void openSentenceDetail(
  BuildContext context, {
  required String fa,
  String? roman,
  required String ur,
  String? en,
  String? urRo,
}) {
  // لفظی معانی (لغت سے)
  final seen = <String>{};
  final wordRows = <(String, String, String, String, String)>[]; // لفظ، رومن، اردو، اردو رومن، انگریزی
  for (final raw in fa.split(RegExp(r'\s+'))) {
    final w = _cleanToken(raw);
    if (w.isEmpty || !seen.add(normalize(w))) continue;
    final f = lookupFaWord(w);
    if (f != null && (f['ur'] ?? '').isNotEmpty) {
      wordRows.add(
          (w, f['ro'] ?? '', f['ur'] ?? '', f['urRo'] ?? '', f['en'] ?? ''));
    }
  }
  final verbsUsed = verbsInSentence(fa);
  // گرامر نوٹ
  final notes = <String>[];
  final notedKeys = <String>{};
  for (final raw in fa.split(RegExp(r'\s+'))) {
    final key = normalize(_cleanToken(raw));
    final note = _grammarNotes[key];
    if (note != null && notedKeys.add(key)) notes.add(note);
  }
  if (fa.contains('؟') || fa.contains('?')) {
    notes.add('یہ سوالیہ جملہ ہے — آخر میں «؟» آتا ہے');
  }
  final text = ur.isEmpty ? fa : '$fa\n$ur';
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (ctx) {
      final cs = Theme.of(ctx).colorScheme;
      return SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 5,
                  margin: const EdgeInsets.only(bottom: 14),
                  decoration: BoxDecoration(
                    color: cs.outlineVariant,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                decoration: BoxDecoration(
                  color: cs.primary.withAlpha(30),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text('جملے کی تفصیل',
                    style: TextStyle(
                        fontSize: 13,
                        color: cs.primary,
                        fontWeight: FontWeight.w700)),
              ),
              WordTapText(fa: fa, style: faStyle(size: 25)),
              if (roman != null && roman.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(
                    roman,
                    style: TextStyle(
                        fontSize: 16,
                        color: romanBodyColor(ctx),
                        fontStyle: FontStyle.italic,
                        fontWeight: FontWeight.w600),
                    textDirection: TextDirection.ltr,
                  ),
                ),
              if (ur.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: UrduTapText(
                    ur: ur,
                    style: urStyle(size: 19, color: urBodyColor(ctx)),
                  ),
                ),
              if (urRo != null && urRo.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      urRo,
                      style: TextStyle(
                          fontSize: 14,
                          fontStyle: FontStyle.italic,
                          fontWeight: FontWeight.w600,
                          color: romanBodyColor(ctx)),
                      textDirection: TextDirection.ltr,
                      textAlign: TextAlign.left,
                    ),
                  ),
                ),
              if (en != null && en.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      en,
                      style: TextStyle(
                          fontSize: 14.5,
                          fontStyle: FontStyle.italic,
                          color: cs.onSurfaceVariant),
                      textDirection: TextDirection.ltr,
                      textAlign: TextAlign.left,
                    ),
                  ),
                ),
              if (wordRows.isNotEmpty) ...[
                const SizedBox(height: 16),
                Text('لفظی معانی',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: cs.primary)),
                const SizedBox(height: 6),
                ...wordRows.map((r) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: [
                          Expanded(
                              child: Text(r.$1, style: faStyle(size: 18))),
                          Expanded(
                            child: Text(
                              r.$2,
                              style: const TextStyle(
                                  fontSize: 14, fontStyle: FontStyle.italic),
                              textDirection: TextDirection.ltr,
                            ),
                          ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(r.$3,
                                    style: urStyle(size: 16),
                                    textAlign: TextAlign.end),
                                if (r.$4.isNotEmpty)
                                  Text(
                                    r.$4,
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontStyle: FontStyle.italic,
                                        fontWeight: FontWeight.w600,
                                        color: romanBodyColor(ctx)),
                                    textDirection: TextDirection.ltr,
                                    textAlign: TextAlign.end,
                                  ),
                                if (r.$5.isNotEmpty)
                                  Text(
                                    r.$5,
                                    style: TextStyle(
                                        fontSize: 12.5,
                                        fontStyle: FontStyle.italic,
                                        color: cs.onSurfaceVariant),
                                    textDirection: TextDirection.ltr,
                                    textAlign: TextAlign.end,
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    )),
              ],
              if (verbsUsed.isNotEmpty) ...[
                const SizedBox(height: 16),
                Text('اس جملے کے مصادر',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: cs.primary)),
                const SizedBox(height: 4),
                Text('مصدر دبائیں — مکمل گردان کھلے گی',
                    style: TextStyle(fontSize: 12.5, color: cs.outline)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final vb in verbsUsed)
                      ActionChip(
                        avatar: const Icon(Icons.menu_book_rounded, size: 16),
                        label: Text('${str(vb['fa'])} — ${str(vb['ur'])}'),
                        onPressed: () => Navigator.of(ctx).push(
                          MaterialPageRoute(
                            builder: (_) => VerbDetailScreen(verb: vb),
                          ),
                        ),
                      ),
                  ],
                ),
              ],
              if (notes.isNotEmpty) ...[
                const SizedBox(height: 16),
                Text('گرامر',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: cs.primary)),
                const SizedBox(height: 6),
                ...notes.map((n) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 3),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(left: 8, top: 9),
                            child: Icon(Icons.circle,
                                size: 7, color: AppColors.gold),
                          ),
                          Expanded(
                            child: Text(n, style: urStyle(size: 16)),
                          ),
                        ],
                      ),
                    )),
              ],
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.of(ctx).push(
                    MaterialPageRoute(
                      builder: (_) =>
                          AskAiScreen(initialQuery: fa, initialTopic: 10),
                    ),
                  ),
                  icon: const Icon(Icons.auto_awesome_rounded, size: 18),
                  label: const Text('جملے کی مکمل گرامر AI سے جانیں (اوپر گرامر نوٹ ایپ میں موجود ہیں)'),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  IconButton(
                    tooltip: 'کاپی',
                    icon: const Icon(Icons.copy_rounded),
                    onPressed: () => copyText(ctx, text),
                  ),
                  IconButton(
                    tooltip: 'شیئر',
                    icon: const Icon(Icons.ios_share_rounded),
                    onPressed: () => shareText(text),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    },
  );
}
