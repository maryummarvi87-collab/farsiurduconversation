import 'package:flutter/material.dart';

import '../theme.dart';

/// مصحف کے لفظ کی تفصیل شیٹ — مصحف اور کتابی صفحات کے آیت کارڈ دونوں استعمال
/// کرتے ہیں تاکہ لفظی تفصیل (معنی، مادہ، اصل صورت، قسمِ کلام، تکرار) ہر جگہ
/// بالکل ایک جیسی ہو۔
/// [wordRec] = quran_words.json کا اس آیت کا ریکارڈ {w: [...], m: [...]?}
void showAyahWordSheet(
  BuildContext context, {
  required String token,
  required List<int> wordIdxs,
  required Map<String, dynamic> wordRec,
}) {
  final entries = (wordRec['w'] as List).cast<List<dynamic>>();
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (_) => SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(token,
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontFamily: 'NoorQuran',
                    fontSize: 36,
                    color: Colors.black)),
            const Divider(height: 24),
            for (final wi in wordIdxs)
              if (wi < entries.length) ...[
                AyahWordDetail(e: entries[wi]),
                const SizedBox(height: 10),
              ],
          ],
        ),
      ),
    ),
  );
}

/// ایک لفظی اندراج کی تفصیل
/// e = [اردو معنی, مادہ, مادے کی تکرار, اصل صورت, اصل صورت کی تکرار, قسمِ کلام]
class AyahWordDetail extends StatelessWidget {
  final List<dynamic> e;
  const AyahWordDetail({super.key, required this.e});

  @override
  Widget build(BuildContext context) {
    final ur = e[0].toString();
    final root = e[1].toString();
    final rc = e[2] as int;
    final lem = e[3].toString();
    final lc = e[4] as int;
    final pos = e[5].toString();
    final rootSpaced = root.split('').join(' ');
    final isVerb = pos == 'فعل';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (isVerb && root.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.gold.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.gold.withOpacity(0.5)),
            ),
            child: Text('فعل کا مادہ: $rootSpaced',
                textDirection: TextDirection.rtl, style: urStyle(size: 16)),
          ),
        if (ur.isNotEmpty)
          Text('معنی: $ur',
              textDirection: TextDirection.rtl, style: urStyle(size: 17)),
        if (pos.isNotEmpty)
          Text('قسمِ کلام: $pos',
              textDirection: TextDirection.rtl, style: urStyle(size: 15)),
        if (root.isNotEmpty)
          Text('مادہ: $rootSpaced — اس مادے کے الفاظ قرآن میں $rc بار',
              textDirection: TextDirection.rtl, style: urStyle(size: 15)),
        if (lem.isNotEmpty)
          Text('اصل صورت: $lem — یہ لفظ قرآن میں $lc بار آیا ہے',
              textDirection: TextDirection.rtl, style: urStyle(size: 15)),
      ],
    );
  }
}
