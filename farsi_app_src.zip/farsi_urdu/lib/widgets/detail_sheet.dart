import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import 'common.dart';
import 'local_learn_sheet.dart';
import 'word_tap_text.dart';

/// «مزید جانیں» — پہلے ایپ کے اندر موجود مواد (مترادفات، متضاد، جمع کا موضوع،
/// مصادر کی صرفی تفصیل، ایپ کے جملے)، پھر چاہیں تو اسی شیٹ میں AI کا بٹن۔
class LearnMoreChips extends StatelessWidget {
  final String word;
  const LearnMoreChips({super.key, required this.word});

  static const _items = <(String, int)>[
    ('مترادفات', 0),
    ('متضاد', 1),
    ('مذکر و مؤنث', 2),
    ('واحد و جمع', 3),
    ('گرامر', 4),
    ('صرفی تجزیہ', 5),
    ('مثالی جملے', 6),
  ];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    if (word.trim().isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('مزید جانیں',
            style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.bold, color: cs.primary)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final it in _items)
              ActionChip(
                avatar: const Icon(Icons.menu_book_rounded, size: 16),
                label: Text(it.$1),
                onPressed: () =>
                    openLocalLearn(context, word: word, cat: it.$2),
              ),
          ],
        ),
      ],
    );
  }
}

/// کسی لفظ یا جملے کی تفصیل: اعراب، رومن، لفظی معانی
class DetailSheet extends StatelessWidget {
  final String fa;
  final String ur;
  final String? vocalized;
  final String? roman;
  final List<dynamic>? words;
  final String? tag;
  final Widget? footer;
  final String? en;
  final String? aiWord;
  final String? urRoman;

  const DetailSheet({
    super.key,
    required this.fa,
    required this.ur,
    this.vocalized,
    this.roman,
    this.words,
    this.tag,
    this.footer,
    this.en,
    this.aiWord,
    this.urRoman,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final text = ur.isEmpty ? fa : '$fa\n$ur';
    final faShown =
        (vocalized != null && vocalized!.isNotEmpty) ? vocalized! : fa;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 5,
                margin: const EdgeInsets.only(bottom: 14),
                decoration: BoxDecoration(
                  color: cs.outlineVariant,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
            if (tag != null && tag!.isNotEmpty)
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                decoration: BoxDecoration(
                  color: cs.primary.withAlpha(30),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(tag!,
                    style: TextStyle(
                        fontSize: 13,
                        color: cs.primary,
                        fontWeight: FontWeight.w700)),
              ),
            WordTapText(fa: faShown, words: words, style: faStyle(size: 26)),
            if (vocalized != null &&
                vocalized!.isNotEmpty &&
                vocalized != fa &&
                faShown != vocalized)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  vocalized!,
                  style: faStyle(size: 22, color: goldAccentColor(context)),
                ),
              ),
            if (roman != null && roman!.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  roman!,
                  style: TextStyle(
                      fontSize: 17,
                      color: romanBodyColor(context),
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.w600),
                  textDirection: TextDirection.ltr,
                ),
              ),
            if (ur.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(ur,
                    style: urStyle(size: 20, color: urBodyColor(context))),
              ),
            if (urRoman != null && urRoman!.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    urRoman!,
                    style: TextStyle(
                        fontSize: 14,
                        color: romanBodyColor(context),
                        fontStyle: FontStyle.italic,
                        fontWeight: FontWeight.w600),
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.left,
                  ),
                ),
              ),
            if (en != null && en!.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    en!,
                    style: TextStyle(
                        fontSize: 15,
                        color: cs.onSurfaceVariant,
                        fontStyle: FontStyle.italic),
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.left,
                  ),
                ),
              ),
            if (words != null && words!.isNotEmpty) ...[
              const SizedBox(height: 14),
              Text('لفظی معانی',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: cs.primary)),
              const SizedBox(height: 6),
              ...words!.map((wd) {
                final m = wd as Map<String, dynamic>;
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      Expanded(
                          child: Text(str(m['f']),
                              style: faStyle(size: 18))),
                      Expanded(
                        child: Text(
                          str(m['r']),
                          style: const TextStyle(
                              fontSize: 14, fontStyle: FontStyle.italic),
                          textDirection: TextDirection.ltr,
                        ),
                      ),
                      Expanded(
                          child: Text(str(m['u']),
                              style: urStyle(size: 16),
                              textAlign: TextAlign.end)),
                    ],
                  ),
                );
              }),
            ],
            if (footer != null) ...[
              const SizedBox(height: 14),
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: footer!,
              ),
            ],
            if (aiWord != null && aiWord!.trim().isNotEmpty) ...[
              const SizedBox(height: 16),
              LearnMoreChips(word: aiWord!),
            ],
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  tooltip: 'کاپی',
                  icon: const Icon(Icons.copy_rounded),
                  onPressed: () => copyText(context, text),
                ),
                IconButton(
                  tooltip: 'شیئر',
                  icon: const Icon(Icons.ios_share_rounded),
                  onPressed: () => shareText(text),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// تفصیل شیٹ کھولو
void openDetail(
  BuildContext context, {
  required String fa,
  required String ur,
  String? vocalized,
  String? roman,
  List<dynamic>? words,
  String? tag,
  Widget? footer,
  String? en,
  String? aiWord,
  String? urRoman,
}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) => DetailSheet(
      fa: fa,
      ur: ur,
      vocalized: vocalized,
      roman: roman,
      words: words,
      tag: tag,
      footer: footer,
      en: en,
      aiWord: aiWord,
      urRoman: urRoman,
    ),
  );
}
