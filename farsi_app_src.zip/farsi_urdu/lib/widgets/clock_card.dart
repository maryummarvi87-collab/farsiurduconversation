import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../theme.dart';
import '../utils/calendars.dart';
import '../utils/text_utils.dart';

/// ڈیجیٹل گھڑی اور آج کی تینوں تاریخیں (ہوم اسکرین کے اوپر)
class ClockCard extends StatefulWidget {
  const ClockCard({super.key});

  @override
  State<ClockCard> createState() => _ClockCardState();
}

class _ClockCardState extends State<ClockCard> {
  Timer? _timer;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final jdn = gregorianToJdn(_now.year, _now.month, _now.day);
    final wd = weekdayIndex(jdn);
    final time =
        localDigits('${two(_now.hour)}:${two(_now.minute)}:${two(_now.second)}');

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(26),
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: Colors.white.withAlpha(50)),
      ),
      child: Column(
        children: [
          Text(
            '${weekdayFa[wd]}  ·  ${weekdayUr[wd]}',
            style: const TextStyle(
              color: AppColors.gold,
              fontSize: 16,
              fontWeight: FontWeight.w700,
            ),
          ),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Text(
              time,
              style: GoogleFonts.vazirmatn(
                fontSize: 52,
                fontWeight: FontWeight.w300,
                color: Colors.white,
                letterSpacing: 3,
                height: 1.25,
              ),
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              for (final c in calendarSystems)
                Expanded(
                  child: Column(
                    children: [
                      Text(
                        c.label,
                        style: TextStyle(
                          color: Colors.white.withAlpha(170),
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        c.format(jdn),
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
