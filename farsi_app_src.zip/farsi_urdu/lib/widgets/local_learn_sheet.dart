import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../screens/ask_ai_screen.dart';
import '../screens/collection_screen.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import 'detail_sheet.dart';
import 'sentence_detail.dart';
import 'word_tap_text.dart';

/// «مزید جانیں» کے موضوعات: (عنوان، AI موضوع نمبر)
const learnCats = <(String, int)>[
  ('مترادفات', 3),
  ('متضاد', 4),
  ('مذکر و مؤنث', 5),
  ('واحد و جمع', 6),
  ('گرامر', 2),
  ('صرفی تجزیہ', 7),
  ('مثالی جملے', 9),
];

Map<String, dynamic>? _verbFor(String w) {
  final nw = normalize(w);
  for (final vb in repo.list('verbs')) {
    if (normalize(str(vb['fa'])) == nw) return vb;
  }
  return null;
}

Map<String, dynamic>? _dictFor(String w) {
  final nw = normalize(w);
  for (final e in repo.list('dictionary')) {
    if (normalize(str(e['fa'])) == nw) return e;
  }
  return null;
}

List<Map<String, dynamic>> _sentencesWith(String w) {
  final nw = normalize(w);
  if (nw.length < 2) return const [];
  final out = <Map<String, dynamic>>[];
  for (final s in repo.list('sentences')) {
    if (normalize(str(s['fa'])).contains(nw)) {
      out.add(s);
      if (out.length >= 10) break;
    }
  }
  return out;
}

List<Map<String, dynamic>> _topicsWhere(bool Function(Map<String, dynamic>) test) {
  return repo.list('grammar').where(test).toList();
}

/// پہلے ایپ کے اندر موجود مواد سے تفصیل، پھر چاہیں تو نیچے AI کا بٹن۔
void openLocalLearn(BuildContext context,
    {required String word, required int cat}) {
  final label = learnCats[cat].$1;
  final aiTopic = learnCats[cat].$2;
  final verb = _verbFor(word);
  final dict = _dictFor(word);
  final nw = normalize(word);

  final sections = <Widget>[];
  void head(String t) {
    sections.add(Padding(
      padding: const EdgeInsets.only(top: 14, bottom: 6),
      child: Text(t,
          style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.bold)),
    ));
  }

  void note(String t) {
    sections.add(Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Text(t, style: urStyle(size: 15)),
    ));
  }

  void wordRow(Map<String, dynamic> m) {
    sections.add(InkWell(
      onTap: () {
        final f = lookupFaWord(str(m['fa']));
        openDetail(
          context,
          fa: str(m['fa']),
          ur: f?['ur'] ?? str(m['ur']),
          vocalized: str(m['v']),
          roman: str(m['ro']),
          en: f?['en'],
          urRoman: f?['urRo'],
          aiWord: str(m['fa']),
          tag: label,
        );
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          children: [
            Expanded(
                child: Text(
                    str(m['v']).isNotEmpty ? str(m['v']) : str(m['fa']),
                    style: faStyle(size: 18))),
            const SizedBox(width: 8),
            Expanded(
                child: Text(str(m['ur']),
                    style: urStyle(size: 15), textAlign: TextAlign.end)),
          ],
        ),
      ),
    ));
  }

  void topicRow(Map<String, dynamic> t) {
    sections.add(InkWell(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => TextDetailScreen(item: t))),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          children: [
            const Icon(Icons.menu_book_rounded, size: 19),
            const SizedBox(width: 8),
            Expanded(
                child: Text(str(t['title']), style: urStyle(size: 15.5))),
            const Icon(Icons.chevron_left_rounded, size: 19),
          ],
        ),
      ),
    ));
  }

  switch (cat) {
    case 0: // مترادفات
      final syn = verb == null ? const [] : asMaps(verb['syn']);
      if (syn.isNotEmpty) {
        head('ایپ میں موجود مترادفات');
        for (final m in syn) {
          wordRow(m);
        }
      } else {
        note('اس لفظ کے مترادفات ایپ کی لغت میں الگ سے درج نہیں ہیں۔ نیچے AI سے معلوم کیے جا سکتے ہیں۔');
      }
      break;
    case 1: // متضاد
      final ant = verb == null ? const [] : asMaps(verb['ant']);
      if (ant.isNotEmpty) {
        head('ایپ میں موجود متضاد الفاظ');
        for (final m in ant) {
          wordRow(m);
        }
      } else {
        note('اس لفظ کے متضاد الفاظ ایپ کی لغت میں الگ سے درج نہیں ہیں۔ نیچے AI سے معلوم کیے جا سکتے ہیں۔');
      }
      break;
    case 2: // مذکر و مؤنث
      note('فارسی میں گرامر کی مذکر و مؤنث نہیں ہوتی — ضمیر «او» مرد و عورت دونوں کے لیے آتا ہے، اور جنس بتانا ہو تو الگ لفظ آتا ہے (مثلاً مرد / زن، پدر / مادر، برادر / خواهر)۔');
      final tops = _topicsWhere((t) => str(t['title']).contains('ضمائر'));
      if (tops.isNotEmpty) {
        head('متعلقہ گرامر موضوع');
        for (final t in tops) {
          topicRow(t);
        }
      }
      break;
    case 3: // واحد و جمع
      final tops = _topicsWhere((t) => str(t['title']).contains('جمع'));
      if (tops.isNotEmpty) {
        head('ایپ کا گرامر موضوع');
        for (final t in tops) {
          topicRow(t);
        }
      }
      note('عام قاعدہ: بے جان چیزوں کی جمع «ها» سے (کتاب → کتاب‌ها) اور جانداروں کی «ان» سے (مرد → مردان) بنتی ہے؛ کچھ الفاظ کی عربی طرز کی جمع بھی آتی ہے (کتاب → کُتُب)۔ اس لفظ کی مخصوص جمع نیچے AI سے بھی پوچھی جا سکتی ہے۔');
      break;
    case 4: // گرامر
      final tops = _topicsWhere((t) =>
          normalize(str(t['body'])).contains(nw) ||
          (verb != null &&
              asMaps(verb['groups'])
                  .any((g) => str(t['title']).contains(str(g['name'])))));
      if (tops.isNotEmpty) {
        head('متعلقہ گرامر موضوعات (ایپ میں موجود)');
        for (final t in tops.take(8)) {
          topicRow(t);
        }
      } else {
        note('اس لفظ سے متعلق گرامر موضوع ایپ میں نہیں ملا۔ نیچے AI سے وضاحت مل سکتی ہے۔');
      }
      break;
    case 5: // صرفی تجزیہ
      if (verb != null) {
        head('صرفی تفصیل (ایپ کے مصادر سے)');
        note('بنِ ماضی: ${str(verb['past'])} (${str(verb['pastRo'])})');
        note('بنِ مضارع: ${str(verb['pres'])} (${str(verb['presRo'])})');
        if (str(verb['tr']).isNotEmpty) note('قسم: فعل ${str(verb['tr'])}');
        final derivs = asMaps(verb['derivs']);
        if (derivs.isNotEmpty) {
          head('مشتقات');
          for (final m in derivs) {
            wordRow({
              'fa': str(m['fa']),
              'v': str(m['v']),
              'ro': str(m['ro']),
              'ur': str(m['ur']),
            });
          }
        }
      } else if (dict != null && str(dict['pos']).isNotEmpty) {
        note('قسمِ کلام: ${str(dict['pos'])}');
        note('اس لفظ کی مصدری صرفی تفصیل ایپ کے مصادر میں نہیں ہے۔ نیچے AI سے مکمل تجزیہ مل سکتا ہے۔');
      } else {
        note('اس لفظ کی صرفی تفصیل ایپ میں نہیں ملی۔ نیچے AI سے تجزیہ مل سکتا ہے۔');
      }
      break;
    case 6: // مثالی جملے
      final sents = _sentencesWith(word);
      if (sents.isNotEmpty) {
        head('ایپ کے جملوں سے مثالیں');
        for (final s in sents) {
          sections.add(InkWell(
            onTap: () => openSentenceDetail(context,
                fa: str(s['fa']),
                roman: str(s['ro']),
                ur: str(s['ur']),
                en: str(s['en']),
                urRo: str(s['urRo'])),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(str(s['fa']), style: faStyle(size: 17)),
                  Text(str(s['ur']), style: urStyle(size: 14.5)),
                ],
              ),
            ),
          ));
        }
      } else {
        note('ایپ کے جملوں میں اس لفظ کی مثال نہیں ملی۔ نیچے AI سے مثالی جملے بنوائے جا سکتے ہیں۔');
      }
      break;
  }

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (ctx) {
      final cs = Theme.of(ctx).colorScheme;
      return SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 5,
                  margin: const EdgeInsets.only(bottom: 14),
                  decoration: BoxDecoration(
                    color: cs.outlineVariant,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
              Text('$label — $word',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: cs.primary)),
              ...sections,
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => Navigator.of(ctx).push(MaterialPageRoute(
                      builder: (_) => AskAiScreen(
                          initialQuery: word, initialTopic: aiTopic))),
                  icon: const Icon(Icons.auto_awesome_rounded, size: 18),
                  label: const Text('AI سے مزید تفصیل'),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}
