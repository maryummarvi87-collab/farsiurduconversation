import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import 'detail_sheet.dart';

/// لغت میں فارسی لفظ کا معنی تلاش کرو (اعراب اتار کر مقابلہ)
Map<String, String>? lookupFaWord(String word) {
  final nw = normalize(word);
  if (nw.isEmpty) return null;
  for (final e in repo.list('dictionary')) {
    if (normalize(str(e['fa'])) == nw) {
      return {
        'fa': str(e['fa']),
        'ro': str(e['ro']),
        'ur': str(e['ur']),
        'v': str(e['v']),
        'en': str(e['en']),
        'urRo': str(e['urRo']),
        'pos': str(e['pos']),
      };
    }
  }
  return null;
}

/// لغت میں اردو لفظ کا فارسی ترجمہ تلاش کرو (اُلٹی تلاش)
Map<String, String>? lookupUrWord(String word) {
  final nw = normalize(word);
  if (nw.isEmpty) return null;
  for (final e in repo.list('dictionary')) {
    final ur = str(e['ur']);
    if (ur.isEmpty) continue;
    final parts = normalize(ur).split(RegExp(r'[/،,؛|]'));
    if (parts.any((p) => p.trim() == nw)) {
      return {
        'fa': str(e['fa']),
        'ro': str(e['ro']),
        'ur': ur,
        'v': str(e['v']),
        'en': str(e['en']),
        'urRo': str(e['urRo']),
        'pos': str(e['pos']),
      };
    }
  }
  return null;
}

/// فارسی متن جس کا ہر لفظ ٹیپ کیا جا سکتا ہے — ٹیپ پر اردو معنی کھلتا ہے
class WordTapText extends StatelessWidget {
  final String fa;
  final List<dynamic>? words;
  final TextStyle? style;

  /// ٹیپ ہونے والے الفاظ کا رنگ — نہ دیا جائے تو موڈ کے مطابق مضبوط رنگ
  final Color? wordColor;

  /// قرآن سیکشن میں لفظی شیٹ کا فارسی/عربی اسپیکر چھپاؤ (کمپیوٹر آواز نہیں)
  final bool hideFaSpeaker;

  const WordTapText(
      {super.key,
      required this.fa,
      this.words,
      this.style,
      this.wordColor,
      this.hideFaSpeaker = false});

  /// لفظ کا اردو معنی تلاش کرو: پہلے w فہرست، پھر لغت
  Map<String, String>? _lookup(String word) {
    final nw = normalize(word);
    if (nw.isEmpty) return null;
    // 1. w breakdown
    if (words != null) {
      for (final wd in words!) {
        final m = wd as Map<String, dynamic>;
        if (normalize(str(m['f'])) == nw) {
          return {'fa': str(m['f']), 'ro': str(m['r']), 'ur': str(m['u'])};
        }
      }
    }
    // 2. dictionary
    for (final e in repo.list('dictionary')) {
      if (normalize(str(e['fa'])) == nw) {
        return {
          'fa': str(e['fa']),
          'ro': str(e['ro']),
          'ur': str(e['ur']),
          'v': str(e['v']),
          'en': str(e['en']),
        'urRo': str(e['urRo']),
          'pos': str(e['pos']),
        };
      }
    }
    return null;
  }

  void _onWordTap(BuildContext context, String word) {
    final found = _lookup(word);
    if (found != null) {
      openDetail(
        context,
        fa: found['fa'] ?? word,
        ur: found['ur'] ?? '',
        vocalized: found['v'],
        roman: found['ro'],
        en: found['en'],
        urRoman: found['urRo'],
        aiWord: found['fa'] ?? word,
        tag: 'لفظ کا معنی',
        hideFaSpeaker: hideFaSpeaker,
      );
    } else {
      openDetail(
        context,
        fa: word,
        ur: 'اس لفظ کا معنی ابھی شامل نہیں۔',
        aiWord: word,
        tag: 'لفظ کا معنی',
        hideFaSpeaker: hideFaSpeaker,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // فارسی الفاظ: پورے ایپ والا سنہرا رنگ
    final wc = wordColor ?? style?.color ?? faBodyColor(context);
    // الفاظ کے درمیان خالی جگہ برقرار رکھو (split خالی جگہ کھا جاتا ہے)
    final spans = <TextSpan>[];
    final wordRe = RegExp(r'\S+');
    var last = 0;
    for (final m in wordRe.allMatches(fa)) {
      if (m.start > last) {
        spans.add(TextSpan(text: fa.substring(last, m.start)));
      }
      final part = m.group(0)!;
      // صرف حروف والے ٹکڑے ٹیپ کے قابل ہیں — نمبر، نشانات (—، ✓) سادہ رہیں
      final tappable = RegExp(r'[ء-يa-zA-Z]').hasMatch(part);
      spans.add(
        TextSpan(
          text: part,
          style: tappable
              ? TextStyle(
                  color: wc,
                  decoration: TextDecoration.underline,
                  decorationStyle: TextDecorationStyle.dotted,
                )
              : null,
          recognizer: tappable
              ? (TapGestureRecognizer()
                ..onTap = () => _onWordTap(context, part))
              : null,
        ),
      );
      last = m.end;
    }
    if (last < fa.length) {
      spans.add(TextSpan(text: fa.substring(last)));
    }
    return RichText(
      text: TextSpan(
        style: style ?? faStyle(size: 22),
        children: spans,
      ),
    );
  }
}

/// اردو متن جس کا ہر لفظ ٹیپ کیا جا سکتا ہے — ٹیپ پر اس کا فارسی ترجمہ کھلتا ہے
class UrduTapText extends StatelessWidget {
  final String ur;
  final TextStyle? style;

  /// ٹیپ ہونے والے الفاظ کا رنگ — نہ دیا جائے تو موڈ کے مطابق مضبوط رنگ
  final Color? wordColor;

  /// قرآن سیکشن میں لفظی شیٹ کا فارسی/عربی اسپیکر چھپاؤ (کمپیوٹر آواز نہیں)
  final bool hideFaSpeaker;

  const UrduTapText(
      {super.key,
      required this.ur,
      this.style,
      this.wordColor,
      this.hideFaSpeaker = false});

  void _onWordTap(BuildContext context, String word) {
    final found = lookupUrWord(word);
    if (found != null) {
      openDetail(
        context,
        fa: found['fa'] ?? word,
        ur: found['ur'] ?? '',
        vocalized: found['v'],
        roman: found['ro'],
        tag: 'فارسی ترجمہ',
        hideFaSpeaker: hideFaSpeaker,
      );
    } else {
      openDetail(
        context,
        fa: word,
        ur: 'اس لفظ کا فارسی ترجمہ ابھی شامل نہیں۔',
        tag: 'فارسی ترجمہ',
        hideFaSpeaker: hideFaSpeaker,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // اردو الفاظ: پورے ایپ والا نیلا رنگ
    final wc = wordColor ?? style?.color ?? urBodyColor(context);
    final spans = <TextSpan>[];
    final wordRe = RegExp(r'\S+');
    var last = 0;
    for (final m in wordRe.allMatches(ur)) {
      if (m.start > last) {
        spans.add(TextSpan(text: ur.substring(last, m.start)));
      }
      final part = m.group(0)!;
      final tappable = RegExp(r'[ء-يa-zA-Z]').hasMatch(part);
      spans.add(
        TextSpan(
          text: part,
          style: tappable
              ? TextStyle(
                  color: wc,
                  decoration: TextDecoration.underline,
                  decorationStyle: TextDecorationStyle.dotted,
                )
              : null,
          recognizer: tappable
              ? (TapGestureRecognizer()
                ..onTap = () => _onWordTap(context, part))
              : null,
        ),
      );
      last = m.end;
    }
    if (last < ur.length) {
      spans.add(TextSpan(text: ur.substring(last)));
    }
    return RichText(
      text: TextSpan(
        style: style ?? urStyle(size: 16.5),
        children: spans,
      ),
    );
  }
}
