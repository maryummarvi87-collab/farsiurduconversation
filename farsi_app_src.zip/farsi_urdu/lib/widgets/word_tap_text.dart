import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import 'detail_sheet.dart';

/// فارسی متن جس کا ہر لفظ ٹیپ کیا جا سکتا ہے — ٹیپ پر اردو معنی کھلتا ہے
class WordTapText extends StatelessWidget {
  final String fa;
  final List<dynamic>? words;
  final TextStyle? style;

  const WordTapText({super.key, required this.fa, this.words, this.style});

  /// لفظ کا اردو معنی تلاش کرو: پہلے w فہرست، پھر لغت
  Map<String, String>? _lookup(String word) {
    final nw = normalize(word);
    if (nw.isEmpty) return null;
    // 1. w breakdown
    if (words != null) {
      for (final wd in words!) {
        final m = wd as Map<String, dynamic>;
        if (normalize(str(m['f'])) == nw) {
          return {'fa': str(m['f']), 'ro': str(m['r']), 'ur': str(m['u'])};
        }
      }
    }
    // 2. dictionary
    for (final e in repo.list('dictionary')) {
      if (normalize(str(e['fa'])) == nw) {
        return {
          'fa': str(e['fa']),
          'ro': str(e['ro']),
          'ur': str(e['ur']),
          'v': str(e['v']),
        };
      }
    }
    return null;
  }

  void _onWordTap(BuildContext context, String word) {
    final found = _lookup(word);
    if (found != null) {
      openDetail(
        context,
        fa: found['fa'] ?? word,
        ur: found['ur'] ?? '',
        vocalized: found['v'],
        roman: found['ro'],
        tag: 'لفظ کا معنی',
      );
    } else {
      openDetail(
        context,
        fa: word,
        ur: 'اس لفظ کا معنی ابھی شامل نہیں۔',
        tag: 'لفظ کا معنی',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    // الفاظ کے درمیان خالی جگہ برقرار رکھو (split خالی جگہ کھا جاتا ہے)
    final spans = <TextSpan>[];
    final wordRe = RegExp(r'\S+');
    var last = 0;
    for (final m in wordRe.allMatches(fa)) {
      if (m.start > last) {
        spans.add(TextSpan(text: fa.substring(last, m.start)));
      }
      final part = m.group(0)!;
      spans.add(
        TextSpan(
          text: part,
          style: TextStyle(
            color: cs.primary,
            decoration: TextDecoration.underline,
            decorationStyle: TextDecorationStyle.dotted,
          ),
          recognizer: TapGestureRecognizer()
            ..onTap = () => _onWordTap(context, part),
        ),
      );
      last = m.end;
    }
    if (last < fa.length) {
      spans.add(TextSpan(text: fa.substring(last)));
    }
    return RichText(
      text: TextSpan(
        style: style ?? faStyle(size: 22),
        children: spans,
      ),
    );
  }
}
